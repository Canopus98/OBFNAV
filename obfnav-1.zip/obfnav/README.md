# OBFNav

Penampil peta offline yang sangat ringan untuk file **.obf** (format peta OsmAnd). Tanpa internet, tanpa library
pihak ketiga (hanya framework Android), tanpa animasi. Peta digambar sebagai garis vektor monokrom, dikendalikan lewat
D-pad/keyboard atau layar sentuh.

## Yang sudah bisa (fase 1)

- Membuka file `.obf` lewat pemilih file Android (memory-mapped, file besar tidak dimuat ke RAM).
- Menggambar jalan (per kelas), rel, sungai, garis pantai, area air, bangunan, nama kota/desa, dan nama jalan di zoom tinggi.
- Pan/zoom, titik GPS dan mode ikuti GPS, mode terang/gelap (INV), identifikasi objek bernama di tengah layar.
- Posisi dan zoom terakhir diingat.

## Yang belum ada

Pencarian POI/alamat dan routing (rute) belum ada. Section POI, alamat, dan routing di file `.obf` dilewati.
Lubang pada poligon (inner polygon) tidak digambar. File di atas 2 GB belum didukung.

## Kontrol

| Tombol | Fungsi |
|---|---|
| D-pad / panah | geser peta (tahan = makin cepat) |
| `+` / `-`, Page Up/Down, Volume | zoom |
| D-pad tengah / Enter | sebut objek bernama terdekat dari crosshair |
| `O` atau Menu | buka file .obf |
| `G` | GPS: nyala + ikuti, lalu ikuti saja, lalu mati |
| `I` | balik warna |
| `N` | nama tampil/sembunyi |
| `Q` | keluar |

Di layar sentuh: seret untuk geser, ketuk peta untuk memindahkan crosshair dan menyebut objek, tombol bawah (`-`, `+`,
`BUKA`, `GPS`, `INV`) untuk sisanya.

## Mendapatkan peta

Unduh peta `.obf` dari OsmAnd (osmand.net, menu unduhan peta) atau salin dari ponsel yang sudah memakai OsmAnd.
Android 11+ tidak mengizinkan memilih file di `Android/data/...`, jadi **salin file .obf ke folder Download** dulu,
lalu pilih dari sana lewat tombol BUKA.

## Membangun APK lewat GitHub (tanpa Android Studio)

1. Buat repository baru di GitHub (boleh private).
2. Unggah **seluruh isi folder ini**. Pastikan folder tersembunyi `.github/workflows/build.yml` ikut terunggah.
   Cara paling aman: pakai `git` (`git init`, `git add -A`, `git commit`, `git push`) atau GitHub Desktop.
   Kalau memakai unggah lewat web dan `.github` tidak ikut, buat manual: *Add file → Create new file*, ketik nama
   `.github/workflows/build.yml`, lalu tempel isi file itu.
3. Buka tab **Actions** → workflow **Build APK** (jalan otomatis setiap push, atau tekan *Run workflow*).
4. Setelah hijau, buka run-nya, unduh artifact **obfnav-debug-apk** (zip berisi `app-debug.apk`).
5. Pasang di ponsel (izinkan "pasang dari sumber tidak dikenal").

Workflow juga menjalankan uji reader OBF sebelum membangun APK. Kalau uji itu gagal, build berhenti.

Membangun sendiri: di komputer dengan JDK 17 + Android SDK, jalankan `gradle assembleDebug` (Gradle 8.9)
atau buka folder ini di Android Studio. Hasilnya `app/build/outputs/apk/debug/app-debug.apk`.

## Memeriksa file .obf nyata di PC (disarankan sebelum menyalahkan aplikasi)

Reader ini diuji dengan file sintetis dan dengan satu file .obf asli (peta kecil sekitar Karawang/Cikampek, Jawa Barat:
header, level zoom, kueri objek, dan koordinat nama kota cocok dengan lokasi sebenarnya). Peta lain, terutama yang jauh
lebih besar atau dari versi OsmAnd berbeda, belum diuji. Untuk memastikan file Anda terbaca benar:

```
mkdir out
javac -d out $(find app/src/main/java/dev/obfnav/core tools -name '*.java')
java -cp out dev.obfnav.tools.SelfTest
java -cp out dev.obfnav.tools.ObfDump peta.obf                      # header, level zoom, jumlah aturan
java -cp out dev.obfnav.tools.ObfDump peta.obf -6.2088 106.8456 15  # objek di sekitar satu titik
```

Kalau `ObfDump` gagal atau hasilnya janggal pada file asli, kirimkan keluarannya; itu petunjuk paling cepat untuk
memperbaiki reader.

## Struktur

```
app/src/main/java/dev/obfnav/core/   reader OBF (Java murni, tanpa dependensi Android)
    ObfReader.java    parser section MAP: aturan, level zoom, R-tree box, blok data, koordinat delta
    Style.java        tabel kecil tag OSM -> kelas gambar + zoom minimum
    Geo.java          lat/lon <-> koordinat Mercator 31-bit
app/src/main/java/dev/obfnav/        UI: MainActivity (file, GPS), MapView (render + input)
tools/                               uji mandiri dan alat ObfDump (tidak ikut APK)
.github/workflows/build.yml          build APK di GitHub Actions
```

Cara kerja singkat: pada saat menggambar, viewport diubah menjadi kotak koordinat 31-bit. Reader menelusuri R-tree
di file, hanya membaca blok yang beririsan dengan kotak itu, lalu hasilnya disimpan sebagai array `int`. Area 1,5x
viewport dimuat sekaligus di thread terpisah supaya geser kecil tidak memicu pembacaan ulang. Layar hanya digambar ulang
saat ada input atau data baru.

## Catatan lisensi

Format .obf didefinisikan oleh OsmAnd (GPLv3). Reader di sini ditulis ulang dari awal, bukan disalin, tetapi nomor
field dan aturan decoding mengikuti kode OsmAnd (`BinaryMapIndexReader`) sebagai acuan. Jika Anda berencana
mendistribusikan aplikasi ini, pertimbangkan merilisnya dengan GPLv3 agar aman, atau minta nasihat hukum.
Data peta OpenStreetMap berlisensi ODbL dan perlu atribusi "© OpenStreetMap contributors".
