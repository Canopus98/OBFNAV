package dev.obfnav.core;

/** Conversions between WGS84 degrees and OsmAnd's 31-bit Web-Mercator coordinates. */
public final class Geo {
    public static final double SPAN = 2147483648.0; // 2^31

    private Geo() {
    }

    public static double lonToX(double lon) {
        return (lon + 180.0) / 360.0 * SPAN;
    }

    public static double latToY(double lat) {
        if (lat > 85.0511) lat = 85.0511;
        if (lat < -85.0511) lat = -85.0511;
        double r = Math.toRadians(lat);
        double e = Math.log(Math.tan(r) + 1.0 / Math.cos(r));
        return (1.0 - e / Math.PI) / 2.0 * SPAN;
    }

    public static double xToLon(double x) {
        return x / SPAN * 360.0 - 180.0;
    }

    public static double yToLat(double y) {
        double n = Math.PI * (1.0 - 2.0 * y / SPAN);
        return Math.toDegrees(Math.atan(Math.sinh(n)));
    }
}
