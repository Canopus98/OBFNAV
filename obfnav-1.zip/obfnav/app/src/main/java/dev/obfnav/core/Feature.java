package dev.obfnav.core;

/** One map object (road, building, water polygon, place point...) in 31-bit Mercator coordinates. */
public final class Feature {
    /** x0,y0,x1,y1,... in 31-bit Mercator units. */
    public int[] xy;
    /** Rule ids (see {@link ObfReader.MapIndex#rule(int)}). */
    public int[] types;
    /** True when the geometry is a closed area (polygon), false for lines and points. */
    public boolean area;
    public String name;
    public long id;
    /** Drawing class assigned by {@link Style}; 0 means "do not draw". */
    public int cls;
    public int minX, maxX, minY, maxY;

    /** Index into the block string table, resolved when the block is finished. */
    int nameRef = -1;
}
