package dev.obfnav;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

import dev.obfnav.core.Feature;
import dev.obfnav.core.Geo;
import dev.obfnav.core.ObfReader;
import dev.obfnav.core.Style;

/**
 * Monochrome vector map view. No bitmaps, no animation: it redraws only on input or when a new
 * batch of features has been loaded by the worker thread.
 */
public final class MapView extends View {

    public interface Host {
        void onOpenRequest();

        void onGpsToggle();

        void onQuit();
    }

    private static final int MAX_FEATURES = 60000;
    private static final int MIN_ZOOM = 1;
    private static final int MAX_ZOOM = 22;

    private static final class Loaded {
        List<Feature> feats;
        int left, right, top, bottom;
        int zoom;
        boolean truncated;
    }

    private static final class Button {
        final String label;
        final int id;
        final android.graphics.RectF r = new android.graphics.RectF();

        Button(String label, int id) {
            this.label = label;
            this.id = id;
        }
    }

    private static final int B_OUT = 0, B_IN = 1, B_OPEN = 2, B_GPS = 3, B_INV = 4;

    private Host host;
    private ObfReader reader;
    private int[][] ruleClasses;
    private String fileName = "";
    private String status = "";

    private double cx = Geo.lonToX(106.8456), cy = Geo.latToY(-6.2088);
    private int zoom = 14;
    private int minZoom = MIN_ZOOM, maxZoom = MAX_ZOOM;
    private boolean inverted;
    private boolean showNames = true;
    private String info = "";

    private boolean hasGps;
    private double gpsLat, gpsLon;
    private boolean followGps;

    private volatile Loaded loaded;
    private final Object lock = new Object();
    private boolean pending;
    private int rl, rr, rt, rb, rz;
    private Thread worker;
    private boolean closed;

    private final float density;
    private final float px1;
    private final Paint line = new Paint();
    private final Paint fill = new Paint();
    private final Paint text = new Paint();
    private final Path path = new Path();
    private final Button[] buttons = {
            new Button("-", B_OUT), new Button("+", B_IN), new Button("BUKA", B_OPEN),
            new Button("GPS", B_GPS), new Button("INV", B_INV)};
    private final List<float[]> labelRects = new ArrayList<float[]>();
    private float downX, downY, lastX, lastY;
    private boolean dragged;

    public MapView(Context ctx) {
        super(ctx);
        density = ctx.getResources().getDisplayMetrics().density;
        px1 = Math.max(1f, Math.round(density * 0.75f));
        setFocusable(true);
        setFocusableInTouchMode(true);
        line.setAntiAlias(false);
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeCap(Paint.Cap.BUTT);
        line.setStrokeJoin(Paint.Join.MITER);
        fill.setAntiAlias(false);
        fill.setStyle(Paint.Style.FILL);
        text.setAntiAlias(false);
        text.setTypeface(Typeface.MONOSPACE);
        text.setTextSize(12f * ctx.getResources().getDisplayMetrics().scaledDensity);
        startWorker();
    }

    public void setHost(Host h) {
        host = h;
    }

    public void setStatus(String s) {
        status = s;
        postInvalidate();
    }

    public boolean isInverted() {
        return inverted;
    }

    public void setInverted(boolean v) {
        inverted = v;
        postInvalidate();
    }

    public int getZoom() {
        return zoom;
    }

    public void setZoom(int z) {
        zoom = Math.max(minZoom, Math.min(maxZoom, z));
        postInvalidate();
    }

    public double getCenterLat() {
        return Geo.yToLat(cy);
    }

    public double getCenterLon() {
        return Geo.xToLon(cx);
    }

    public void setCenter(double lat, double lon) {
        cx = Geo.lonToX(lon);
        cy = Geo.latToY(lat);
        postInvalidate();
    }

    public void setGps(boolean has, double lat, double lon) {
        hasGps = has;
        gpsLat = lat;
        gpsLon = lon;
        if (has && followGps) {
            cx = Geo.lonToX(lon);
            cy = Geo.latToY(lat);
        }
        postInvalidate();
    }

    public boolean isFollowGps() {
        return followGps;
    }

    public void setFollowGps(boolean f) {
        followGps = f;
        if (f && hasGps) {
            cx = Geo.lonToX(gpsLon);
            cy = Geo.latToY(gpsLat);
        }
        postInvalidate();
    }

    /** Installs a new map file; the view jumps to the middle of its coverage if the view is outside it. */
    public void setReader(ObfReader r, String name) {
        reader = r;
        fileName = name;
        loaded = null;
        info = "";
        if (r == null) {
            ruleClasses = null;
            minZoom = MIN_ZOOM;
            maxZoom = MAX_ZOOM;
            postInvalidate();
            return;
        }
        List<ObfReader.MapIndex> maps = r.getMaps();
        ruleClasses = new int[maps.size()][];
        int lo = Integer.MAX_VALUE, hi = 0;
        boolean inside = false;
        for (int i = 0; i < maps.size(); i++) {
            ObfReader.MapIndex mi = maps.get(i);
            ruleClasses[i] = Style.buildRuleClasses(mi);
            if (!mi.levels.isEmpty()) {
                lo = Math.min(lo, mi.minZoom());
                hi = Math.max(hi, mi.maxZoom());
                for (ObfReader.Level lv : mi.levels) {
                    if (cx >= lv.left && cx <= lv.right && cy >= lv.top && cy <= lv.bottom) inside = true;
                }
            }
        }
        if (hi > 0) {
            minZoom = Math.max(MIN_ZOOM, lo);
            maxZoom = Math.min(MAX_ZOOM, hi);
        }
        if (!inside && !maps.isEmpty() && maps.get(0).centerX() >= 0) {
            cx = maps.get(0).centerX();
            cy = maps.get(0).centerY();
        }
        zoom = Math.max(minZoom, Math.min(maxZoom, Math.max(zoom, 12)));
        postInvalidate();
    }

    public void close() {
        synchronized (lock) {
            closed = true;
            lock.notifyAll();
        }
    }

    // ------------------------------------------------------------------ loading

    private void startWorker() {
        worker = new Thread(new Runnable() {
            @Override
            public void run() {
                loop();
            }
        }, "obf-loader");
        worker.setPriority(Thread.NORM_PRIORITY - 1);
        worker.setDaemon(true);
        worker.start();
    }

    private void requestLoad(int l, int r, int t, int b, int z) {
        synchronized (lock) {
            rl = l;
            rr = r;
            rt = t;
            rb = b;
            rz = z;
            pending = true;
            lock.notifyAll();
        }
    }

    private void loop() {
        while (true) {
            int l, r, t, b, z;
            ObfReader rd;
            int[][] rc;
            synchronized (lock) {
                while (!pending && !closed) {
                    try {
                        lock.wait();
                    } catch (InterruptedException e) {
                        return;
                    }
                }
                if (closed) return;
                l = rl;
                r = rr;
                t = rt;
                b = rb;
                z = rz;
                pending = false;
                rd = reader;
                rc = ruleClasses;
            }
            if (rd == null || rc == null) continue;
            final List<Feature> out = new ArrayList<Feature>();
            final boolean[] truncated = {false};
            final int zz = z;
            try {
                List<ObfReader.MapIndex> maps = rd.getMaps();
                for (int i = 0; i < maps.size(); i++) {
                    final int[] classes = rc[i];
                    rd.search(maps.get(i), l, r, t, b, z, new ObfReader.FeatureSink() {
                        @Override
                        public boolean accept(ObfReader.MapIndex map, Feature f) {
                            f.cls = Style.classOf(classes, f.types);
                            if (f.cls == Style.NONE || zz < Style.minZoom(f.cls)) return true;
                            if (Style.isPlace(f.cls) && f.name == null) return true;
                            out.add(f);
                            if (out.size() >= MAX_FEATURES) {
                                truncated[0] = true;
                                return false;
                            }
                            return true;
                        }
                    });
                    if (truncated[0]) break;
                }
            } catch (IOException e) {
                setStatus("ERR " + e.getMessage());
                continue;
            }
            Collections.sort(out, new Comparator<Feature>() {
                @Override
                public int compare(Feature x, Feature y) {
                    return x.cls < y.cls ? -1 : (x.cls == y.cls ? 0 : 1);
                }
            });
            Loaded ld = new Loaded();
            ld.feats = out;
            ld.left = l;
            ld.right = r;
            ld.top = t;
            ld.bottom = b;
            ld.zoom = z;
            ld.truncated = truncated[0];
            loaded = ld;
            postInvalidate();
        }
    }

    // ------------------------------------------------------------------ drawing

    private double unitsPerPx() {
        return Math.pow(2.0, 23 - zoom) / density;
    }

    private int fg() {
        return inverted ? 0xFFFFFFFF : 0xFF000000;
    }

    private int bg() {
        return inverted ? 0xFF000000 : 0xFFFFFFFF;
    }

    private void applyClass(int cls) {
        line.setPathEffect(null);
        float w = px1;
        switch (cls) {
            case Style.MOTORWAY:
            case Style.TRUNK:
                w = px1 * 3;
                break;
            case Style.PRIMARY:
                w = px1 * 2;
                break;
            case Style.SECONDARY:
                w = px1 * 2;
                break;
            case Style.TRACK:
                line.setPathEffect(new DashPathEffect(new float[]{px1 * 6, px1 * 4}, 0));
                break;
            case Style.PATH:
                line.setPathEffect(new DashPathEffect(new float[]{px1 * 2, px1 * 3}, 0));
                break;
            case Style.RAIL:
                line.setPathEffect(new DashPathEffect(new float[]{px1 * 10, px1 * 3, px1 * 2, px1 * 3}, 0));
                break;
            case Style.WATERWAY:
            case Style.WATER:
                line.setPathEffect(new DashPathEffect(new float[]{px1, px1 * 3}, 0));
                break;
            default:
                break;
        }
        line.setStrokeWidth(w);
    }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        c.drawColor(bg());
        line.setColor(fg());
        fill.setColor(fg());
        text.setColor(fg());

        double upp = unitsPerPx();
        double halfW = w / 2.0 * upp, halfH = h / 2.0 * upp;
        int vl = (int) Math.max(0, cx - halfW), vr = (int) Math.min(Integer.MAX_VALUE, cx + halfW);
        int vt = (int) Math.max(0, cy - halfH), vb = (int) Math.min(Integer.MAX_VALUE, cy + halfH);

        Loaded ld = loaded;
        if (reader != null && w > 0) {
            boolean covered = ld != null && ld.zoom == zoom && vl >= ld.left && vr <= ld.right
                    && vt >= ld.top && vb <= ld.bottom;
            if (!covered) {
                // load 1.5x the viewport so small pans do not trigger a reload
                int ml = (int) (halfW * 1.5), mt = (int) (halfH * 1.5);
                requestLoad((int) Math.max(0, cx - halfW - ml), (int) Math.min(Integer.MAX_VALUE, cx + halfW + ml),
                        (int) Math.max(0, cy - halfH - mt), (int) Math.min(Integer.MAX_VALUE, cy + halfH + mt),
                        zoom);
            }
        }

        labelRects.clear();
        int drawn = 0;
        if (ld != null) {
            int lastCls = -1;
            double ox = cx - halfW, oy = cy - halfH;
            double inv = 1.0 / upp;
            for (int i = 0; i < ld.feats.size(); i++) {
                Feature f = ld.feats.get(i);
                if (zoom < Style.minZoom(f.cls)) continue;
                if (f.maxX < vl || f.minX > vr || f.maxY < vt || f.minY > vb) continue;
                if (Style.isPlace(f.cls)) continue; // labels are drawn in a second pass
                if (f.cls != lastCls) {
                    applyClass(f.cls);
                    lastCls = f.cls;
                }
                drawFeature(c, f, ox, oy, inv);
                drawn++;
            }
            line.setPathEffect(null);
            if (showNames) drawLabels(c, ld, ox, oy, inv, vl, vr, vt, vb, w, h);
        }

        drawGps(c, w, h);
        drawChrome(c, w, h, drawn, ld);
    }

    private void drawFeature(Canvas c, Feature f, double ox, double oy, double inv) {
        int[] xy = f.xy;
        path.rewind();
        float lastX = 0, lastY = 0;
        boolean started = false;
        for (int i = 0; i < xy.length; i += 2) {
            float sx = (float) ((xy[i] - ox) * inv);
            float sy = (float) ((xy[i + 1] - oy) * inv);
            if (!started) {
                path.moveTo(sx, sy);
                started = true;
            } else if (Math.abs(sx - lastX) >= 1f || Math.abs(sy - lastY) >= 1f) {
                path.lineTo(sx, sy);
            } else {
                continue;
            }
            lastX = sx;
            lastY = sy;
        }
        if (f.area) path.close();
        c.drawPath(path, line);
    }

    private boolean placeLabel(Canvas c, String s, float x, float y, int w, int h) {
        if (s == null || s.length() == 0) return false;
        float tw = text.measureText(s);
        float th = text.getTextSize();
        float l = x - tw / 2, t = y - th, r = x + tw / 2, b = y + 3;
        if (l < 2 || r > w - 2 || t < th + 6 || b > h - th * 2.2f) return false;
        for (float[] q : labelRects) {
            if (l < q[2] && r > q[0] && t < q[3] && b > q[1]) return false;
        }
        labelRects.add(new float[]{l, t, r, b});
        fill.setColor(bg());
        c.drawRect(l - 2, t, r + 2, b, fill);
        text.setColor(fg());
        c.drawText(s, l, y, text);
        return true;
    }

    private void drawLabels(Canvas c, Loaded ld, double ox, double oy, double inv,
                            int vl, int vr, int vt, int vb, int w, int h) {
        int roadLabels = 0;
        // places first (big ones first), then road names at high zoom
        for (int pass = 0; pass < 2; pass++) {
            for (int i = ld.feats.size() - 1; i >= 0; i--) {
                Feature f = ld.feats.get(i);
                if (f.name == null) continue;
                if (pass == 0 && !Style.isPlace(f.cls)) continue;
                if (pass == 1 && (!Style.isRoad(f.cls) || zoom < 16 || roadLabels > 40)) continue;
                if (f.maxX < vl || f.minX > vr || f.maxY < vt || f.minY > vb) continue;
                int n = f.xy.length / 2;
                int mid = (n / 2) * 2;
                float sx = (float) ((f.xy[mid] - ox) * inv);
                float sy = (float) ((f.xy[mid + 1] - oy) * inv);
                if (placeLabel(c, f.name, sx, sy, w, h) && pass == 1) roadLabels++;
            }
        }
    }

    private void drawGps(Canvas c, int w, int h) {
        if (!hasGps) return;
        float sx = (float) ((Geo.lonToX(gpsLon) - (cx - w / 2.0 * unitsPerPx())) / unitsPerPx());
        float sy = (float) ((Geo.latToY(gpsLat) - (cy - h / 2.0 * unitsPerPx())) / unitsPerPx());
        float r = 7 * density;
        line.setPathEffect(null);
        line.setStrokeWidth(px1 * 2);
        c.drawLine(sx - r, sy, sx + r, sy, line);
        c.drawLine(sx, sy - r, sx, sy + r, line);
        c.drawRect(sx - r / 2, sy - r / 2, sx + r / 2, sy + r / 2, line);
    }

    private void drawChrome(Canvas c, int w, int h, int drawn, Loaded ld) {
        float th = text.getTextSize();
        line.setPathEffect(null);
        line.setStrokeWidth(px1);
        line.setColor(fg());

        // crosshair
        float mx = w / 2f, my = h / 2f, cr = 6 * density;
        c.drawLine(mx - cr, my, mx + cr, my, line);
        c.drawLine(mx, my - cr, mx, my + cr, line);

        if (reader == null) {
            text.setColor(fg());
            String[] hint = {"Belum ada peta.", "Tekan BUKA (atau tombol O)", "lalu pilih file .obf"};
            for (int i = 0; i < hint.length; i++) {
                float tw = text.measureText(hint[i]);
                c.drawText(hint[i], mx - tw / 2, my + th * (3 + 1.5f * i), text);
            }
        }

        // top bar
        fill.setColor(bg());
        c.drawRect(0, 0, w, th + 8, fill);
        line.setStrokeWidth(px1);
        c.drawLine(0, th + 8, w, th + 8, line);
        text.setColor(fg());
        String top = (fileName.length() == 0 ? "(belum ada peta)" : fileName) + "  Z" + zoom
                + (ld != null && ld.truncated ? " [PENUH]" : "");
        c.drawText(top, 4, th + 2, text);

        // bottom bar: info line, coordinates/status, soft buttons
        float bh = th * 2.2f + 10 * density;
        float by = h - bh;
        fill.setColor(bg());
        c.drawRect(0, by, w, h, fill);
        c.drawLine(0, by, w, by, line);
        String l1 = info.length() > 0 ? info : status;
        if (l1.length() == 0) {
            l1 = String.format(Locale.US, "%.5f %.5f  %d obj", getCenterLat(), getCenterLon(), drawn);
        }
        c.drawText(l1, 4, by + th + 1, text);

        float bw = w / (float) buttons.length;
        float y0 = by + th * 1.4f + 4, y1 = h - 3;
        for (int i = 0; i < buttons.length; i++) {
            Button b = buttons[i];
            b.r.set(i * bw + 3, y0, (i + 1) * bw - 3, y1);
            boolean on = (b.id == B_INV && inverted) || (b.id == B_GPS && followGps);
            if (on) {
                fill.setColor(fg());
                c.drawRect(b.r, fill);
                text.setColor(bg());
            } else {
                c.drawRect(b.r, line);
                text.setColor(fg());
            }
            float tw = text.measureText(b.label);
            c.drawText(b.label, b.r.centerX() - tw / 2, b.r.centerY() + th / 3, text);
        }
        text.setColor(fg());

        // frame
        line.setStrokeWidth(px1);
        c.drawRect(px1 / 2, px1 / 2, w - px1 / 2, h - px1 / 2, line);
    }

    // ------------------------------------------------------------------ input

    private void pan(double dxPx, double dyPx) {
        double upp = unitsPerPx();
        cx = Math.max(0, Math.min(Geo.SPAN - 1, cx + dxPx * upp));
        cy = Math.max(0, Math.min(Geo.SPAN - 1, cy + dyPx * upp));
        followGps = false;
        info = "";
        invalidate();
    }

    private void zoomBy(int d) {
        int z = Math.max(minZoom, Math.min(maxZoom, zoom + d));
        if (z != zoom) {
            zoom = z;
            info = "";
            invalidate();
        }
    }

    private void press(int id) {
        switch (id) {
            case B_OUT:
                zoomBy(-1);
                break;
            case B_IN:
                zoomBy(1);
                break;
            case B_OPEN:
                if (host != null) host.onOpenRequest();
                break;
            case B_GPS:
                if (host != null) host.onGpsToggle();
                break;
            case B_INV:
                inverted = !inverted;
                invalidate();
                break;
            default:
                break;
        }
    }

    /** Describes the nearest named object around the crosshair. */
    private void identify() {
        Loaded ld = loaded;
        info = "";
        if (ld == null || reader == null) return;
        double bestD = 40 * density * unitsPerPx();
        bestD *= bestD;
        Feature best = null;
        for (Feature f : ld.feats) {
            if (f.name == null) continue;
            for (int i = 0; i < f.xy.length; i += 2) {
                double dx = f.xy[i] - cx, dy = f.xy[i + 1] - cy;
                double d = dx * dx + dy * dy;
                if (d < bestD) {
                    bestD = d;
                    best = f;
                }
            }
        }
        info = best == null ? "(tidak ada objek bernama)" : best.name + " [" + describe(best) + "]";
        invalidate();
    }

    private String describe(Feature f) {
        switch (f.cls) {
            case Style.MOTORWAY:
                return "motorway";
            case Style.TRUNK:
                return "trunk";
            case Style.PRIMARY:
                return "primary";
            case Style.SECONDARY:
                return "secondary";
            case Style.TERTIARY:
                return "tertiary";
            case Style.MINOR:
                return "jalan";
            case Style.PLACE_BIG:
            case Style.PLACE_SMALL:
                return "tempat";
            case Style.WATER:
            case Style.WATERWAY:
                return "air";
            case Style.BUILDING:
                return "bangunan";
            default:
                return "objek";
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent e) {
        float step = Math.min(getWidth(), getHeight()) / 6f;
        if (e.getRepeatCount() > 8) step *= 3;
        switch (keyCode) {
            case KeyEvent.KEYCODE_DPAD_LEFT:
                pan(-step, 0);
                return true;
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                pan(step, 0);
                return true;
            case KeyEvent.KEYCODE_DPAD_UP:
                pan(0, -step);
                return true;
            case KeyEvent.KEYCODE_DPAD_DOWN:
                pan(0, step);
                return true;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
                if (e.getRepeatCount() == 0) identify();
                return true;
            case KeyEvent.KEYCODE_PLUS:
            case KeyEvent.KEYCODE_EQUALS:
            case KeyEvent.KEYCODE_NUMPAD_ADD:
            case KeyEvent.KEYCODE_PAGE_UP:
            case KeyEvent.KEYCODE_VOLUME_UP:
                if (e.getRepeatCount() == 0) zoomBy(1);
                return true;
            case KeyEvent.KEYCODE_MINUS:
            case KeyEvent.KEYCODE_NUMPAD_SUBTRACT:
            case KeyEvent.KEYCODE_PAGE_DOWN:
            case KeyEvent.KEYCODE_VOLUME_DOWN:
                if (e.getRepeatCount() == 0) zoomBy(-1);
                return true;
            case KeyEvent.KEYCODE_O:
            case KeyEvent.KEYCODE_MENU:
                press(B_OPEN);
                return true;
            case KeyEvent.KEYCODE_G:
                press(B_GPS);
                return true;
            case KeyEvent.KEYCODE_I:
                press(B_INV);
                return true;
            case KeyEvent.KEYCODE_N:
                showNames = !showNames;
                invalidate();
                return true;
            case KeyEvent.KEYCODE_Q:
                if (host != null) host.onQuit();
                return true;
            default:
                return super.onKeyDown(keyCode, e);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getAction()) {
            case MotionEvent.ACTION_DOWN:
                downX = lastX = e.getX();
                downY = lastY = e.getY();
                dragged = false;
                return true;
            case MotionEvent.ACTION_MOVE: {
                float dx = e.getX() - lastX, dy = e.getY() - lastY;
                if (!dragged && Math.hypot(e.getX() - downX, e.getY() - downY) > 8 * density) dragged = true;
                if (dragged) pan(-dx, -dy);
                lastX = e.getX();
                lastY = e.getY();
                return true;
            }
            case MotionEvent.ACTION_UP:
                if (!dragged) {
                    for (Button b : buttons) {
                        if (b.r.contains(e.getX(), e.getY())) {
                            press(b.id);
                            return true;
                        }
                    }
                    // a tap on the map moves the crosshair there and identifies the object
                    double upp = unitsPerPx();
                    cx += (e.getX() - getWidth() / 2f) * upp;
                    cy += (e.getY() - getHeight() / 2f) * upp;
                    identify();
                }
                return true;
            default:
                return true;
        }
    }
}
