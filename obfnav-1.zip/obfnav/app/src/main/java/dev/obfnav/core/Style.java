package dev.obfnav.core;

/**
 * Tiny rule table: maps OSM tag=value pairs (decoded from the OBF rule table) to a drawing class.
 * Higher class number wins when an object carries several matching tags.
 */
public final class Style {
    public static final int NONE = 0;
    public static final int WATER = 1;      // water polygons
    public static final int COAST = 2;      // natural=coastline
    public static final int WATERWAY = 3;   // rivers, streams, canals
    public static final int BUILDING = 4;
    public static final int RAIL = 5;
    public static final int PATH = 6;       // footway, path, cycleway, steps
    public static final int TRACK = 7;
    public static final int MINOR = 8;      // residential, service, unclassified
    public static final int TERTIARY = 9;
    public static final int SECONDARY = 10;
    public static final int PRIMARY = 11;
    public static final int TRUNK = 12;
    public static final int MOTORWAY = 13;
    public static final int PLACE_SMALL = 20; // village, suburb, hamlet...
    public static final int PLACE_BIG = 21;   // city, town

    private Style() {
    }

    public static int[] buildRuleClasses(ObfReader.MapIndex mi) {
        int[] c = new int[mi.rules.length];
        for (int i = 0; i < c.length; i++) {
            ObfReader.Rule r = mi.rules[i];
            c[i] = r == null ? NONE : classify(r.tag, r.value);
        }
        return c;
    }

    public static int classOf(int[] ruleClass, int[] types) {
        int best = NONE;
        for (int t : types) {
            if (t >= 0 && t < ruleClass.length && ruleClass[t] > best) best = ruleClass[t];
        }
        return best;
    }

    public static int classify(String tag, String v) {
        if (tag == null) return NONE;
        if (v == null) v = "";
        if (tag.equals("highway")) {
            if (v.startsWith("motorway")) return MOTORWAY;
            if (v.startsWith("trunk")) return TRUNK;
            if (v.startsWith("primary")) return PRIMARY;
            if (v.startsWith("secondary")) return SECONDARY;
            if (v.startsWith("tertiary")) return TERTIARY;
            if (v.equals("residential") || v.equals("unclassified") || v.equals("living_street")
                    || v.equals("service") || v.equals("road")) return MINOR;
            if (v.equals("track")) return TRACK;
            if (v.equals("footway") || v.equals("path") || v.equals("cycleway") || v.equals("steps")
                    || v.equals("pedestrian") || v.equals("bridleway")) return PATH;
            return NONE;
        }
        if (tag.equals("building")) return v.equals("no") ? NONE : BUILDING;
        if (tag.equals("natural")) {
            if (v.equals("water") || v.equals("bay")) return WATER;
            if (v.equals("coastline")) return COAST;
            return NONE;
        }
        if (tag.equals("waterway")) {
            if (v.equals("riverbank") || v.equals("dock")) return WATER;
            if (v.equals("river") || v.equals("stream") || v.equals("canal") || v.equals("drain")
                    || v.equals("ditch")) return WATERWAY;
            return NONE;
        }
        if (tag.equals("landuse") && (v.equals("reservoir") || v.equals("basin"))) return WATER;
        if (tag.equals("railway")) {
            if (v.equals("rail") || v.equals("light_rail") || v.equals("narrow_gauge")
                    || v.equals("tram") || v.equals("subway")) return RAIL;
            return NONE;
        }
        if (tag.equals("place")) {
            if (v.equals("city") || v.equals("town")) return PLACE_BIG;
            if (v.equals("village") || v.equals("suburb") || v.equals("hamlet")
                    || v.equals("neighbourhood") || v.equals("quarter")) return PLACE_SMALL;
            return NONE;
        }
        return NONE;
    }

    /** Lowest zoom at which a class is drawn (keeps low zoom levels fast and uncluttered). */
    public static int minZoom(int cls) {
        switch (cls) {
            case WATER:
            case COAST:
            case MOTORWAY:
            case TRUNK:
            case PRIMARY:
                return 0;
            case PLACE_BIG:
                return 6;
            case SECONDARY:
                return 10;
            case RAIL:
                return 11;
            case WATERWAY:
            case TERTIARY:
            case PLACE_SMALL:
                return 12;
            case MINOR:
                return 14;
            case TRACK:
                return 15;
            case BUILDING:
            case PATH:
                return 16;
            default:
                return 99;
        }
    }

    public static boolean isRoad(int cls) {
        return cls >= MINOR && cls <= MOTORWAY;
    }

    public static boolean isPlace(int cls) {
        return cls >= PLACE_SMALL;
    }
}
