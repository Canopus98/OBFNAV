package dev.obfnav.tools;

import dev.obfnav.core.Geo;

import java.nio.charset.Charset;
import java.util.Arrays;

/**
 * Writes a tiny but structurally faithful OBF (MAP section only) for self-testing the reader.
 * It mirrors the layout that OsmAnd's reader expects: wire-type-6 sections with 4-byte big-endian
 * lengths, delta-coded boxes, blocks addressed by a shift relative to their box.
 */
public final class SyntheticObf {
    private static final Charset UTF8 = Charset.forName("UTF-8");
    private static final int MASK = ~31;

    // ---- rule ids used by the test file
    public static final int R_RESIDENTIAL = 1, R_PRIMARY = 2, R_NAME = 3, R_BUILDING = 4,
            R_TOWN = 5, R_WATER = 6, R_MOTORWAY = 7;

    // ---- expected data, exposed to the test
    public static final class Obj {
        public final long id;
        public final boolean area;
        public final int[] xy;
        public final int[] types;
        public final String name;

        Obj(long id, boolean area, int[] xy, int[] types, String name) {
            this.id = id;
            this.area = area;
            this.xy = xy;
            this.types = types;
            this.name = name;
        }
    }

    /** Writes the synthetic file to the given path, e.g. to try ObfDump or the app without a real map. */
    public static void main(String[] args) throws java.io.IOException {
        if (args.length != 1) {
            System.err.println("usage: SyntheticObf out.obf");
            System.exit(2);
        }
        java.io.FileOutputStream o = new java.io.FileOutputStream(args[0]);
        o.write(new SyntheticObf().build());
        o.close();
        System.out.println("written " + args[0]);
    }

    public int left, right, top, bottom;      // level bounds (31-bit)
    public int midX;                          // split between west and east child
    public Obj[] west, east, root, lowzoom;

    private byte[] a = new byte[1 << 16];
    private int n;

    private void u8(int v) {
        if (n == a.length) a = Arrays.copyOf(a, n * 2);
        a[n++] = (byte) v;
    }

    private void varint(long v) {
        while ((v & ~0x7FL) != 0) {
            u8((int) ((v & 0x7F) | 0x80));
            v >>>= 7;
        }
        u8((int) v);
    }

    private void sint(long v) {
        varint((v << 1) ^ (v >> 63));
    }

    private void tag(int field, int wire) {
        varint(((long) field << 3) | wire);
    }

    private void str(String s) {
        byte[] b = s.getBytes(UTF8);
        varint(b.length);
        for (byte x : b) u8(x);
    }

    private int reserve4() {
        int at = n;
        for (int i = 0; i < 4; i++) u8(0);
        return at;
    }

    private void patch4(int at, int v) {
        a[at] = (byte) (v >>> 24);
        a[at + 1] = (byte) (v >>> 16);
        a[at + 2] = (byte) (v >>> 8);
        a[at + 3] = (byte) v;
    }

    private static int snap(double v) {
        return ((int) v) & MASK;
    }

    private static Obj line(long id, int[] types, String name, double... lonlat) {
        int[] xy = new int[lonlat.length];
        for (int i = 0; i < lonlat.length; i += 2) {
            xy[i] = snap(Geo.lonToX(lonlat[i]));
            xy[i + 1] = snap(Geo.latToY(lonlat[i + 1]));
        }
        return new Obj(id, false, xy, types, name);
    }

    private static Obj poly(long id, int[] types, String name, double... lonlat) {
        Obj o = line(id, types, name, lonlat);
        return new Obj(id, true, o.xy, types, name);
    }

    public byte[] build() {
        // Jakarta-ish area, split into a west and an east child box
        double lonL = 106.70, lonR = 107.00, latT = -6.10, latB = -6.35;
        left = snap(Geo.lonToX(lonL));
        right = snap(Geo.lonToX(lonR));
        top = snap(Geo.latToY(latT));
        bottom = snap(Geo.latToY(latB));
        midX = snap(Geo.lonToX(106.85));

        west = new Obj[]{
                line(1001, new int[]{R_RESIDENTIAL, R_NAME}, "Jalan Satu", 106.78, -6.20, 106.79, -6.21, 106.80, -6.215),
                line(1002, new int[]{R_PRIMARY}, null, 106.72, -6.30, 106.76, -6.25, 106.80, -6.18),
                poly(1003, new int[]{R_BUILDING}, null, 106.760, -6.200, 106.762, -6.200, 106.762, -6.202, 106.760, -6.202),
        };
        east = new Obj[]{
                line(2001, new int[]{R_MOTORWAY, R_NAME}, "Tol Timur", 106.90, -6.15, 106.93, -6.20, 106.97, -6.28),
                poly(2002, new int[]{R_WATER}, "Danau", 106.88, -6.22, 106.90, -6.22, 106.90, -6.24, 106.88, -6.24),
        };
        root = new Obj[]{
                line(3001, new int[]{R_PRIMARY, R_NAME}, "Jalan Tengah", 106.84, -6.19, 106.86, -6.19),
        };
        lowzoom = new Obj[]{
                line(4001, new int[]{R_TOWN, R_NAME}, "Kota Tes", 106.85, -6.22, 106.85, -6.22),
        };

        n = 0;
        // ---------------- top level
        tag(1, 0);
        varint(2); // version
        tag(18, 0);
        varint(1700000000000L); // dateCreated (milliseconds, as in real OBF files)
        tag(6, 6); // MAP section
        int lenAt = reserve4();
        int bodyStart = n;
        writeMapIndex();
        patch4(lenAt, n - bodyStart);

        // Sections the reader must skip, as found in real files after the map section:
        // address index (field 7, 4-byte length)
        tag(7, 6);
        int al = reserve4();
        int as = n;
        for (int i = 0; i < 10; i++) u8(0x55);
        patch4(al, n - as);
        // routing index (field 9) with the 8-byte length form (first byte has the high bit set)
        tag(9, 6);
        u8(0x80);
        u8(0);
        u8(0);
        u8(0);
        u8(0);
        u8(0);
        u8(0);
        u8(12);
        for (int i = 0; i < 12; i++) u8(0x66);
        // owner (field 33, plain length-delimited) and a poi index (field 8)
        tag(33, 2);
        varint(3);
        u8(1);
        u8(2);
        u8(3);
        tag(8, 6);
        int pl = reserve4();
        int ps = n;
        for (int i = 0; i < 7; i++) u8(0x77);
        patch4(pl, n - ps);

        tag(32, 0);
        varint(2); // version confirm
        return Arrays.copyOf(a, n);
    }

    private void rule(int id, String tagName, String value) {
        tag(4, 2);
        int save = n;
        // write body into temp area to know its length
        int bodyStartGuess = n;
        // placeholder one-byte length (bodies are < 128 bytes)
        u8(0);
        int s = n;
        tag(3, 2);
        str(tagName);
        if (value != null) {
            tag(5, 2);
            str(value);
        }
        tag(7, 0);
        varint(id);
        tag(10, 0);
        varint(0);
        int len = n - s;
        if (len >= 128) throw new IllegalStateException("rule too long");
        a[bodyStartGuess] = (byte) len;
    }

    private void writeMapIndex() {
        tag(2, 2);
        str("synthetic-test");
        rule(R_RESIDENTIAL, "highway", "residential");
        rule(R_PRIMARY, "highway", "primary");
        rule(R_NAME, "name", null);
        rule(R_BUILDING, "building", "yes");
        rule(R_TOWN, "place", "town");
        rule(R_WATER, "natural", "water");
        rule(R_MOTORWAY, "highway", "motorway");

        // ---- level 1: zoom 11..22 with a box tree: root(block) -> west(block), east(block)
        tag(5, 6);
        int lvLen = reserve4();
        int lvStart = n;
        tag(1, 0);
        varint(22);
        tag(2, 0);
        varint(11);
        tag(3, 0);
        varint(left);
        tag(4, 0);
        varint(right);
        tag(5, 0);
        varint(top);
        tag(6, 0);
        varint(bottom);

        // root box: same bounds as the level (delta 0)
        tag(7, 6);
        int rootLen = reserve4();
        int rootStart = n;
        tag(1, 0);
        sint(0);
        tag(2, 0);
        sint(0);
        tag(3, 0);
        sint(0);
        tag(4, 0);
        sint(0);
        tag(5, 6);
        int rootShiftAt = reserve4();

        // west child: [left, midX]
        tag(7, 6);
        int wLen = reserve4();
        int wStart = n;
        tag(1, 0);
        sint(0);
        tag(2, 0);
        sint(midX - right);
        tag(3, 0);
        sint(0);
        tag(4, 0);
        sint(0);
        tag(5, 6);
        int wShiftAt = reserve4();
        patch4(wLen, n - wStart);

        // east child: [midX, right]
        tag(7, 6);
        int eLen = reserve4();
        int eStart = n;
        tag(1, 0);
        sint(midX - left);
        tag(2, 0);
        sint(0);
        tag(3, 0);
        sint(0);
        tag(4, 0);
        sint(0);
        tag(5, 6);
        int eShiftAt = reserve4();
        patch4(eLen, n - eStart);

        patch4(rootLen, n - rootStart);

        // blocks (BLOCKS field of the level)
        int pos;
        tag(15, 2);
        pos = n;
        writeBlock(root, 7000000000L, new String[]{"Jalan Tengah"}, new int[]{0});
        patch4(rootShiftAt, pos - rootStart);

        tag(15, 2);
        pos = n;
        writeBlock(west, 1000000L, new String[]{"Jalan Satu"}, new int[]{0, -1, -1}, left);
        patch4(wShiftAt, pos - wStart);

        tag(15, 2);
        pos = n;
        writeBlock(east, 0L, new String[]{"Tol Timur", "Danau"}, new int[]{0, 1}, midX);
        patch4(eShiftAt, pos - eStart);

        patch4(lvLen, n - lvStart);

        // ---- level 2: zoom 6..10, one box with one block
        tag(5, 6);
        int lv2Len = reserve4();
        int lv2Start = n;
        tag(1, 0);
        varint(10);
        tag(2, 0);
        varint(6);
        tag(3, 0);
        varint(left);
        tag(4, 0);
        varint(right);
        tag(5, 0);
        varint(top);
        tag(6, 0);
        varint(bottom);
        tag(7, 6);
        int b2Len = reserve4();
        int b2Start = n;
        tag(1, 0);
        sint(0);
        tag(2, 0);
        sint(0);
        tag(3, 0);
        sint(0);
        tag(4, 0);
        sint(0);
        tag(5, 6);
        int b2Shift = reserve4();
        patch4(b2Len, n - b2Start);
        tag(15, 2);
        pos = n;
        writeBlock(lowzoom, 0L, new String[]{"Kota Tes"}, new int[]{0}, left);
        patch4(b2Shift, pos - b2Start);
        patch4(lv2Len, n - lv2Start);
    }

    private void writeBlock(Obj[] objs, long baseId, String[] strings, int[] nameIdx) {
        writeBlock(objs, baseId, strings, nameIdx, left);
    }

    /** nameIdx[i] = index into strings for object i, or -1; boxLeft anchors coordinate deltas. */
    private void writeBlock(Obj[] objs, long baseId, String[] strings, int[] nameIdx, int boxLeft) {
        // The reader anchors coordinates at (box.left & MASK, box.top & MASK).
        // Every box in this file has top == this.top, so py0 is the same for all boxes.
        int lenPos = n;
        u8(0);
        u8(0); // two-byte varint length placeholder (patched below; blocks are < 16384 bytes)
        int start = n;
        tag(10, 0);
        varint(baseId);
        for (int i = 0; i < objs.length; i++) {
            Obj o = objs[i];
            tag(12, 2);
            int ol = n;
            u8(0);
            u8(0);
            int os = n;
            tag(o.area ? 2 : 1, 2);
            int cl = n;
            u8(0);
            u8(0);
            int cs = n;
            int px = boxLeft & MASK;
            int py = top & MASK;
            for (int k = 0; k < o.xy.length; k += 2) {
                sint((o.xy[k] - px) >> 5);
                sint((o.xy[k + 1] - py) >> 5);
                px = o.xy[k];
                py = o.xy[k + 1];
            }
            patchVar2(cl, n - cs);
            // unknown fields the reader must skip: additionalTypes(6), label(8), inner polygon(4)
            tag(6, 2);
            varint(2);
            varint(1);
            varint(2);
            tag(8, 2);
            varint(2);
            sint(0);
            sint(0);
            tag(4, 2);
            varint(2);
            sint(1);
            sint(1);
            tag(7, 2);
            int tl = n;
            u8(0);
            int ts = n;
            for (int t : o.types) varint(t);
            a[tl] = (byte) (n - ts);
            tag(12, 0);
            sint(o.id - baseId);
            if (nameIdx[i] >= 0) {
                tag(10, 2);
                varint(2);
                varint(R_NAME);
                varint(nameIdx[i]);
            }
            patchVar2(ol, n - os);
        }
        tag(15, 2);
        int tl2 = n;
        u8(0);
        u8(0);
        int ts2 = n;
        for (String s : strings) {
            tag(1, 2);
            str(s);
        }
        patchVar2(tl2, n - ts2);
        patchVar2(lenPos, n - start);
    }

    /** Patches a fixed 2-byte varint (value < 16384). */
    private void patchVar2(int at, int v) {
        if (v >= 16384) throw new IllegalStateException("too long");
        a[at] = (byte) ((v & 0x7F) | 0x80);
        a[at + 1] = (byte) (v >>> 7);
    }
}
