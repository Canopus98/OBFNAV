package dev.obfnav.tools;

import dev.obfnav.core.Coast;

import java.util.ArrayList;
import java.util.List;

public final class CoastTest {
    static int checks;

    static void check(boolean ok, String m) {
        checks++;
        if (!ok) throw new AssertionError("FAILED: " + m);
    }

    static double area(int[] p) {
        double a = 0;
        int n = p.length / 2;
        for (int i = 0, j = n - 1; i < n; j = i++) a += (double) p[2 * j] * p[2 * i + 1] - (double) p[2 * i] * p[2 * j + 1];
        return Math.abs(a) / 2;
    }

    static double total(Coast.Result r) {
        double s = 0;
        for (int[] p : r.land) s += area(p);
        return s;
    }

    static List<int[]> L(int[]... a) {
        List<int[]> l = new ArrayList<int[]>();
        for (int[] x : a) l.add(x);
        return l;
    }

    public static void main(String[] args) {
        int l = 1000, r = 2000, t = 5000, b = 6000; // 1000 x 1000 rect, y down
        double full = 1000.0 * 1000.0;
        // 1. none
        check(!Coast.land(new ArrayList<int[]>(), l, r, t, b).seaMode, "no coast -> not sea mode");
        // 2. coast heading east at mid: land on the left (north = smaller y) => upper half
        Coast.Result a = Coast.land(L(new int[]{0, 5500, 3000, 5500}), l, r, t, b);
        check(a.seaMode && a.land.size() == 1, "east coast one polygon");
        check(Math.abs(total(a) - full / 2) < 1, "east-heading coast: land = upper half, area " + total(a));
        // check which half: all vertices have y <= 5500
        for (int i = 1; i < a.land.get(0).length; i += 2) check(a.land.get(0)[i] <= 5500, "land is north");
        // 3. heading west => land on the left = south (larger y)
        a = Coast.land(L(new int[]{3000, 5500, 0, 5500}), l, r, t, b);
        for (int i = 1; i < a.land.get(0).length; i += 2) check(a.land.get(0)[i] >= 5500, "west-heading: land is south");
        check(Math.abs(total(a) - full / 2) < 1, "west half area");
        // 4. chain split in two features
        a = Coast.land(L(new int[]{0, 5500, 1500, 5500}, new int[]{1500, 5500, 3000, 5500}), l, r, t, b);
        check(a.land.size() == 1 && Math.abs(total(a) - full / 2) < 1, "joined split coastline");
        // 5. coast heading north at x=1500: land on the left = west
        a = Coast.land(L(new int[]{1500, 8000, 1500, 3000}), l, r, t, b);
        check(Math.abs(total(a) - full / 2) < 1, "north-heading half");
        for (int i = 0; i < a.land.get(0).length; i += 2) check(a.land.get(0)[i] <= 1500, "north-heading: land is west");
        // 6. corner cut: enters left edge, leaves top edge, land on the left
        a = Coast.land(L(new int[]{700, 5600, 1600, 4700}), l, r, t, b); // crosses left edge at y=5300, top edge at x=1300
        check(a.seaMode && a.land.size() == 1, "diagonal produces polygon");
        // heading up-right: left side = up-left corner region (small triangle at top-left)
        check(Math.abs(total(a) - 300.0 * 300.0 / 2) < 2, "land is the small top-left triangle, area " + total(a));
        // 7. island ring inside, closed: land inside
        int[] ring = {1200, 5200, 1400, 5200, 1400, 5400, 1200, 5400, 1200, 5200};
        a = Coast.land(L(ring), l, r, t, b);
        check(a.seaMode && a.land.size() == 1 && Math.abs(total(a) - 200.0 * 200.0) < 1, "island ring");
        // 8. rect fully inside a big island (ring surrounds rect)
        int[] big = {0, 4000, 4000, 4000, 4000, 8000, 0, 8000, 0, 4000};
        a = Coast.land(L(big), l, r, t, b);
        check(a.seaMode && a.land.size() == 1 && Math.abs(total(a) - full) < 1, "rect inside island = all land");
        // 9. rect in open sea with an island far away
        int[] far = {10000, 10000, 11000, 10000, 11000, 11000, 10000, 11000, 10000, 10000};
        a = Coast.land(L(far), l, r, t, b);
        check(a.seaMode && a.land.isEmpty(), "all sea");
        // 10. two parallel coasts (a strait / peninsula): land strip between them
        a = Coast.land(L(new int[]{0, 5700, 3000, 5700}, new int[]{3000, 5300, 0, 5300}), l, r, t, b);
        // first heads east at y=5700 (land north), second heads west at y=5300 (land south) => land between 5300..5700
        check(a.land.size() == 1 && Math.abs(total(a) - 1000.0 * 400.0) < 1, "strip area " + total(a));
        System.out.println("COAST TESTS PASSED (" + checks + " checks)");
    }
}
