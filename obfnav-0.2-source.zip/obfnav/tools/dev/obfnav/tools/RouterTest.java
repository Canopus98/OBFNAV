package dev.obfnav.tools;

import dev.obfnav.core.Geo;
import dev.obfnav.core.Route;
import dev.obfnav.core.Router;
import dev.obfnav.core.Style;

import java.util.ArrayList;
import java.util.List;

/** Router tests on hand-built road networks (no OBF file needed). */
public final class RouterTest {
    static int checks;
    static final double LON0 = 106.80, LAT0 = -6.20, STEP = 0.001; // ~111 m

    static void check(boolean ok, String msg) {
        checks++;
        if (!ok) throw new AssertionError("FAILED: " + msg);
    }

    static int X(double i) {
        return (int) Geo.lonToX(LON0 + i * STEP) & ~31;
    }

    static int Y(double j) {
        return (int) Geo.latToY(LAT0 + j * STEP) & ~31; // j up = north
    }

    static int[] way(double... ij) {
        int[] a = new int[ij.length];
        for (int k = 0; k < ij.length; k += 2) {
            a[k] = X(ij[k]);
            a[k + 1] = Y(ij[k + 1]);
        }
        return a;
    }

    static int[] pt(double i, double j) {
        return new int[]{X(i), Y(j)};
    }

    static Router net(int vehicle, boolean avoidToll, boolean shortest) {
        Router.Options o = new Router.Options();
        o.vehicle = vehicle;
        o.avoidToll = avoidToll;
        o.shortest = shortest;
        return new Router(o);
    }

    static List<int[]> pts(int[]... p) {
        List<int[]> l = new ArrayList<int[]>();
        for (int[] x : p) l.add(x);
        return l;
    }

    /** 5x5 grid of two-way residential streets, nodes shared at every crossing. */
    static void grid(Router r, int n) {
        long id = 1;
        for (int k = 0; k < n; k++) {
            double[] h = new double[n * 2], v = new double[n * 2];
            for (int m = 0; m < n; m++) {
                h[2 * m] = m;
                h[2 * m + 1] = k;
                v[2 * m] = k;
                v[2 * m + 1] = m;
            }
            r.addWay(way(h), Style.MINOR, 0, 0, "Jl H" + k, id++);
            r.addWay(way(v), Style.MINOR, 0, 0, "Jl V" + k, id++);
        }
    }

    public static void main(String[] args) throws Exception {
        // ---- 1. grid, one left turn
        {
            Router r = net(Router.CAR, false, true);
            grid(r, 5);
            r.prepare(LAT0);
            Route rt = r.routeThrough(pts(pt(0, 0), pt(4, 4)));
            double manhattan = 8 * STEP * 111320;
            check(Math.abs(rt.length - manhattan) < manhattan * 0.03, "grid length " + rt.length + " vs " + manhattan);
            // shortest path on a grid has exactly one turn if it goes L-shaped; many equal paths exist,
            // so only check structure: arrive is last and turns alternate left/right between 90deg steps
            check(rt.maneuvers.get(rt.maneuvers.size() - 1).type == Route.T_ARRIVE, "ends with arrive");
            System.out.println("grid: " + (int) rt.length + " m, maneuvers=" + rt.maneuvers.size());
        }
        // ---- 2. L-shaped forced route: left turn, distance
        {
            Router r = net(Router.CAR, false, true);
            r.addWay(way(0, 0, 4, 0), Style.MINOR, 0, 0, "Jl Timur", 1);
            r.addWay(way(4, 0, 4, 4), Style.MINOR, 0, 0, "Jl Utara", 2);
            r.prepare(LAT0);
            Route rt = r.routeThrough(pts(pt(0, 0), pt(4, 4)));
            check(rt.maneuvers.size() == 2, "L route maneuvers " + rt.maneuvers.size());
            Route.Maneuver m = rt.maneuvers.get(0);
            check(m.type == Route.T_LEFT, "east then north is a LEFT turn, got " + m.type);
            check("Jl Utara".equals(m.road), "road name after turn " + m.road);
            check(Math.abs(m.at - 4 * STEP * 111320) < 15, "turn at " + m.at);
            // east then south = right
            Router r2 = net(Router.CAR, false, true);
            r2.addWay(way(0, 4, 4, 4), Style.MINOR, 0, 0, "A", 1);
            r2.addWay(way(4, 4, 4, 0), Style.MINOR, 0, 0, "B", 2);
            r2.prepare(LAT0);
            Route rt2 = r2.routeThrough(pts(pt(0, 4), pt(4, 0)));
            check(rt2.maneuvers.get(0).type == Route.T_RIGHT, "east then south is RIGHT, got " + rt2.maneuvers.get(0).type);
        }
        // ---- 3. one-way forces a detour
        {
            Router r = net(Router.CAR, false, true);
            grid(r, 3);
            // replace nothing: build a second network where the middle street is one-way westwards
            Router r2 = net(Router.CAR, false, true);
            r2.addWay(way(0, 0, 2, 0), Style.MINOR, Style.F_ONEWAY_REV, 0, "oneway west", 1); // east->west only
            r2.addWay(way(0, 0, 0, 1, 2, 1, 2, 0), Style.MINOR, 0, 0, "detour", 2);
            r2.prepare(LAT0);
            Route rt = r2.routeThrough(pts(pt(0, 0), pt(2, 0)));
            check(rt.length > 3.5 * STEP * 111320, "one-way detour length " + rt.length);
            Router r3 = net(Router.CAR, false, true);
            r3.addWay(way(0, 0, 2, 0), Style.MINOR, Style.F_ONEWAY_REV, 0, "oneway west", 1);
            r3.prepare(LAT0);
            Route back = r3.routeThrough(pts(pt(2, 0), pt(0, 0)));
            check(Math.abs(back.length - 2 * STEP * 111320) < 10, "against-direction ok in allowed direction");
            try {
                r3.routeThrough(pts(pt(0, 0), pt(2, 0)));
                check(false, "must not route against one-way");
            } catch (Router.RouteException e) {
                check(true, "no route against one-way");
            }
        }
        // ---- 4. toll road: car uses it, avoidToll doesn't, motorcycle never
        {
            for (int mode = 0; mode < 3; mode++) {
                Router r = net(mode == 2 ? Router.MOTO : Router.CAR, mode == 1, false);
                r.addWay(way(0, 0, 4, 4), Style.MOTORWAY, Style.F_ONEWAY, 0, "Jalan Tol Test", 1);
                r.addWay(way(4, 4, 0, 0), Style.MOTORWAY, Style.F_ONEWAY, 0, "Jalan Tol Test", 2);
                r.addWay(way(0, 0, 0, 5, 5, 5, 4, 4), Style.PRIMARY, 0, 0, "Jl Biasa", 3);
                r.prepare(LAT0);
                Route rt = r.routeThrough(pts(pt(0, 0), pt(4, 4)));
                if (mode == 0) check(rt.tollMeters > 500, "car uses toll " + rt.tollMeters);
                else check(rt.tollMeters == 0, "mode " + mode + " avoids toll " + rt.tollMeters);
            }
            // only route is toll: avoidToll falls back with a note, motorcycle fails
            Router r = net(Router.CAR, true, false);
            r.addWay(way(0, 0, 4, 4), Style.MOTORWAY, 0, 0, "Tol", 1);
            r.prepare(LAT0);
            Route rt = r.routeThrough(pts(pt(0, 0), pt(4, 4)));
            check(rt.note != null && rt.tollMeters > 0, "fallback note " + rt.note);
            Router rm = net(Router.MOTO, false, false);
            rm.addWay(way(0, 0, 4, 4), Style.MOTORWAY, 0, 0, "Tol", 1);
            rm.prepare(LAT0);
            try {
                rm.routeThrough(pts(pt(0, 0), pt(4, 4)));
                check(false, "motorcycle on toll-only must fail");
            } catch (Router.RouteException e) {
                check(true, "moto toll-only fails: " + e.getMessage());
            }
            check(Router.class != null && Router.MOTO_BANNED_ON_TOLL, "moto ban constant");
        }
        // ---- 5. fastest vs shortest
        {
            for (int sh = 0; sh < 2; sh++) {
                Router r = net(Router.CAR, false, sh == 1);
                r.addWay(way(0, 0, 4, 0), Style.MINOR, 0, 0, "pendek", 1);                 // 444 m @ 25 km/h
                r.addWay(way(0, 0, 0, 1, 4, 1, 4, 0), Style.PRIMARY, 0, 0, "cepat", 2);    // 666 m @ 50 km/h
                r.prepare(LAT0);
                Route rt = r.routeThrough(pts(pt(0, 0), pt(4, 0)));
                if (sh == 1) check(rt.length < 500, "shortest picks direct: " + rt.length);
                else check(rt.length > 600, "fastest picks primary detour: " + rt.length);
            }
        }
        // ---- 6. roundabout exit count
        {
            Router r = net(Router.CAR, false, false);
            double cx = 4, cy = 4, rad = 0.4;
            // ring of 8 points, counter-clockwise (travel direction), closed
            double[] ring = new double[18];
            for (int k = 0; k <= 8; k++) {
                double a = Math.toRadians(-90 + 45 * k); // start at south, go counter-clockwise (east first)
                ring[2 * k] = cx + rad * Math.cos(a);
                ring[2 * k + 1] = cy + rad * Math.sin(a);
            }
            r.addWay(way(ring), Style.PRIMARY, Style.F_ROUNDABOUT, 0, "Bundaran", 1);
            // arms at ring points: south (k=0), east (k=2), north (k=4), west (k=6)
            r.addWay(way(cx, 0, ring[0], ring[1]), Style.PRIMARY, 0, 0, "Selatan", 2);
            r.addWay(way(ring[4], ring[5], 8, cy), Style.PRIMARY, 0, 0, "Timur", 3);
            r.addWay(way(ring[8], ring[9], cx, 8), Style.PRIMARY, 0, 0, "Utara", 4);
            r.addWay(way(ring[12], ring[13], 0, cy), Style.PRIMARY, 0, 0, "Barat", 5);
            r.prepare(LAT0);
            // enter from south, leave east: first exit after passing none -> exit 1 (east is the first arm CCW)
            Route rt = r.routeThrough(pts(pt(cx, 0.2), pt(7.5, cy)));
            Route.Maneuver rb = null;
            for (Route.Maneuver m : rt.maneuvers) if (m.type == Route.T_ROUNDABOUT) rb = m;
            check(rb != null, "roundabout maneuver present");
            check(rb.exit == 1, "south->east is exit 1, got " + rb.exit);
            check("Timur".equals(rb.road), "exit road " + rb.road);
            Route rt2 = r.routeThrough(pts(pt(cx, 0.2), pt(cx, 7.5)));
            rb = null;
            for (Route.Maneuver m : rt2.maneuvers) if (m.type == Route.T_ROUNDABOUT) rb = m;
            check(rb != null && rb.exit == 2, "south->north is exit 2, got " + (rb == null ? -1 : rb.exit));
            Route rt3 = r.routeThrough(pts(pt(cx, 0.2), pt(0.5, cy)));
            rb = null;
            for (Route.Maneuver m : rt3.maneuvers) if (m.type == Route.T_ROUNDABOUT) rb = m;
            check(rb != null && rb.exit == 3, "south->west is exit 3, got " + (rb == null ? -1 : rb.exit));
        }
        // ---- 7. multi-leg via + tracking
        {
            Router r = net(Router.CAR, false, true);
            r.addWay(way(0, 0, 4, 0), Style.MINOR, 0, 0, "A", 1);
            r.addWay(way(4, 0, 4, 4), Style.MINOR, 0, 0, "B", 2);
            r.addWay(way(4, 4, 0, 4), Style.MINOR, 0, 0, "C", 3);
            r.prepare(LAT0);
            Route rt = r.routeThrough(pts(pt(0, 0), pt(4, 0), pt(0, 4)));
            check(rt.maneuvers.get(rt.maneuvers.size() - 1).type == Route.T_ARRIVE, "last is arrive");
            boolean via = false;
            for (Route.Maneuver m : rt.maneuvers) if (m.type == Route.T_VIA) via = true;
            check(via, "via maneuver present");
            check(Math.abs(rt.length - 12 * STEP * 111320) < 40, "multi-leg length " + rt.length);
            // tracking: a point 20 m off the route half way along the first street
            Route.Fix f = rt.locate(X(2), Y(0) - 20 / rt.mPerUnit, 0);
            check(Math.abs(f.along - 2 * STEP * 111320) < 10, "along " + f.along);
            check(f.off > 15 && f.off < 25, "off " + f.off);
            check(f.toNext > 200 && f.toNext < 250, "to next maneuver " + f.toNext);
            Route.Fix g = rt.locate(X(0), Y(9), 0);
            check(g.off > 500, "far away is off-route: " + g.off);
        }
        // ---- 8. snapping mid-segment with a long way (start and goal not on vertices)
        {
            Router r = net(Router.CAR, false, true);
            r.addWay(way(0, 0, 10, 0), Style.MINOR, 0, 0, "Long", 1);
            r.prepare(LAT0);
            Route rt = r.routeThrough(pts(pt(2.5, 0.05), pt(7.5, -0.05)));
            check(Math.abs(rt.length - 5 * STEP * 111320) < 15, "mid-segment direct " + rt.length);
        }
        // ---- 9. full path through the OBF reader (synthetic file): Jalan Satu, 3 vertices
        {
            dev.obfnav.core.ObfReader rd = new dev.obfnav.core.ObfReader(java.nio.ByteBuffer.wrap(new SyntheticObf().build()));
            Router.Options o = new Router.Options();
            List<int[]> p = pts(new int[]{(int) Geo.lonToX(106.7805), (int) Geo.latToY(-6.2008)},
                    new int[]{(int) Geo.lonToX(106.7995), (int) Geo.latToY(-6.2148)});
            Route rt = Router.route(rd, p, o);
            check(rt.length > 2000 && rt.length < 3500, "OBF route length " + rt.length);
            check(rt.note != null && rt.note.contains("satu arah"), "warns that the map has no oneway info: " + rt.note);
            Route.Maneuver last = rt.maneuvers.get(rt.maneuvers.size() - 1);
            check(last.type == Route.T_ARRIVE, "arrive");
            try {
                Router.route(rd, pts(new int[]{(int) Geo.lonToX(100), (int) Geo.latToY(1)},
                        new int[]{(int) Geo.lonToX(100.01), (int) Geo.latToY(1)}), o);
                check(false, "outside the map must fail");
            } catch (Router.RouteException e) {
                check(true, "outside map: " + e.getMessage());
            }
        }
        System.out.println("ROUTER TESTS PASSED (" + checks + " checks)");
    }
}
