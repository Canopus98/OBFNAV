package dev.obfnav.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Turns natural=coastline lines into land polygons for a rectangle, so the sea can be painted as the
 * background and land on top. OSM convention: land is on the LEFT of the coastline's direction.
 *
 * <p>Open coastlines are clipped to the rectangle, then closed by walking along the rectangle's border
 * (counter-clockwise on screen, y pointing down) from every exit point to the next entry point.
 */
public final class Coast {
    public static final class Result {
        /** true when the coastline data lets us tell sea from land (paint the background as sea). */
        public boolean seaMode;
        public final List<int[]> land = new ArrayList<int[]>();
    }

    private Coast() {
    }

    private static final class Seg {
        int[] pts;
        double entryS, exitS;
        boolean used;
    }

    public static Result land(List<int[]> lines, int l, int r, int t, int b) {
        Result res = new Result();
        if (lines.isEmpty()) return res;
        List<int[]> chains = chain(lines);
        List<Seg> segs = new ArrayList<Seg>();
        double W = r - (double) l, H = b - (double) t;
        for (int[] c : chains) {
            int n = c.length / 2;
            boolean closed = n > 3 && c[0] == c[2 * n - 2] && c[1] == c[2 * n - 1];
            if (closed) {
                int out = -1;
                for (int i = 0; i < n && out < 0; i++) if (!inside(c[2 * i], c[2 * i + 1], l, r, t, b)) out = i;
                if (out < 0) { // ring entirely inside
                    res.seaMode = true;
                    res.land.add(c);
                    continue;
                }
                // rotate so the ring starts at an outside vertex
                int[] rot = new int[c.length];
                int m = n - 1; // distinct vertices
                for (int i = 0; i <= m; i++) {
                    int s = (out + i) % m;
                    rot[2 * i] = c[2 * s];
                    rot[2 * i + 1] = c[2 * s + 1];
                }
                c = rot;
                int before = segs.size();
                clip(c, l, r, t, b, segs);
                if (segs.size() == before) {
                    // ring does not touch the rectangle: is the rectangle inside the island?
                    res.seaMode = true;
                    if (pointInPoly(c, (l + (double) r) / 2, (t + (double) b) / 2)) {
                        res.land.add(new int[]{l, t, r, t, r, b, l, b});
                    }
                }
            } else {
                clip(c, l, r, t, b, segs);
            }
        }
        List<Seg> usable = new ArrayList<Seg>();
        for (Seg s : segs) if (!Double.isNaN(s.entryS) && !Double.isNaN(s.exitS)) usable.add(s);
        if (!usable.isEmpty()) res.seaMode = true;
        double P = 2 * (W + H);
        double[] corners = {0, W, W + H, 2 * W + H};
        int[][] cpos = {{l, t}, {r, t}, {r, b}, {l, b}};
        for (Seg s0 : usable) {
            if (s0.used) continue;
            s0.used = true;
            int[] poly = s0.pts;
            Seg cur = s0;
            boolean ok = false;
            for (int guard = 0; guard <= usable.size(); guard++) {
                Seg next = null;
                double best = Double.MAX_VALUE;
                for (Seg s : usable) {
                    if (s.used && s != s0) continue;
                    double d = mod(cur.exitS - s.entryS, P);
                    if (d < best) {
                        best = d;
                        next = s;
                    }
                }
                if (next == null) break;
                // corners strictly between exit and entry, walking counter-clockwise (decreasing s)
                List<double[]> cs = new ArrayList<double[]>();
                for (int k = 0; k < 4; k++) {
                    double d = mod(cur.exitS - corners[k], P);
                    if (d > 1e-6 && d < best - 1e-6) cs.add(new double[]{d, k});
                }
                java.util.Collections.sort(cs, new java.util.Comparator<double[]>() {
                    @Override
                    public int compare(double[] x, double[] y) {
                        return Double.compare(x[0], y[0]);
                    }
                });
                int add = cs.size() * 2;
                poly = Arrays.copyOf(poly, poly.length + add);
                int o = poly.length - add;
                for (double[] cc : cs) {
                    poly[o++] = cpos[(int) cc[1]][0];
                    poly[o++] = cpos[(int) cc[1]][1];
                }
                if (next == s0) {
                    ok = true;
                    break;
                }
                next.used = true;
                int[] q = new int[poly.length + next.pts.length];
                System.arraycopy(poly, 0, q, 0, poly.length);
                System.arraycopy(next.pts, 0, q, poly.length, next.pts.length);
                poly = q;
                cur = next;
            }
            if (ok) res.land.add(poly);
        }
        return res;
    }

    private static double mod(double a, double p) {
        a %= p;
        if (a < 0) a += p;
        return a;
    }

    private static boolean inside(double x, double y, int l, int r, int t, int b) {
        return x >= l && x <= r && y >= t && y <= b;
    }

    private static boolean pointInPoly(int[] p, double x, double y) {
        boolean in = false;
        int n = p.length / 2;
        for (int i = 0, j = n - 1; i < n; j = i++) {
            double xi = p[2 * i], yi = p[2 * i + 1], xj = p[2 * j], yj = p[2 * j + 1];
            if ((yi > y) != (yj > y) && x < (xj - xi) * (y - yi) / (yj - yi) + xi) in = !in;
        }
        return in;
    }

    // ---------------------------------------------------------------- chaining

    private static long key(int x, int y) {
        return ((long) x << 32) | (y & 0xFFFFFFFFL);
    }

    private static List<int[]> chain(List<int[]> lines) {
        int n = lines.size();
        Map<Long, Integer> byStart = new HashMap<Long, Integer>();
        Map<Long, Integer> byEnd = new HashMap<Long, Integer>();
        for (int i = 0; i < n; i++) {
            int[] a = lines.get(i);
            if (a.length < 4) continue;
            byStart.put(key(a[0], a[1]), i);
            byEnd.put(key(a[a.length - 2], a[a.length - 1]), i);
        }
        boolean[] used = new boolean[n];
        List<int[]> out = new ArrayList<int[]>();
        for (int i = 0; i < n; i++) {
            if (used[i] || lines.get(i).length < 4) continue;
            // walk back to the start of the chain
            int first = i;
            int guard = 0;
            while (guard++ < n) {
                int[] a = lines.get(first);
                Integer p = byEnd.get(key(a[0], a[1]));
                if (p == null || p == first || used[p]) break;
                if (p == i) break; // closed loop
                first = p;
            }
            List<int[]> parts = new ArrayList<int[]>();
            int cur = first;
            guard = 0;
            while (guard++ <= n) {
                used[cur] = true;
                parts.add(lines.get(cur));
                int[] a = lines.get(cur);
                Integer nx = byStart.get(key(a[a.length - 2], a[a.length - 1]));
                if (nx == null || used[nx]) break;
                cur = nx;
            }
            int total = 0;
            for (int[] p : parts) total += p.length;
            int[] c = new int[total - 2 * (parts.size() - 1)];
            int o = 0;
            for (int k = 0; k < parts.size(); k++) {
                int[] p = parts.get(k);
                int from = k == 0 ? 0 : 2;
                System.arraycopy(p, from, c, o, p.length - from);
                o += p.length - from;
            }
            out.add(c);
        }
        return out;
    }

    // ---------------------------------------------------------------- clipping

    private static void clip(int[] c, int l, int r, int t, int b, List<Seg> out) {
        int n = c.length / 2;
        List<int[]> cur = null;
        double entry = Double.NaN;
        for (int i = 0; i + 1 < n; i++) {
            double px = c[2 * i], py = c[2 * i + 1], qx = c[2 * i + 2], qy = c[2 * i + 3];
            double dx = qx - px, dy = qy - py;
            double t0 = 0, t1 = 1;
            double[] pp = {-dx, dx, -dy, dy};
            double[] qq = {px - l, r - px, py - t, b - py};
            boolean hit = true;
            for (int k = 0; k < 4 && hit; k++) {
                if (pp[k] == 0) {
                    if (qq[k] < 0) hit = false;
                } else {
                    double u = qq[k] / pp[k];
                    if (pp[k] < 0) {
                        if (u > t1) hit = false;
                        else if (u > t0) t0 = u;
                    } else {
                        if (u < t0) hit = false;
                        else if (u < t1) t1 = u;
                    }
                }
            }
            if (!hit || t1 - t0 < 1e-12) {
                continue;
            }
            boolean pIn = t0 <= 0;
            boolean qIn = t1 >= 1;
            if (cur == null) {
                cur = new ArrayList<int[]>();
                if (pIn) {
                    cur.add(new int[]{(int) px, (int) py});
                    entry = Double.NaN; // chain starts inside: open end
                } else {
                    int[] e = clamp(px + t0 * dx, py + t0 * dy, l, r, t, b);
                    cur.add(e);
                    entry = param(e[0], e[1], l, r, t, b);
                }
            }
            if (qIn) {
                cur.add(new int[]{(int) qx, (int) qy});
            } else {
                int[] x = clamp(px + t1 * dx, py + t1 * dy, l, r, t, b);
                cur.add(x);
                emit(cur, entry, param(x[0], x[1], l, r, t, b), out);
                cur = null;
            }
        }
        if (cur != null) emit(cur, entry, Double.NaN, out);
    }

    private static void emit(List<int[]> pts, double entry, double exit, List<Seg> out) {
        Seg s = new Seg();
        s.pts = new int[pts.size() * 2];
        for (int i = 0; i < pts.size(); i++) {
            s.pts[2 * i] = pts.get(i)[0];
            s.pts[2 * i + 1] = pts.get(i)[1];
        }
        s.entryS = entry;
        s.exitS = exit;
        out.add(s);
    }

    private static int[] clamp(double x, double y, int l, int r, int t, int b) {
        return new int[]{(int) Math.max(l, Math.min(r, Math.round(x))), (int) Math.max(t, Math.min(b, Math.round(y)))};
    }

    /** Position along the rectangle border, increasing clockwise (on screen) from the top-left corner. */
    static double param(int x, int y, int l, int r, int t, int b) {
        double W = r - (double) l, H = b - (double) t;
        double dTop = Math.abs(y - t), dRight = Math.abs(x - r), dBottom = Math.abs(y - b), dLeft = Math.abs(x - l);
        double m = Math.min(Math.min(dTop, dRight), Math.min(dBottom, dLeft));
        if (m == dTop) return x - l;
        if (m == dRight) return W + (y - t);
        if (m == dBottom) return W + H + (r - x);
        return 2 * W + H + (b - y);
    }
}
