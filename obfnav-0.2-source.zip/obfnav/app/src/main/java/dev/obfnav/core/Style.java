package dev.obfnav.core;

/**
 * Tiny rule table: maps OSM tag=value pairs (decoded from the OBF rule table) to a drawing class.
 * Higher class number wins when an object carries several matching tags.
 */
public final class Style {
    public static final int NONE = 0;
    public static final int WATER = 1;      // water polygons
    public static final int COAST = 2;      // natural=coastline
    public static final int WATERWAY = 3;   // rivers, streams, canals
    public static final int BUILDING = 4;
    public static final int RAIL = 5;
    public static final int PATH = 6;       // footway, path, cycleway, steps
    public static final int TRACK = 7;
    public static final int MINOR = 8;      // residential, service, unclassified
    public static final int TERTIARY = 9;
    public static final int SECONDARY = 10;
    public static final int PRIMARY = 11;
    public static final int TRUNK = 12;
    public static final int MOTORWAY = 13;
    public static final int PLACE_SMALL = 20; // village, suburb, hamlet...
    public static final int PLACE_BIG = 21;   // city, town

    private Style() {
    }

    public static int[] buildRuleClasses(ObfReader.MapIndex mi) {
        int[] c = new int[mi.rules.length];
        for (int i = 0; i < c.length; i++) {
            ObfReader.Rule r = mi.rules[i];
            c[i] = r == null ? NONE : classify(r.tag, r.value);
        }
        return c;
    }

    public static int classOf(int[] ruleClass, int[] types) {
        int best = NONE;
        for (int t : types) {
            if (t >= 0 && t < ruleClass.length && ruleClass[t] > best) best = ruleClass[t];
        }
        return best;
    }

    public static int classify(String tag, String v) {
        if (tag == null) return NONE;
        if (v == null) v = "";
        if (tag.equals("highway")) {
            if (v.startsWith("motorway")) return MOTORWAY;
            if (v.startsWith("trunk")) return TRUNK;
            if (v.startsWith("primary")) return PRIMARY;
            if (v.startsWith("secondary")) return SECONDARY;
            if (v.startsWith("tertiary")) return TERTIARY;
            if (v.equals("residential") || v.equals("unclassified") || v.equals("living_street")
                    || v.equals("service") || v.equals("road")) return MINOR;
            if (v.equals("track")) return TRACK;
            if (v.equals("footway") || v.equals("path") || v.equals("cycleway") || v.equals("steps")
                    || v.equals("pedestrian") || v.equals("bridleway")) return PATH;
            return NONE;
        }
        if (tag.equals("building")) return v.equals("no") ? NONE : BUILDING;
        if (tag.equals("natural")) {
            if (v.equals("water") || v.equals("bay")) return WATER;
            if (v.equals("coastline")) return COAST;
            return NONE;
        }
        if (tag.equals("waterway")) {
            if (v.equals("riverbank") || v.equals("dock")) return WATER;
            if (v.equals("river") || v.equals("stream") || v.equals("canal") || v.equals("drain")
                    || v.equals("ditch")) return WATERWAY;
            return NONE;
        }
        if (tag.equals("landuse") && (v.equals("reservoir") || v.equals("basin"))) return WATER;
        if (tag.equals("railway")) {
            if (v.equals("rail") || v.equals("light_rail") || v.equals("narrow_gauge")
                    || v.equals("tram") || v.equals("subway")) return RAIL;
            return NONE;
        }
        if (tag.equals("place")) {
            if (v.equals("city") || v.equals("town")) return PLACE_BIG;
            if (v.equals("village") || v.equals("suburb") || v.equals("hamlet")
                    || v.equals("neighbourhood") || v.equals("quarter")) return PLACE_SMALL;
            return NONE;
        }
        return NONE;
    }

    // ---- road attribute flags (decoded from OBF rules; see buildRuleFlags)
    public static final int F_ONEWAY = 1, F_ONEWAY_REV = 2, F_ONEWAY_NO = 4, F_ROUNDABOUT = 8,
            F_TOLL = 16, F_NOTOLL = 32, F_NOCAR = 64, F_NOMOTO = 128, F_CARYES = 256, F_MOTOYES = 512;

    /** Per-rule attribute flags and max speeds, indexed like {@link ObfReader.MapIndex#rules}. */
    public static int[] buildRuleFlags(ObfReader.MapIndex mi) {
        int[] c = new int[mi.rules.length];
        for (int i = 0; i < c.length; i++) {
            ObfReader.Rule r = mi.rules[i];
            c[i] = r == null ? 0 : flagsOf(r.tag, r.value);
        }
        return c;
    }

    /** Max speed in km/h per rule (0 = none). */
    public static int[] buildRuleSpeeds(ObfReader.MapIndex mi) {
        int[] c = new int[mi.rules.length];
        for (int i = 0; i < c.length; i++) {
            ObfReader.Rule r = mi.rules[i];
            if (r == null || !"maxspeed".equals(r.tag) || r.value == null) continue;
            int v = 0;
            boolean any = false;
            for (int k = 0; k < r.value.length(); k++) {
                char ch = r.value.charAt(k);
                if (ch >= '0' && ch <= '9') {
                    v = v * 10 + (ch - '0');
                    any = true;
                    if (v > 300) break;
                } else if (any) break;
            }
            if (any && v >= 5 && v <= 200) c[i] = v;
        }
        return c;
    }

    public static boolean hasRuleTag(ObfReader.MapIndex mi, String tag) {
        for (ObfReader.Rule r : mi.rules) if (r != null && tag.equals(r.tag)) return true;
        return false;
    }

    public static int flagsOf(String tag, String v) {
        if (tag == null) return 0;
        if (v == null) v = "";
        boolean no = v.equals("no") || v.equals("private") || v.equals("false");
        boolean yes = v.equals("yes") || v.equals("designated") || v.equals("permissive");
        switch (tag) {
            case "oneway":
                if (v.equals("yes") || v.equals("true") || v.equals("1")) return F_ONEWAY;
                if (v.equals("-1") || v.equals("reverse")) return F_ONEWAY_REV;
                if (v.equals("no") || v.equals("false") || v.equals("0")) return F_ONEWAY_NO;
                return 0;
            case "junction":
                return v.equals("roundabout") ? F_ROUNDABOUT : 0;
            case "toll":
                return v.equals("yes") || v.equals("true") ? F_TOLL : (v.equals("no") ? F_NOTOLL : 0);
            case "access":
            case "vehicle":
            case "motor_vehicle":
                if (no) return F_NOCAR | F_NOMOTO;
                return 0;
            case "motorcar":
                return no ? F_NOCAR : (yes ? F_CARYES : 0);
            case "motorcycle":
                return no ? F_NOMOTO : (yes ? F_MOTOYES : 0);
            default:
                return 0;
        }
    }

    /** True for a road class that vehicles use (tracks included). */
    public static boolean isVehicleRoad(int cls) {
        return cls >= TRACK && cls <= MOTORWAY;
    }

    /**
     * Toll road test shared by the renderer and the router: explicit toll=yes, any motorway not marked
     * toll=no (in Indonesia every motorway is a toll road), or a name containing the word "Tol"/"Toll".
     */
    public static boolean isToll(int cls, int flags, String name) {
        if (!isVehicleRoad(cls)) return false;
        if ((flags & F_TOLL) != 0) return true;
        if ((flags & F_NOTOLL) != 0) return false;
        return cls == MOTORWAY || nameIsToll(name);
    }

    public static boolean nameIsToll(String name) {
        if (name == null) return false;
        int i = 0, n = name.length();
        while (i < n) {
            while (i < n && !Character.isLetter(name.charAt(i))) i++;
            int s = i;
            while (i < n && Character.isLetter(name.charAt(i))) i++;
            int len = i - s;
            if ((len == 3 && name.regionMatches(true, s, "tol", 0, 3))
                    || (len == 4 && name.regionMatches(true, s, "toll", 0, 4))) return true;
        }
        return false;
    }

    /** Lowest zoom at which a class is drawn (keeps low zoom levels fast and uncluttered). */
    public static int minZoom(int cls) {
        switch (cls) {
            case WATER:
            case COAST:
            case MOTORWAY:
            case TRUNK:
            case PRIMARY:
                return 0;
            case PLACE_BIG:
                return 6;
            case SECONDARY:
                return 10;
            case RAIL:
                return 11;
            case WATERWAY:
            case TERTIARY:
            case PLACE_SMALL:
                return 12;
            case MINOR:
                return 14;
            case TRACK:
                return 15;
            case BUILDING:
            case PATH:
                return 16;
            default:
                return 99;
        }
    }

    public static boolean isRoad(int cls) {
        return cls >= MINOR && cls <= MOTORWAY;
    }

    public static boolean isPlace(int cls) {
        return cls >= PLACE_SMALL;
    }
}
