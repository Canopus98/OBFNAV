package dev.obfnav;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import android.speech.tts.TextToSpeech;
import android.view.WindowManager;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.util.Locale;

import dev.obfnav.core.ObfReader;

/** Single-screen host: file picking (Storage Access Framework), GPS and view-state persistence. */
public final class MainActivity extends Activity implements MapView.Host, LocationListener {
    private static final int REQ_OPEN = 1;
    private static final int REQ_LOCATION = 2;
    private static final String PREFS = "obfnav";

    private MapView map;
    private SharedPreferences prefs;
    private boolean wantGps;
    private boolean gpsRunning;
    private TextToSpeech tts;
    private boolean ttsReady;
    private boolean ttsWarned;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        map = new MapView(this);
        map.setHost(this);
        setContentView(map);
        map.requestFocus();

        map.setCenter(Double.longBitsToDouble(prefs.getLong("lat", Double.doubleToLongBits(-6.2088))),
                Double.longBitsToDouble(prefs.getLong("lon", Double.doubleToLongBits(106.8456))));
        map.setZoom(prefs.getInt("zoom", 14));
        map.setInverted(prefs.getBoolean("inv", false));
        loadNavState();
        initTts();

        String saved = prefs.getString("uri", null);
        if (saved != null) openMap(Uri.parse(saved));
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (wantGps) startGps();
    }

    @Override
    protected void onPause() {
        super.onPause();
        stopGpsUpdates();
        prefs.edit()
                .putLong("lat", Double.doubleToLongBits(map.getCenterLat()))
                .putLong("lon", Double.doubleToLongBits(map.getCenterLon()))
                .putInt("zoom", map.getZoom())
                .putBoolean("inv", map.isInverted())
                .apply();
        saveNavState();
    }

    // ------------------------------------------------------------------ persisted navigation state

    private void loadNavState() {
        map.setOptions(new int[]{prefs.getInt("o_veh", 0), prefs.getInt("o_short", 0), prefs.getInt("o_toll", 0),
                prefs.getInt("o_voice", 1), prefs.getInt("o_names", 1)});
        map.setWaypointsData(prefs.getString("waypoints", ""));
    }

    private void saveNavState() {
        int[] o = map.getOptions();
        prefs.edit()
                .putInt("o_veh", o[0]).putInt("o_short", o[1]).putInt("o_toll", o[2])
                .putInt("o_voice", o[3]).putInt("o_names", o[4])
                .putBoolean("inv", map.isInverted())
                .putString("waypoints", map.getWaypointsData())
                .apply();
    }

    @Override
    public void onStateChanged() {
        saveNavState();
    }

    // ------------------------------------------------------------------ voice

    private void initTts() {
        try {
            tts = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
                @Override
                public void onInit(int status) {
                    if (status != TextToSpeech.SUCCESS || tts == null) return;
                    int r = tts.setLanguage(new Locale("id", "ID"));
                    ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED;
                }
            });
        } catch (Exception e) {
            tts = null; // no TTS engine: visual instructions only
        }
    }

    @Override
    public void onSpeak(String text) {
        if (tts == null) return;
        if (!ttsReady) {
            if (!ttsWarned) {
                ttsWarned = true;
                map.setStatus("Suara Indonesia belum terpasang di HP (cek pengaturan Text-to-speech)");
            }
            return;
        }
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "nav");
    }

    @Override
    public void onNeedGps() {
        if (!wantGps) {
            wantGps = true;
            startGps();
        }
        map.setFollowGps(true);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (tts != null) tts.shutdown();
        map.close();
    }

    // ------------------------------------------------------------------ file picking

    @Override
    public void onOpenRequest() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try {
            startActivityForResult(i, REQ_OPEN);
        } catch (Exception e) {
            map.setStatus("Tidak ada pemilih file di perangkat ini");
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_OPEN || res != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) {
            // some providers do not support persistable grants; the file just will not auto-reopen
        }
        prefs.edit().putString("uri", uri.toString()).apply();
        openMap(uri);
    }

    private String displayName(Uri uri) {
        Cursor c = null;
        try {
            c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null);
            if (c != null && c.moveToFirst()) return c.getString(0);
        } catch (Exception ignored) {
            // fall through
        } finally {
            if (c != null) c.close();
        }
        String p = uri.getLastPathSegment();
        return p == null ? "map.obf" : p;
    }

    private void openMap(final Uri uri) {
        map.setStatus("Membuka peta...");
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    final String name = displayName(uri);
                    ParcelFileDescriptor pfd = getContentResolver().openFileDescriptor(uri, "r");
                    if (pfd == null) throw new IOException("file tidak bisa dibuka");
                    final ObfReader reader;
                    try {
                        FileInputStream in = new FileInputStream(pfd.getFileDescriptor());
                        FileChannel ch = in.getChannel();
                        long size = ch.size();
                        if (size > Integer.MAX_VALUE) throw new IOException("file > 2 GB belum didukung");
                        MappedByteBuffer mb = ch.map(FileChannel.MapMode.READ_ONLY, 0, size);
                        reader = new ObfReader(mb); // the mapping stays valid after the descriptor is closed
                    } finally {
                        pfd.close();
                    }
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            map.setReader(reader, name);
                            map.setStatus(reader.getMaps().isEmpty() ? "File ini tidak berisi data peta" : "");
                        }
                    });
                } catch (final Exception e) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            map.setStatus("GAGAL: " + e.getMessage());
                        }
                    });
                }
            }
        }, "obf-open").start();
    }

    // ------------------------------------------------------------------ GPS

    @Override
    public void onGpsToggle() {
        if (!wantGps) {
            wantGps = true;
            startGps();
            map.setFollowGps(true);
        } else if (map.isFollowGps()) {
            wantGps = false;
            stopGpsUpdates();
            map.setGps(false, 0, 0, Float.NaN, 0f);
            map.setFollowGps(false);
            map.setStatus("");
        } else {
            map.setFollowGps(true);
        }
    }

    private boolean hasLocationPermission() {
        return Build.VERSION.SDK_INT < 23
                || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void startGps() {
        if (!hasLocationPermission()) {
            if (Build.VERSION.SDK_INT >= 23) {
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQ_LOCATION);
            }
            return;
        }
        if (gpsRunning) return;
        LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (lm == null || !lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            map.setStatus("GPS mati. Aktifkan lokasi di pengaturan.");
            return;
        }
        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, this);
            gpsRunning = true;
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            map.setStatus("Mencari sinyal GPS...");
            Location last = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (last != null) onLocationChanged(last);
        } catch (SecurityException e) {
            map.setStatus("Izin lokasi ditolak");
        }
    }

    private void stopGpsUpdates() {
        if (!gpsRunning) return;
        LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (lm != null) lm.removeUpdates(this);
        gpsRunning = false;
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == REQ_LOCATION) {
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) {
                startGps();
            } else {
                wantGps = false;
                map.setFollowGps(false);
                map.setStatus("Izin lokasi ditolak");
            }
        }
    }

    @Override
    public void onLocationChanged(Location l) {
        float brg = l.hasBearing() && l.getSpeed() > 1.0f ? l.getBearing() : Float.NaN;
        map.setGps(true, l.getLatitude(), l.getLongitude(), brg, l.getAccuracy());
        if (map.getRouteStatusFree()) map.setStatus("GPS " + (int) l.getAccuracy() + " m");
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
    }

    @Override
    public void onProviderEnabled(String provider) {
    }

    @Override
    public void onProviderDisabled(String provider) {
        map.setStatus("GPS dimatikan");
    }

    @Override
    public void onQuit() {
        finish();
    }
}
