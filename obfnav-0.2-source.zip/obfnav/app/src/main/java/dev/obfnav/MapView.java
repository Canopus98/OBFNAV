package dev.obfnav;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

import dev.obfnav.core.Coast;
import dev.obfnav.core.Feature;
import dev.obfnav.core.Geo;
import dev.obfnav.core.ObfReader;
import dev.obfnav.core.Route;
import dev.obfnav.core.Router;
import dev.obfnav.core.Style;

/**
 * Vector map view in the style of an old handheld GPS: flat colours, no bitmaps, no animation. It
 * redraws only on input or when the worker thread has new data.
 */
public final class MapView extends View {

    public interface Host {
        void onOpenRequest();

        void onGpsToggle();

        /** Start GPS (if not running) and follow it; used when navigation needs a position. */
        void onNeedGps();

        void onQuit();

        void onSpeak(String text);

        /** Waypoints or options changed; the host should persist them. */
        void onStateChanged();
    }

    private static final int MAX_FEATURES = 60000;
    private static final int MIN_ZOOM = 1;
    private static final int MAX_ZOOM = 22;
    private static final int KEY_TOLL = 50; // draw-order / style key for toll roads (above every class)

    private static final class Loaded {
        List<Feature> feats;
        Coast.Result coast;
        int left, right, top, bottom;
        int zoom;
        boolean truncated;
    }

    private static final class Button {
        final String label;
        final int id;
        final RectF r = new RectF();

        Button(String label, int id) {
            this.label = label;
            this.id = id;
        }
    }

    private static final class Waypoint {
        String name;
        double lat, lon;
    }

    private static final class Item {
        final String label;
        final String hint;
        final int id;
        final boolean enabled;

        Item(String label, String hint, int id, boolean enabled) {
            this.label = label;
            this.hint = hint;
            this.id = id;
            this.enabled = enabled;
        }
    }

    // button ids
    private static final int B_OUT = 0, B_IN = 1, B_MENU = 2, B_ROUTE = 3, B_WP = 4, B_GPS = 5, B_CLOSE = 6;
    // panels
    private static final int P_NONE = 0, P_MENU = 1, P_ROUTE = 2, P_WP = 3, P_WPACT = 4;
    // item ids
    private static final int M_OPEN = 100, M_THEME = 101, M_NAMES = 102, M_VOICE = 103, M_QUIT = 104;
    private static final int R_VEH = 200, R_MODE = 201, R_TOLL = 202, R_GO = 203, R_ADD = 204,
            R_ORIGIN = 205, R_CLEAR = 206, R_INFO = 207;
    private static final int W_SAVE_C = 300, W_SAVE_G = 301, W_EMPTY = 302;
    private static final int WA_GO = 400, WA_ADD = 401, WA_SHOW = 402, WA_DEL = 403, WA_BACK = 404;
    private static final int W_ITEM = 1000;

    private Host host;
    private ObfReader reader;
    private int[][] ruleClasses;
    private int[][] ruleFlags;
    private String fileName = "";
    private String status = "";

    private double cx = Geo.lonToX(106.8456), cy = Geo.latToY(-6.2088);
    private int zoom = 14;
    private int minZoom = MIN_ZOOM, maxZoom = MAX_ZOOM;
    private boolean inverted;
    private boolean showNames = true;
    private String info = "";

    private boolean hasGps;
    private double gpsLat, gpsLon;
    private float gpsBearing = Float.NaN;
    private float gpsAccuracy;
    private boolean followGps;

    // ---- navigation state
    private int optVehicle = Router.CAR;
    private boolean optShortest;
    private boolean optAvoidToll;
    private boolean optVoice = true;
    private int[] manualOrigin;
    private final List<int[]> plan = new ArrayList<int[]>();
    private int planBase;
    private Route route;
    private Route.Fix fix;
    private int lastSeg;
    private int offCount;
    private int[] announced = new int[0];
    private int routeGen;
    private boolean routing;
    private boolean waitingGps;
    private final List<Waypoint> waypoints = new ArrayList<Waypoint>();

    // ---- panels
    private int panel = P_NONE;
    private final List<Item> items = new ArrayList<Item>();
    private float panelScroll;
    private int panelSel;
    private int wpSel = -1;
    private String panelTitle = "";

    private volatile Loaded loaded;
    private final Object lock = new Object();
    private boolean pending;
    private int rl, rr, rt, rb, rz;
    private Thread worker;
    private boolean closed;

    // ---- palette
    private int cLand, cWater, cWaterDark, cRoad, cToll, cText, cBox, cBuilding, cRail, cRoute, cWp, cGps;

    private final float density;
    private final float sp;
    private final float px1;
    private final Paint line = new Paint();
    private final Paint fill = new Paint();
    private final Paint text = new Paint();
    private final Paint big = new Paint();
    private final Paint huge = new Paint();
    private final Path path = new Path();
    private final Button[] mainButtons = {
            new Button("MENU", B_MENU), new Button("RUTE", B_ROUTE), new Button("WP", B_WP), new Button("GPS", B_GPS)};
    private final Button zoomIn = new Button("+", B_IN);
    private final Button zoomOut = new Button("-", B_OUT);
    private final Button closeBtn = new Button("TUTUP", B_CLOSE);
    private final List<float[]> labelRects = new ArrayList<float[]>();
    private float downX, downY, lastX, lastY;
    private boolean dragged;
    private float panelTop, panelBottom;

    public MapView(Context ctx) {
        super(ctx);
        density = ctx.getResources().getDisplayMetrics().density;
        sp = ctx.getResources().getDisplayMetrics().scaledDensity;
        px1 = Math.max(1f, Math.round(density * 0.75f));
        setFocusable(true);
        setFocusableInTouchMode(true);
        line.setAntiAlias(false);
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeCap(Paint.Cap.BUTT);
        line.setStrokeJoin(Paint.Join.MITER);
        fill.setAntiAlias(false);
        fill.setStyle(Paint.Style.FILL);
        Typeface mono = Typeface.MONOSPACE;
        Typeface monoBold = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD);
        text.setAntiAlias(false);
        text.setTypeface(mono);
        text.setTextSize(14f * sp);
        big.setAntiAlias(false);
        big.setTypeface(monoBold);
        big.setTextSize(20f * sp);
        huge.setAntiAlias(false);
        huge.setTypeface(monoBold);
        huge.setTextSize(34f * sp);
        applyPalette();
        startWorker();
    }

    // ------------------------------------------------------------------ palette

    /** Few flat colours, high contrast. Water blue, land green, toll roads dark red. */
    private void applyPalette() {
        if (!inverted) {
            cLand = 0xFFA9DC91;
            cWater = 0xFF3F86F0;
            cWaterDark = 0xFF14429E;
            cRoad = 0xFF000000;
            cToll = 0xFF8B0000;
            cText = 0xFF000000;
            cBox = 0xFFFFFFFF;
            cBuilding = 0xFF4F6B45;
            cRail = 0xFF303030;
            cRoute = 0xFFE000C8;
            cWp = 0xFFFFE000;
            cGps = 0xFF0028D8;
        } else {
            cLand = 0xFF123D1C;
            cWater = 0xFF1B3FA8;
            cWaterDark = 0xFF5C8CFF;
            cRoad = 0xFFFFFFFF;
            cToll = 0xFFD03030;
            cText = 0xFFFFFFFF;
            cBox = 0xFF000000;
            cBuilding = 0xFF7FA07A;
            cRail = 0xFFD0D0D0;
            cRoute = 0xFFFF4DFF;
            cWp = 0xFFFFE000;
            cGps = 0xFF00E5FF;
        }
    }

    // ------------------------------------------------------------------ public state API

    public void setHost(Host h) {
        host = h;
    }

    public void setStatus(String s) {
        status = s;
        postInvalidate();
    }

    public boolean isInverted() {
        return inverted;
    }

    public void setInverted(boolean v) {
        inverted = v;
        applyPalette();
        postInvalidate();
    }

    public int getZoom() {
        return zoom;
    }

    public void setZoom(int z) {
        zoom = Math.max(minZoom, Math.min(maxZoom, z));
        postInvalidate();
    }

    public double getCenterLat() {
        return Geo.yToLat(cy);
    }

    public double getCenterLon() {
        return Geo.xToLon(cx);
    }

    public void setCenter(double lat, double lon) {
        cx = Geo.lonToX(lon);
        cy = Geo.latToY(lat);
        postInvalidate();
    }

    /** Called from the location callback (UI thread). Bearing is NaN when unknown. */
    public void setGps(boolean has, double lat, double lon, float bearing, float accuracy) {
        hasGps = has;
        gpsLat = lat;
        gpsLon = lon;
        gpsBearing = bearing;
        gpsAccuracy = accuracy;
        if (has && followGps) {
            cx = Geo.lonToX(lon);
            cy = Geo.latToY(lat);
        }
        if (has && waitingGps && manualOrigin == null && !plan.isEmpty() && !routing) {
            waitingGps = false;
            requestRoute(false);
        }
        if (has) trackRoute();
        postInvalidate();
    }

    /** True when no route is shown, so the host may write GPS accuracy into the status line. */
    public boolean getRouteStatusFree() {
        return route == null && !routing;
    }

    public boolean isFollowGps() {
        return followGps;
    }

    public void setFollowGps(boolean f) {
        followGps = f;
        if (f && hasGps) {
            cx = Geo.lonToX(gpsLon);
            cy = Geo.latToY(gpsLat);
        }
        postInvalidate();
    }

    /** Navigation options, in the order: vehicle, shortest(0/1), avoidToll(0/1), voice(0/1), names(0/1). */
    public int[] getOptions() {
        return new int[]{optVehicle, optShortest ? 1 : 0, optAvoidToll ? 1 : 0, optVoice ? 1 : 0, showNames ? 1 : 0};
    }

    public void setOptions(int[] o) {
        if (o == null || o.length < 5) return;
        optVehicle = o[0] == Router.MOTO ? Router.MOTO : Router.CAR;
        optShortest = o[1] != 0;
        optAvoidToll = o[2] != 0;
        optVoice = o[3] != 0;
        showNames = o[4] != 0;
    }

    /** One waypoint per line: lat,lon,name */
    public String getWaypointsData() {
        StringBuilder sb = new StringBuilder();
        for (Waypoint w : waypoints) {
            sb.append(String.format(Locale.US, "%.6f,%.6f,%s\n", w.lat, w.lon, w.name));
        }
        return sb.toString();
    }

    public void setWaypointsData(String data) {
        waypoints.clear();
        if (data == null) return;
        for (String ln : data.split("\n")) {
            String[] p = ln.split(",", 3);
            if (p.length < 3) continue;
            try {
                Waypoint w = new Waypoint();
                w.lat = Double.parseDouble(p[0]);
                w.lon = Double.parseDouble(p[1]);
                w.name = p[2];
                waypoints.add(w);
            } catch (NumberFormatException ignored) {
                // skip a damaged line
            }
        }
    }

    /** Installs a new map file; the view jumps to the middle of its coverage if the view is outside it. */
    public void setReader(ObfReader r, String name) {
        reader = r;
        fileName = name;
        loaded = null;
        info = "";
        clearRoute();
        if (r == null) {
            ruleClasses = null;
            ruleFlags = null;
            minZoom = MIN_ZOOM;
            maxZoom = MAX_ZOOM;
            postInvalidate();
            return;
        }
        List<ObfReader.MapIndex> maps = r.getMaps();
        ruleClasses = new int[maps.size()][];
        ruleFlags = new int[maps.size()][];
        int lo = Integer.MAX_VALUE, hi = 0;
        boolean inside = false;
        for (int i = 0; i < maps.size(); i++) {
            ObfReader.MapIndex mi = maps.get(i);
            ruleClasses[i] = Style.buildRuleClasses(mi);
            ruleFlags[i] = Style.buildRuleFlags(mi);
            if (!mi.levels.isEmpty()) {
                lo = Math.min(lo, mi.minZoom());
                hi = Math.max(hi, mi.maxZoom());
                for (ObfReader.Level lv : mi.levels) {
                    if (cx >= lv.left && cx <= lv.right && cy >= lv.top && cy <= lv.bottom) inside = true;
                }
            }
        }
        if (hi > 0) {
            minZoom = Math.max(MIN_ZOOM, lo);
            maxZoom = Math.min(MAX_ZOOM, hi);
        }
        if (!inside && !maps.isEmpty() && maps.get(0).centerX() >= 0) {
            cx = maps.get(0).centerX();
            cy = maps.get(0).centerY();
        }
        zoom = Math.max(minZoom, Math.min(maxZoom, Math.max(zoom, 12)));
        postInvalidate();
    }

    public void close() {
        synchronized (lock) {
            closed = true;
            lock.notifyAll();
        }
    }

    // ------------------------------------------------------------------ loading

    private void startWorker() {
        worker = new Thread(new Runnable() {
            @Override
            public void run() {
                loop();
            }
        }, "obf-loader");
        worker.setPriority(Thread.NORM_PRIORITY - 1);
        worker.setDaemon(true);
        worker.start();
    }

    private void requestLoad(int l, int r, int t, int b, int z) {
        synchronized (lock) {
            rl = l;
            rr = r;
            rt = t;
            rb = b;
            rz = z;
            pending = true;
            lock.notifyAll();
        }
    }

    private void loop() {
        while (true) {
            int l, r, t, b, z;
            ObfReader rd;
            int[][] rc;
            int[][] rf;
            synchronized (lock) {
                while (!pending && !closed) {
                    try {
                        lock.wait();
                    } catch (InterruptedException e) {
                        return;
                    }
                }
                if (closed) return;
                l = rl;
                r = rr;
                t = rt;
                b = rb;
                z = rz;
                pending = false;
                rd = reader;
                rc = ruleClasses;
                rf = ruleFlags;
            }
            if (rd == null || rc == null || rf == null) continue;
            final List<Feature> out = new ArrayList<Feature>();
            final boolean[] truncated = {false};
            final int zz = z;
            try {
                List<ObfReader.MapIndex> maps = rd.getMaps();
                for (int i = 0; i < maps.size(); i++) {
                    final int[] classes = rc[i];
                    final int[] flags = rf[i];
                    rd.search(maps.get(i), l, r, t, b, z, new ObfReader.FeatureSink() {
                        @Override
                        public boolean accept(ObfReader.MapIndex map, Feature f) {
                            f.cls = Style.classOf(classes, f.types);
                            if (f.cls == Style.NONE || zz < Style.minZoom(f.cls)) return true;
                            if (Style.isPlace(f.cls) && f.name == null) return true;
                            if (Style.isVehicleRoad(f.cls)) {
                                int fl = 0;
                                for (int ty : f.types) if (ty >= 0 && ty < flags.length) fl |= flags[ty];
                                f.flags = fl;
                                f.toll = Style.isToll(f.cls, fl, f.name);
                            }
                            out.add(f);
                            if (out.size() >= MAX_FEATURES) {
                                truncated[0] = true;
                                return false;
                            }
                            return true;
                        }
                    });
                    if (truncated[0]) break;
                }
            } catch (IOException e) {
                setStatus("ERR " + e.getMessage());
                continue;
            }
            Collections.sort(out, new Comparator<Feature>() {
                @Override
                public int compare(Feature x, Feature y) {
                    int a = styleKey(x), c = styleKey(y);
                    return a < c ? -1 : (a == c ? 0 : 1);
                }
            });
            List<int[]> coastLines = new ArrayList<int[]>();
            for (Feature f : out) if (f.cls == Style.COAST && !f.area) coastLines.add(f.xy);
            Loaded ld = new Loaded();
            ld.feats = out;
            ld.coast = Coast.land(coastLines, l, r, t, b);
            ld.left = l;
            ld.right = r;
            ld.top = t;
            ld.bottom = b;
            ld.zoom = z;
            ld.truncated = truncated[0];
            loaded = ld;
            postInvalidate();
        }
    }

    private static int styleKey(Feature f) {
        return f.toll ? KEY_TOLL : f.cls;
    }

    // ------------------------------------------------------------------ geometry helpers

    private double unitsPerPx() {
        return Math.pow(2.0, 23 - zoom) / density;
    }

    private double metersPerUnit() {
        return Router.metersPerUnit(Geo.yToLat(cy));
    }

    private float sx(double x, double ox, double inv) {
        return (float) ((x - ox) * inv);
    }

    // ------------------------------------------------------------------ drawing: map

    private void applyKey(int key) {
        line.setPathEffect(null);
        line.setColor(cRoad);
        float w = px1;
        switch (key) {
            case KEY_TOLL:
                line.setColor(cToll);
                w = px1 * 4;
                break;
            case Style.MOTORWAY:
            case Style.TRUNK:
                w = px1 * 3.5f;
                break;
            case Style.PRIMARY:
                w = px1 * 3;
                break;
            case Style.SECONDARY:
                w = px1 * 2.5f;
                break;
            case Style.TERTIARY:
                w = px1 * 2;
                break;
            case Style.MINOR:
                w = px1 * 1.5f;
                break;
            case Style.TRACK:
                line.setPathEffect(new DashPathEffect(new float[]{px1 * 6, px1 * 4}, 0));
                break;
            case Style.PATH:
                line.setPathEffect(new DashPathEffect(new float[]{px1 * 2, px1 * 3}, 0));
                break;
            case Style.RAIL:
                line.setColor(cRail);
                line.setPathEffect(new DashPathEffect(new float[]{px1 * 10, px1 * 3, px1 * 2, px1 * 3}, 0));
                break;
            case Style.WATERWAY:
                line.setColor(cWaterDark);
                w = px1 * 2;
                break;
            case Style.COAST:
                line.setColor(cWaterDark);
                w = px1 * 2;
                break;
            case Style.BUILDING:
                line.setColor(cBuilding);
                break;
            case Style.WATER:
                line.setColor(cWaterDark);
                break;
            default:
                break;
        }
        line.setStrokeWidth(w);
    }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        double upp = unitsPerPx();
        double halfW = w / 2.0 * upp, halfH = h / 2.0 * upp;
        int vl = (int) Math.max(0, cx - halfW), vr = (int) Math.min(Integer.MAX_VALUE, cx + halfW);
        int vt = (int) Math.max(0, cy - halfH), vb = (int) Math.min(Integer.MAX_VALUE, cy + halfH);
        double ox = cx - halfW, oy = cy - halfH;
        double inv = 1.0 / upp;

        Loaded ld = loaded;
        boolean sea = ld != null && ld.coast != null && ld.coast.seaMode;
        c.drawColor(sea ? cWater : cLand);

        if (reader != null && w > 0) {
            boolean covered = ld != null && ld.zoom == zoom && vl >= ld.left && vr <= ld.right
                    && vt >= ld.top && vb <= ld.bottom;
            if (!covered) {
                // load 1.5x the viewport so small pans do not trigger a reload
                int ml = (int) (halfW * 1.5), mt = (int) (halfH * 1.5);
                requestLoad((int) Math.max(0, cx - halfW - ml), (int) Math.min(Integer.MAX_VALUE, cx + halfW + ml),
                        (int) Math.max(0, cy - halfH - mt), (int) Math.min(Integer.MAX_VALUE, cy + halfH + mt),
                        zoom);
            }
        }

        labelRects.clear();
        int drawn = 0;
        if (ld != null) {
            if (sea) {
                fill.setColor(cLand);
                for (int[] poly : ld.coast.land) drawPolyFill(c, poly, ox, oy, inv);
            }
            int lastKey = -1;
            for (int i = 0; i < ld.feats.size(); i++) {
                Feature f = ld.feats.get(i);
                if (zoom < Style.minZoom(f.cls)) continue;
                if (f.maxX < vl || f.minX > vr || f.maxY < vt || f.minY > vb) continue;
                if (Style.isPlace(f.cls)) continue; // labels are drawn in a second pass
                if (f.cls == Style.WATER && f.area) {
                    fill.setColor(cWater);
                    drawPolyFill(c, f.xy, ox, oy, inv);
                    drawn++;
                    continue;
                }
                int key = styleKey(f);
                if (key != lastKey) {
                    applyKey(key);
                    lastKey = key;
                }
                drawFeature(c, f, ox, oy, inv);
                drawn++;
            }
            line.setPathEffect(null);
        }

        drawRoute(c, ox, oy, inv, w, h);
        drawWaypoints(c, ox, oy, inv, w, h);
        if (ld != null && showNames) drawLabels(c, ld, ox, oy, inv, vl, vr, vt, vb, w, h);
        drawGps(c, ox, oy, inv);
        drawChrome(c, w, h, drawn, ld);
    }

    private void drawPolyFill(Canvas c, int[] xy, double ox, double oy, double inv) {
        path.rewind();
        for (int i = 0; i < xy.length; i += 2) {
            float x = sx(xy[i], ox, inv), y = sx(xy[i + 1], oy, inv);
            if (i == 0) path.moveTo(x, y);
            else path.lineTo(x, y);
        }
        path.close();
        c.drawPath(path, fill);
    }

    private void drawFeature(Canvas c, Feature f, double ox, double oy, double inv) {
        int[] xy = f.xy;
        path.rewind();
        float lastX = 0, lastY = 0;
        boolean started = false;
        for (int i = 0; i < xy.length; i += 2) {
            float x = sx(xy[i], ox, inv);
            float y = sx(xy[i + 1], oy, inv);
            if (!started) {
                path.moveTo(x, y);
                started = true;
            } else if (Math.abs(x - lastX) >= 1f || Math.abs(y - lastY) >= 1f) {
                path.lineTo(x, y);
            } else {
                continue;
            }
            lastX = x;
            lastY = y;
        }
        if (f.area) path.close();
        c.drawPath(path, line);
    }

    private boolean placeLabel(Canvas c, String s, float x, float y, int w, int h) {
        if (s == null || s.length() == 0) return false;
        float tw = text.measureText(s);
        float th = text.getTextSize();
        float l = x - tw / 2, t = y - th, r = x + tw / 2, b = y + 3;
        if (l < 2 || r > w - 2 || t < th + 6 || b > h - th * 2 - 80 * density) return false;
        for (float[] q : labelRects) {
            if (l < q[2] && r > q[0] && t < q[3] && b > q[1]) return false;
        }
        labelRects.add(new float[]{l, t, r, b});
        fill.setColor(cBox);
        c.drawRect(l - 2, t, r + 2, b, fill);
        text.setColor(cText);
        c.drawText(s, l, y, text);
        return true;
    }

    private void drawLabels(Canvas c, Loaded ld, double ox, double oy, double inv,
                            int vl, int vr, int vt, int vb, int w, int h) {
        int roadLabels = 0;
        // places first (big ones first), then road names at high zoom
        for (int pass = 0; pass < 2; pass++) {
            for (int i = ld.feats.size() - 1; i >= 0; i--) {
                Feature f = ld.feats.get(i);
                if (f.name == null) continue;
                if (pass == 0 && !Style.isPlace(f.cls)) continue;
                if (pass == 1 && (!Style.isRoad(f.cls) || zoom < 16 || roadLabels > 40)) continue;
                if (f.maxX < vl || f.minX > vr || f.maxY < vt || f.minY > vb) continue;
                int n = f.xy.length / 2;
                int mid = (n / 2) * 2;
                float x = sx(f.xy[mid], ox, inv);
                float y = sx(f.xy[mid + 1], oy, inv);
                if (placeLabel(c, f.name, x, y, w, h) && pass == 1) roadLabels++;
            }
        }
    }

    // ------------------------------------------------------------------ drawing: route, waypoints, GPS

    private void drawRoute(Canvas c, double ox, double oy, double inv, int w, int h) {
        Route r = route;
        if (r == null || r.size() < 2) return;
        path.rewind();
        float lx = 0, ly = 0;
        boolean started = false;
        for (int i = 0; i < r.xy.length; i += 2) {
            float x = sx(r.xy[i], ox, inv), y = sx(r.xy[i + 1], oy, inv);
            if (!started) {
                path.moveTo(x, y);
                started = true;
            } else if (Math.abs(x - lx) >= 1.5f || Math.abs(y - ly) >= 1.5f || i >= r.xy.length - 2) {
                path.lineTo(x, y);
            } else {
                continue;
            }
            lx = x;
            ly = y;
        }
        line.setPathEffect(null);
        line.setStrokeJoin(Paint.Join.ROUND);
        line.setStrokeCap(Paint.Cap.ROUND);
        line.setColor(cBox);
        line.setStrokeWidth(10 * density);
        c.drawPath(path, line);
        line.setColor(cRoute);
        line.setStrokeWidth(6 * density);
        c.drawPath(path, line);
        line.setStrokeJoin(Paint.Join.MITER);
        line.setStrokeCap(Paint.Cap.BUTT);

        // destination (and via) markers
        for (Route.Maneuver m : r.maneuvers) {
            if (m.type != Route.T_ARRIVE && m.type != Route.T_VIA) continue;
            float x = sx(r.xy[2 * m.pt], ox, inv), y = sx(r.xy[2 * m.pt + 1], oy, inv);
            if (x < -40 || y < -40 || x > w + 40 || y > h + 40) continue;
            float rad = (m.type == Route.T_ARRIVE ? 13 : 10) * density;
            fill.setColor(cText);
            c.drawCircle(x, y, rad + 3 * density, fill);
            fill.setColor(m.type == Route.T_ARRIVE ? cRoute : cWp);
            c.drawCircle(x, y, rad, fill);
        }
    }

    private void drawWaypoints(Canvas c, double ox, double oy, double inv, int w, int h) {
        float r = 11 * density;
        for (Waypoint wp : waypoints) {
            float x = sx(Geo.lonToX(wp.lon), ox, inv), y = sx(Geo.latToY(wp.lat), oy, inv);
            if (x < -r || y < -r || x > w + r || y > h + r) continue;
            path.rewind();
            path.moveTo(x, y - r);
            path.lineTo(x + r, y);
            path.lineTo(x, y + r);
            path.lineTo(x - r, y);
            path.close();
            fill.setColor(cWp);
            c.drawPath(path, fill);
            line.setPathEffect(null);
            line.setColor(0xFF000000);
            line.setStrokeWidth(px1 * 1.5f);
            c.drawPath(path, line);
            if (showNames) placeLabel(c, wp.name, x, y - r - 4 * density, w, h);
        }
    }

    private void drawGps(Canvas c, double ox, double oy, double inv) {
        if (!hasGps) return;
        float x = sx(Geo.lonToX(gpsLon), ox, inv), y = sx(Geo.latToY(gpsLat), oy, inv);
        float r = 14 * density;
        line.setPathEffect(null);
        if (Float.isNaN(gpsBearing)) {
            fill.setColor(cBox);
            c.drawCircle(x, y, r + 3 * density, fill);
            fill.setColor(cGps);
            c.drawCircle(x, y, r, fill);
        } else {
            c.save();
            c.translate(x, y);
            c.rotate(gpsBearing);
            path.rewind();
            path.moveTo(0, -r * 1.3f);
            path.lineTo(r, r);
            path.lineTo(0, r * 0.4f);
            path.lineTo(-r, r);
            path.close();
            line.setColor(cBox);
            line.setStrokeWidth(5 * density);
            c.drawPath(path, line);
            fill.setColor(cGps);
            c.drawPath(path, fill);
            c.restore();
        }
    }

    // ------------------------------------------------------------------ drawing: chrome

    private float barH() {
        return 72 * density;
    }

    private void box(Canvas c, RectF r, boolean on, String label, Paint p) {
        float bw = 3 * density;
        fill.setColor(on ? cText : cBox);
        c.drawRect(r, fill);
        line.setPathEffect(null);
        line.setColor(cText);
        line.setStrokeWidth(bw);
        c.drawRect(r.left + bw / 2, r.top + bw / 2, r.right - bw / 2, r.bottom - bw / 2, line);
        p.setColor(on ? cBox : cText);
        float tw = p.measureText(label);
        c.drawText(label, r.centerX() - tw / 2, r.centerY() + p.getTextSize() * 0.35f, p);
    }

    private String clip(String s, float maxW, Paint p) {
        if (p.measureText(s) <= maxW) return s;
        int n = s.length();
        while (n > 1 && p.measureText(s.substring(0, n) + "..") > maxW) n--;
        return s.substring(0, n) + "..";
    }

    private void drawChrome(Canvas c, int w, int h, int drawn, Loaded ld) {
        float th = text.getTextSize();
        float pad = 8 * density;
        line.setPathEffect(null);
        line.setStrokeWidth(px1);
        line.setColor(cText);

        if (panel != P_NONE) {
            drawPanel(c, w, h);
            return;
        }

        // crosshair
        float mx = w / 2f, my = h / 2f, cr = 10 * density;
        line.setStrokeWidth(2 * px1);
        c.drawLine(mx - cr, my, mx + cr, my, line);
        c.drawLine(mx, my - cr, mx, my + cr, line);

        if (reader == null) {
            String[] hint = {"Belum ada peta.", "Tekan MENU > BUKA PETA", "lalu pilih file .obf"};
            for (int i = 0; i < hint.length; i++) {
                float tw = big.measureText(hint[i]);
                fill.setColor(cBox);
                c.drawRect(mx - tw / 2 - 4, my + big.getTextSize() * (2 + 1.5f * i) - big.getTextSize(),
                        mx + tw / 2 + 4, my + big.getTextSize() * (2 + 1.5f * i) + 6, fill);
                big.setColor(cText);
                c.drawText(hint[i], mx - tw / 2, my + big.getTextSize() * (2 + 1.5f * i), big);
            }
        }

        // top bar
        float topH = th + 10;
        fill.setColor(cBox);
        c.drawRect(0, 0, w, topH, fill);
        line.setStrokeWidth(px1 * 1.5f);
        c.drawLine(0, topH, w, topH, line);
        text.setColor(cText);
        String top = (fileName.length() == 0 ? "(belum ada peta)" : fileName) + "  Z" + zoom
                + (ld != null && ld.truncated ? " [PENUH]" : "");
        c.drawText(clip(top, w - 8, text), 4, th + 2, text);
        float y0 = topH;

        // navigation banner
        if (route != null) y0 = drawBanner(c, w, y0);

        // zoom buttons (right edge)
        float bh = barH();
        float infoH = th + 12;
        float avail = h - y0 - bh - infoH - 4 * pad;
        float zb = Math.max(48 * density, Math.min(80 * density, avail / 2));
        zoomIn.r.set(w - zb - pad, y0 + pad, w - pad, y0 + pad + zb);
        zoomOut.r.set(w - zb - pad, y0 + pad * 2 + zb, w - pad, y0 + pad * 2 + zb * 2);
        huge.setTextSize(Math.min(40 * sp, zb * 0.6f));
        box(c, zoomIn.r, false, "+", huge);
        box(c, zoomOut.r, false, "-", huge);

        // bottom: info line + big buttons
        float by = h - bh;
        fill.setColor(cBox);
        c.drawRect(0, by - infoH, w, h, fill);
        line.setStrokeWidth(px1 * 1.5f);
        c.drawLine(0, by - infoH, w, by - infoH, line);
        String l1 = info.length() > 0 ? info : status;
        if (l1.length() == 0) {
            l1 = String.format(Locale.US, "%.5f %.5f  %d obj", getCenterLat(), getCenterLon(), drawn);
        }
        text.setColor(cText);
        c.drawText(clip(l1, w - 8, text), 4, by - 6 * density, text);

        float bw = w / (float) mainButtons.length;
        for (int i = 0; i < mainButtons.length; i++) {
            Button b = mainButtons[i];
            b.r.set(i * bw + 3, by + 3, (i + 1) * bw - 3, h - 3);
            boolean on = (b.id == B_GPS && followGps) || (b.id == B_ROUTE && route != null);
            box(c, b.r, on, b.label, big);
        }
    }

    /** Draws the turn banner; returns the y below it. */
    private float drawBanner(Canvas c, int w, float y0) {
        Route r = route;
        float bh = 96 * density;
        fill.setColor(cBox);
        c.drawRect(0, y0, w, y0 + bh, fill);
        line.setStrokeWidth(3 * density);
        line.setColor(cText);
        c.drawLine(0, y0 + bh, w, y0 + bh, line);

        Route.Fix f = fix;
        Route.Maneuver m = null;
        double dist;
        if (f != null && f.nextMan < r.maneuvers.size()) {
            m = r.maneuvers.get(f.nextMan);
            dist = f.toNext;
        } else if (!r.maneuvers.isEmpty()) {
            m = r.maneuvers.get(0);
            dist = m.at;
        } else {
            return y0 + bh;
        }
        // arrow
        float ax = 12 * density + 34 * density, ay = y0 + bh / 2;
        drawArrow(c, m, ax, ay, 30 * density);
        // distance
        float tx = ax + 46 * density;
        huge.setColor(cText);
        huge.setTextSize(34 * sp);
        c.drawText(fmtDist(dist), tx, y0 + 40 * density, huge);
        // text line
        big.setColor(cText);
        big.setTextSize(17 * sp);
        c.drawText(clip(maneuverText(m), w - tx - 8 * density, big), tx, y0 + 66 * density, big);
        // remaining
        double rem = f != null ? f.remaining : r.length;
        double secs = r.length > 0 ? r.seconds * (rem / r.length) : 0;
        String s2 = fmtDist(rem) + "  " + fmtTime(secs) + (r.tollMeters > 0 ? "  TOL" : "")
                + (optVehicle == Router.MOTO ? "  MOTOR" : "  MOBIL");
        text.setColor(cText);
        c.drawText(clip(s2, w - tx - 8 * density, text), tx, y0 + 88 * density, text);
        big.setTextSize(20 * sp);
        return y0 + bh;
    }

    private void drawArrow(Canvas c, Route.Maneuver m, float x, float y, float s) {
        c.save();
        c.translate(x, y);
        line.setPathEffect(null);
        line.setColor(cText);
        fill.setColor(cText);
        line.setStrokeWidth(8 * density);
        switch (m.type) {
            case Route.T_ARRIVE:
            case Route.T_VIA:
                fill.setColor(m.type == Route.T_ARRIVE ? cRoute : cWp);
                c.drawCircle(0, 0, s * 0.8f, fill);
                line.setStrokeWidth(3 * density);
                c.drawCircle(0, 0, s * 0.8f, line);
                break;
            case Route.T_ROUNDABOUT: {
                line.setStrokeWidth(5 * density);
                c.drawCircle(0, 0, s * 0.7f, line);
                big.setColor(cText);
                String n = String.valueOf(m.exit);
                c.drawText(n, -big.measureText(n) / 2, big.getTextSize() * 0.35f, big);
                break;
            }
            default: {
                float ang = 0;
                switch (m.type) {
                    case Route.T_SLIGHT_LEFT:
                        ang = -45;
                        break;
                    case Route.T_LEFT:
                        ang = -90;
                        break;
                    case Route.T_SHARP_LEFT:
                        ang = -135;
                        break;
                    case Route.T_SLIGHT_RIGHT:
                        ang = 45;
                        break;
                    case Route.T_RIGHT:
                        ang = 90;
                        break;
                    case Route.T_SHARP_RIGHT:
                        ang = 135;
                        break;
                    case Route.T_UTURN:
                        ang = 180;
                        break;
                    default:
                        break;
                }
                c.drawLine(0, s, 0, 0, line);
                c.rotate(ang);
                c.drawLine(0, 0, 0, -s * 0.7f, line);
                path.rewind();
                path.moveTo(0, -s * 1.25f);
                path.lineTo(s * 0.6f, -s * 0.5f);
                path.lineTo(-s * 0.6f, -s * 0.5f);
                path.close();
                c.drawPath(path, fill);
                break;
            }
        }
        c.restore();
    }

    // ------------------------------------------------------------------ drawing: panels

    private void drawPanel(Canvas c, int w, int h) {
        float titleH = 60 * density, rowH = 68 * density, bh = barH();
        c.drawColor(cBox);
        panelTop = titleH;
        panelBottom = h - bh;
        c.save();
        c.clipRect(0, panelTop, w, panelBottom);
        for (int i = 0; i < items.size(); i++) {
            Item it = items.get(i);
            float y = panelTop + i * rowH - panelScroll;
            if (y + rowH < panelTop || y > panelBottom) continue;
            boolean sel = i == panelSel;
            fill.setColor(sel ? cText : cBox);
            c.drawRect(0, y, w, y + rowH, fill);
            line.setStrokeWidth(2 * density);
            line.setColor(cText);
            c.drawLine(0, y + rowH, w, y + rowH, line);
            int col = it.enabled ? (sel ? cBox : cText) : 0xFF808080;
            big.setTextSize(it.hint != null ? 18 * sp : 20 * sp);
            big.setColor(col);
            float ty = it.hint != null ? y + rowH * 0.42f : y + rowH / 2 + big.getTextSize() * 0.35f;
            c.drawText(clip(it.label, w - 24 * density, big), 12 * density, ty, big);
            if (it.hint != null) {
                text.setColor(col);
                c.drawText(clip(it.hint, w - 24 * density, text), 12 * density, y + rowH * 0.82f, text);
            }
        }
        c.restore();
        big.setTextSize(20 * sp);

        // title bar and close bar
        fill.setColor(cText);
        c.drawRect(0, 0, w, titleH, fill);
        big.setColor(cBox);
        c.drawText(clip(panelTitle, w - 24 * density, big), 12 * density, titleH / 2 + big.getTextSize() * 0.35f, big);
        closeBtn.r.set(3, h - bh + 3, w - 3, h - 3);
        box(c, closeBtn.r, false, panel == P_WPACT ? "KEMBALI" : "TUTUP", big);
    }

    private void closePanel() {
        panel = P_NONE;
        invalidate();
    }

    private void openPanel(int kind) {
        panel = kind;
        panelScroll = 0;
        panelSel = 0;
        buildPanel();
        invalidate();
    }

    private void buildPanel() {
        items.clear();
        switch (panel) {
            case P_MENU:
                panelTitle = "MENU";
                items.add(new Item("BUKA PETA (.obf)", null, M_OPEN, true));
                items.add(new Item("TEMA: " + (inverted ? "GELAP" : "TERANG"), "ketuk untuk ganti", M_THEME, true));
                items.add(new Item("NAMA DI PETA: " + (showNames ? "ON" : "OFF"), "nama jalan dan tempat", M_NAMES, true));
                items.add(new Item("SUARA NAVIGASI: " + (optVoice ? "ON" : "OFF"), "butuh suara Indonesia di HP", M_VOICE, true));
                items.add(new Item("KELUAR", null, M_QUIT, true));
                break;
            case P_ROUTE:
                panelTitle = "RUTE";
                if (route != null) {
                    items.add(new Item("RUTE AKTIF: " + fmtDist(route.length) + ", " + fmtTime(route.seconds),
                            route.note != null ? route.note : (route.tollMeters > 0 ? "melewati jalan tol" : "tanpa tol"),
                            R_INFO, false));
                }
                items.add(new Item("KENDARAAN: " + (optVehicle == Router.MOTO ? "MOTOR" : "MOBIL"),
                        "ketuk untuk ganti", R_VEH, true));
                items.add(new Item("RUTE: " + (optShortest ? "TERPENDEK" : "TERCEPAT"), "ketuk untuk ganti", R_MODE, true));
                if (optVehicle == Router.MOTO) {
                    items.add(new Item("TOL: DILARANG UNTUK MOTOR", "otomatis dihindari", R_TOLL, false));
                } else {
                    items.add(new Item("HINDARI TOL: " + (optAvoidToll ? "YA" : "TIDAK"), "ketuk untuk ganti", R_TOLL, true));
                }
                items.add(new Item(manualOrigin == null ? "ASAL: POSISI GPS" : "ASAL: TITIK DI PETA",
                        manualOrigin == null ? "ketuk = pakai titik tengah (+) sebagai asal" : "ketuk = kembali ke GPS",
                        R_ORIGIN, true));
                items.add(new Item("NAVIGASI KE TITIK TENGAH (+)", "geser/ketuk peta dulu untuk memilih tujuan", R_GO, true));
                if (!plan.isEmpty()) {
                    items.add(new Item("TAMBAH TITIK TENGAH SEBAGAI TUJUAN AKHIR", "tujuan sebelumnya jadi titik singgah", R_ADD, true));
                }
                if (route != null || !plan.isEmpty()) items.add(new Item("BATALKAN RUTE", null, R_CLEAR, true));
                break;
            case P_WP:
                panelTitle = "WAYPOINT (" + waypoints.size() + ")";
                items.add(new Item("SIMPAN WP DI TITIK TENGAH (+)", null, W_SAVE_C, true));
                items.add(new Item("SIMPAN WP DI POSISI GPS", hasGps ? null : "GPS belum dapat sinyal", W_SAVE_G, hasGps));
                if (waypoints.isEmpty()) items.add(new Item("(belum ada waypoint)", null, W_EMPTY, false));
                for (int i = 0; i < waypoints.size(); i++) {
                    Waypoint wp = waypoints.get(i);
                    items.add(new Item(wp.name, fmtDist(distToCenter(wp)) + " dari titik tengah", W_ITEM + i, true));
                }
                break;
            case P_WPACT: {
                Waypoint wp = wpSel >= 0 && wpSel < waypoints.size() ? waypoints.get(wpSel) : null;
                panelTitle = wp == null ? "WAYPOINT" : wp.name;
                items.add(new Item("NAVIGASI KE SINI", null, WA_GO, true));
                items.add(new Item("TAMBAH KE RUTE (TUJUAN AKHIR)", "tujuan sebelumnya jadi titik singgah", WA_ADD, true));
                items.add(new Item("LIHAT DI PETA", null, WA_SHOW, true));
                items.add(new Item("HAPUS WAYPOINT", null, WA_DEL, true));
                break;
            }
            default:
                break;
        }
        if (panelSel >= items.size()) panelSel = Math.max(0, items.size() - 1);
    }

    private void activate(int index) {
        if (index < 0 || index >= items.size()) return;
        Item it = items.get(index);
        if (!it.enabled) return;
        panelSel = index;
        switch (it.id) {
            case M_OPEN:
                closePanel();
                if (host != null) host.onOpenRequest();
                return;
            case M_THEME:
                setInverted(!inverted);
                changed();
                buildPanel();
                break;
            case M_NAMES:
                showNames = !showNames;
                changed();
                buildPanel();
                break;
            case M_VOICE:
                optVoice = !optVoice;
                changed();
                buildPanel();
                break;
            case M_QUIT:
                if (host != null) host.onQuit();
                return;
            case R_VEH:
                optVehicle = optVehicle == Router.CAR ? Router.MOTO : Router.CAR;
                optionsChanged();
                break;
            case R_MODE:
                optShortest = !optShortest;
                optionsChanged();
                break;
            case R_TOLL:
                optAvoidToll = !optAvoidToll;
                optionsChanged();
                break;
            case R_ORIGIN:
                manualOrigin = manualOrigin == null ? new int[]{(int) cx, (int) cy} : null;
                if (manualOrigin != null) setStatus("Asal diset di titik tengah");
                optionsChanged();
                break;
            case R_GO:
                plan.clear();
                planBase = 0;
                plan.add(new int[]{(int) cx, (int) cy});
                closePanel();
                requestRoute(false);
                return;
            case R_ADD:
                plan.add(new int[]{(int) cx, (int) cy});
                closePanel();
                requestRoute(false);
                return;
            case R_CLEAR:
                clearRoute();
                buildPanel();
                break;
            case W_SAVE_C:
                saveWaypoint(Geo.yToLat(cy), Geo.xToLon(cx));
                buildPanel();
                break;
            case W_SAVE_G:
                saveWaypoint(gpsLat, gpsLon);
                buildPanel();
                break;
            case WA_GO:
                if (wpSel >= 0 && wpSel < waypoints.size()) {
                    Waypoint wp = waypoints.get(wpSel);
                    plan.clear();
                    planBase = 0;
                    plan.add(new int[]{(int) Geo.lonToX(wp.lon), (int) Geo.latToY(wp.lat)});
                    closePanel();
                    requestRoute(false);
                }
                return;
            case WA_ADD:
                if (wpSel >= 0 && wpSel < waypoints.size()) {
                    Waypoint wp = waypoints.get(wpSel);
                    plan.add(new int[]{(int) Geo.lonToX(wp.lon), (int) Geo.latToY(wp.lat)});
                    closePanel();
                    requestRoute(false);
                }
                return;
            case WA_SHOW:
                if (wpSel >= 0 && wpSel < waypoints.size()) {
                    Waypoint wp = waypoints.get(wpSel);
                    followGps = false;
                    cx = Geo.lonToX(wp.lon);
                    cy = Geo.latToY(wp.lat);
                    closePanel();
                }
                return;
            case WA_DEL:
                if (wpSel >= 0 && wpSel < waypoints.size()) {
                    waypoints.remove(wpSel);
                    changed();
                }
                wpSel = -1;
                openPanel(P_WP);
                return;
            default:
                if (it.id >= W_ITEM && it.id - W_ITEM < waypoints.size()) {
                    wpSel = it.id - W_ITEM;
                    openPanel(P_WPACT);
                    return;
                }
                break;
        }
        invalidate();
    }

    private void saveWaypoint(double lat, double lon) {
        int n = 1;
        for (Waypoint w : waypoints) {
            if (w.name.startsWith("WP")) {
                int k = 0;
                int i = 2;
                while (i < w.name.length() && Character.isDigit(w.name.charAt(i)) && k < 100000) {
                    k = k * 10 + (w.name.charAt(i) - '0');
                    i++;
                }
                if (k >= n) n = k + 1;
            }
        }
        String near = nearestName(Geo.lonToX(lon), Geo.latToY(lat));
        Waypoint wp = new Waypoint();
        wp.lat = lat;
        wp.lon = lon;
        String nm = "WP" + n + (near != null ? " " + near : "");
        nm = nm.replace(',', ' ').replace('\n', ' ');
        if (nm.length() > 28) nm = nm.substring(0, 28);
        wp.name = nm;
        waypoints.add(wp);
        changed();
        setStatus("Tersimpan: " + wp.name);
    }

    private double distToCenter(Waypoint wp) {
        double dx = Geo.lonToX(wp.lon) - cx, dy = Geo.latToY(wp.lat) - cy;
        return Math.sqrt(dx * dx + dy * dy) * metersPerUnit();
    }

    private void changed() {
        if (host != null) host.onStateChanged();
    }

    private void optionsChanged() {
        changed();
        buildPanel();
        if (!plan.isEmpty() && !routing) requestRoute(false);
        invalidate();
    }

    // ------------------------------------------------------------------ navigation

    private int[] origin() {
        if (manualOrigin != null) return manualOrigin;
        if (hasGps) return new int[]{(int) Geo.lonToX(gpsLon), (int) Geo.latToY(gpsLat)};
        return null;
    }

    private void clearRoute() {
        waitingGps = false;
        routeGen++;
        routing = false;
        route = null;
        fix = null;
        plan.clear();
        planBase = 0;
        lastSeg = 0;
        offCount = 0;
        invalidate();
    }

    private void requestRoute(final boolean reroute) {
        if (reader == null) {
            setStatus("Buka peta dulu");
            return;
        }
        if (plan.isEmpty()) return;
        int[] org = origin();
        if (org == null) {
            waitingGps = true;
            if (host != null) host.onNeedGps();
            setStatus("Nunggu sinyal GPS, atau pilih ASAL = titik di peta");
            return;
        }
        final List<int[]> pts = new ArrayList<int[]>();
        pts.add(org);
        for (int i = Math.min(planBase, plan.size() - 1); i < plan.size(); i++) pts.add(plan.get(i));
        final Router.Options o = new Router.Options();
        o.vehicle = optVehicle;
        o.avoidToll = optAvoidToll;
        o.shortest = optShortest;
        final ObfReader rd = reader;
        final int gen = ++routeGen;
        routing = true;
        setStatus(reroute ? "Keluar jalur, menghitung ulang..." : "Menghitung rute...");
        new Thread(new Runnable() {
            @Override
            public void run() {
                Route res = null;
                String err = null;
                try {
                    res = Router.route(rd, pts, o);
                } catch (Router.RouteException e) {
                    err = e.getMessage();
                } catch (IOException e) {
                    err = "Gagal membaca peta: " + e.getMessage();
                } catch (OutOfMemoryError e) {
                    err = "Memori habis, area rute terlalu luas";
                } catch (RuntimeException e) {
                    err = "Error rute: " + e;
                }
                final Route fr = res;
                final String fe = err;
                post(new Runnable() {
                    @Override
                    public void run() {
                        if (gen != routeGen) return; // superseded or cancelled
                        routing = false;
                        if (fr == null) {
                            route = null;
                            fix = null;
                            setStatus("RUTE GAGAL: " + fe);
                            return;
                        }
                        applyRoute(fr, reroute);
                    }
                });
            }
        }, "obf-route").start();
    }

    private void applyRoute(Route r, boolean reroute) {
        route = r;
        fix = null;
        lastSeg = 0;
        offCount = 0;
        announced = new int[r.maneuvers.size()];
        String s = "Rute " + fmtDist(r.length) + ", " + fmtTime(r.seconds) + (r.tollMeters > 0 ? ", lewat tol" : "");
        if (r.note != null) s += " | " + r.note;
        setStatus(s);
        if (!reroute) {
            if (hasGps && manualOrigin == null) {
                followGps = true;
                setFollowGps(true);
            } else {
                if (host != null && manualOrigin == null) host.onNeedGps();
                fitRoute(r);
            }
            speak("Rute siap. Jarak " + spokenDist(r.length) + ", sekitar " + fmtTime(r.seconds));
        } else {
            speak("Rute dihitung ulang");
        }
        invalidate();
    }

    private void fitRoute(Route r) {
        int minX = Integer.MAX_VALUE, maxX = 0, minY = Integer.MAX_VALUE, maxY = 0;
        for (int i = 0; i < r.xy.length; i += 2) {
            minX = Math.min(minX, r.xy[i]);
            maxX = Math.max(maxX, r.xy[i]);
            minY = Math.min(minY, r.xy[i + 1]);
            maxY = Math.max(maxY, r.xy[i + 1]);
        }
        cx = (minX + (double) maxX) / 2;
        cy = (minY + (double) maxY) / 2;
        followGps = false;
        int w = Math.max(1, getWidth()), h = Math.max(1, getHeight());
        for (int z = maxZoom; z >= minZoom; z--) {
            double upp = Math.pow(2.0, 23 - z) / density;
            if ((maxX - minX) < w * 0.8 * upp && (maxY - minY) < h * 0.5 * upp) {
                zoom = z;
                return;
            }
        }
        zoom = minZoom;
    }

    /** Called for every GPS fix: match to the route, announce turns, detect leaving the route. */
    private void trackRoute() {
        Route r = route;
        if (r == null || routing || manualOrigin != null) return;
        double x = Geo.lonToX(gpsLon), y = Geo.latToY(gpsLat);
        Route.Fix f = r.locate(x, y, lastSeg);
        lastSeg = f.seg;
        fix = f;
        double limit = Math.max(50.0, gpsAccuracy * 2.0);
        if (f.off > limit) {
            offCount++;
            if (offCount >= 3) {
                offCount = 0;
                planBase += viaPassed(r, f.along);
                requestRoute(true);
            }
            return;
        }
        offCount = 0;
        if (f.nextMan >= r.maneuvers.size() || f.remaining < 20) {
            speak("Anda telah tiba di tujuan");
            setStatus("Tiba di tujuan");
            route = null;
            fix = null;
            plan.clear();
            planBase = 0;
            return;
        }
        Route.Maneuver m = r.maneuvers.get(f.nextMan);
        if (m.type == Route.T_ARRIVE && f.toNext < 20) {
            speak("Anda telah tiba di tujuan");
            setStatus("Tiba di tujuan");
            route = null;
            fix = null;
            plan.clear();
            planBase = 0;
            return;
        }
        final int[] thr = {400, 150, 30};
        for (int k = 0; k < thr.length; k++) {
            int bit = 1 << k;
            if (f.toNext <= thr[k] && (announced[f.nextMan] & bit) == 0) {
                // mark this and all larger distances as done so they are not spoken late
                for (int j = 0; j <= k; j++) announced[f.nextMan] |= 1 << j;
                String when = k == 2 ? "Sekarang, " : "Dalam " + spokenDist(thr[k]) + ", ";
                speak(when + spoken(maneuverText(m)));
                break;
            }
        }
    }

    private int viaPassed(Route r, double along) {
        int n = 0;
        for (Route.Maneuver m : r.maneuvers) if (m.type == Route.T_VIA && m.at <= along + 15) n++;
        return n;
    }

    private void speak(String s) {
        if (optVoice && host != null) host.onSpeak(s);
    }

    // ------------------------------------------------------------------ text helpers

    private static String maneuverText(Route.Maneuver m) {
        String base;
        switch (m.type) {
            case Route.T_SLIGHT_LEFT:
                base = "Serong kiri";
                break;
            case Route.T_LEFT:
                base = "Belok kiri";
                break;
            case Route.T_SHARP_LEFT:
                base = "Belok tajam ke kiri";
                break;
            case Route.T_SLIGHT_RIGHT:
                base = "Serong kanan";
                break;
            case Route.T_RIGHT:
                base = "Belok kanan";
                break;
            case Route.T_SHARP_RIGHT:
                base = "Belok tajam ke kanan";
                break;
            case Route.T_UTURN:
                base = "Putar balik";
                break;
            case Route.T_ROUNDABOUT:
                base = "Bundaran, ambil jalan keluar ke-" + Math.max(1, m.exit);
                break;
            case Route.T_VIA:
                return "Tiba di titik singgah";
            case Route.T_ARRIVE:
                return "Tiba di tujuan";
            default:
                base = "Lurus";
                break;
        }
        return m.road != null && m.road.length() > 0 ? base + " ke " + m.road : base;
    }

    private static String spoken(String s) {
        return s.toLowerCase(Locale.US);
    }

    static String fmtDist(double m) {
        if (m < 1000) {
            int v = (int) Math.round(m);
            if (v >= 100) v = (v + 5) / 10 * 10;
            return v + " m";
        }
        return String.format(Locale.US, "%.1f km", m / 1000.0);
    }

    static String spokenDist(double m) {
        if (m < 1000) return (int) Math.round(m / 10.0) * 10 + " meter";
        return String.format(Locale.US, "%.1f kilometer", m / 1000.0).replace('.', ',');
    }

    static String fmtTime(double sec) {
        int min = (int) Math.round(sec / 60.0);
        if (min < 1) return "1 mnt";
        if (min < 60) return min + " mnt";
        return (min / 60) + " j " + String.format(Locale.US, "%02d", min % 60) + " mnt";
    }

    // ------------------------------------------------------------------ input

    private void pan(double dxPx, double dyPx) {
        double upp = unitsPerPx();
        cx = Math.max(0, Math.min(Geo.SPAN - 1, cx + dxPx * upp));
        cy = Math.max(0, Math.min(Geo.SPAN - 1, cy + dyPx * upp));
        followGps = false;
        info = "";
        invalidate();
    }

    private void zoomBy(int d) {
        int z = Math.max(minZoom, Math.min(maxZoom, zoom + d));
        if (z != zoom) {
            zoom = z;
            info = "";
            invalidate();
        }
    }

    private void press(int id) {
        switch (id) {
            case B_OUT:
                zoomBy(-1);
                break;
            case B_IN:
                zoomBy(1);
                break;
            case B_MENU:
                openPanel(P_MENU);
                break;
            case B_ROUTE:
                openPanel(P_ROUTE);
                break;
            case B_WP:
                openPanel(P_WP);
                break;
            case B_GPS:
                if (host != null) host.onGpsToggle();
                break;
            default:
                break;
        }
    }

    /** Name of the closest named object to a point (31-bit coords), or null. */
    private String nearestName(double x, double y) {
        Loaded ld = loaded;
        if (ld == null) return null;
        double bestD = 40 * density * unitsPerPx();
        bestD *= bestD;
        Feature best = null;
        for (Feature f : ld.feats) {
            if (f.name == null) continue;
            for (int i = 0; i < f.xy.length; i += 2) {
                double dx = f.xy[i] - x, dy = f.xy[i + 1] - y;
                double d = dx * dx + dy * dy;
                if (d < bestD) {
                    bestD = d;
                    best = f;
                }
            }
        }
        return best == null ? null : best.name;
    }

    /** Describes the nearest named object around the crosshair. */
    private void identify() {
        Loaded ld = loaded;
        info = "";
        if (ld == null || reader == null) return;
        double bestD = 40 * density * unitsPerPx();
        bestD *= bestD;
        Feature best = null;
        for (Feature f : ld.feats) {
            if (f.name == null) continue;
            for (int i = 0; i < f.xy.length; i += 2) {
                double dx = f.xy[i] - cx, dy = f.xy[i + 1] - cy;
                double d = dx * dx + dy * dy;
                if (d < bestD) {
                    bestD = d;
                    best = f;
                }
            }
        }
        info = best == null ? "(tidak ada objek bernama)" : best.name + " [" + describe(best) + "]";
        invalidate();
    }

    private String describe(Feature f) {
        if (f.toll) return "jalan tol";
        switch (f.cls) {
            case Style.MOTORWAY:
                return "motorway";
            case Style.TRUNK:
                return "trunk";
            case Style.PRIMARY:
                return "primary";
            case Style.SECONDARY:
                return "secondary";
            case Style.TERTIARY:
                return "tertiary";
            case Style.MINOR:
                return "jalan";
            case Style.PLACE_BIG:
            case Style.PLACE_SMALL:
                return "tempat";
            case Style.WATER:
            case Style.WATERWAY:
                return "air";
            case Style.BUILDING:
                return "bangunan";
            default:
                return "objek";
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent e) {
        if (panel != P_NONE) {
            switch (keyCode) {
                case KeyEvent.KEYCODE_DPAD_UP:
                    movePanelSel(-1);
                    return true;
                case KeyEvent.KEYCODE_DPAD_DOWN:
                    movePanelSel(1);
                    return true;
                case KeyEvent.KEYCODE_DPAD_CENTER:
                case KeyEvent.KEYCODE_ENTER:
                    if (e.getRepeatCount() == 0) activate(panelSel);
                    return true;
                case KeyEvent.KEYCODE_BACK:
                case KeyEvent.KEYCODE_ESCAPE:
                    if (panel == P_WPACT) openPanel(P_WP);
                    else closePanel();
                    return true;
                default:
                    return true;
            }
        }
        float step = Math.min(getWidth(), getHeight()) / 6f;
        if (e.getRepeatCount() > 8) step *= 3;
        switch (keyCode) {
            case KeyEvent.KEYCODE_DPAD_LEFT:
                pan(-step, 0);
                return true;
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                pan(step, 0);
                return true;
            case KeyEvent.KEYCODE_DPAD_UP:
                pan(0, -step);
                return true;
            case KeyEvent.KEYCODE_DPAD_DOWN:
                pan(0, step);
                return true;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
                if (e.getRepeatCount() == 0) identify();
                return true;
            case KeyEvent.KEYCODE_PLUS:
            case KeyEvent.KEYCODE_EQUALS:
            case KeyEvent.KEYCODE_NUMPAD_ADD:
            case KeyEvent.KEYCODE_PAGE_UP:
            case KeyEvent.KEYCODE_VOLUME_UP:
                if (e.getRepeatCount() == 0) zoomBy(1);
                return true;
            case KeyEvent.KEYCODE_MINUS:
            case KeyEvent.KEYCODE_NUMPAD_SUBTRACT:
            case KeyEvent.KEYCODE_PAGE_DOWN:
            case KeyEvent.KEYCODE_VOLUME_DOWN:
                if (e.getRepeatCount() == 0) zoomBy(-1);
                return true;
            case KeyEvent.KEYCODE_O:
                if (host != null) host.onOpenRequest();
                return true;
            case KeyEvent.KEYCODE_MENU:
            case KeyEvent.KEYCODE_M:
                openPanel(P_MENU);
                return true;
            case KeyEvent.KEYCODE_R:
                openPanel(P_ROUTE);
                return true;
            case KeyEvent.KEYCODE_W:
                openPanel(P_WP);
                return true;
            case KeyEvent.KEYCODE_G:
                press(B_GPS);
                return true;
            case KeyEvent.KEYCODE_I:
                setInverted(!inverted);
                changed();
                return true;
            case KeyEvent.KEYCODE_N:
                showNames = !showNames;
                changed();
                invalidate();
                return true;
            case KeyEvent.KEYCODE_Q:
                if (host != null) host.onQuit();
                return true;
            default:
                return super.onKeyDown(keyCode, e);
        }
    }

    private void movePanelSel(int d) {
        int n = items.size();
        if (n == 0) return;
        panelSel = Math.max(0, Math.min(n - 1, panelSel + d));
        float rowH = 68 * density;
        float top = panelSel * rowH, bottom = top + rowH, areaH = panelBottom - panelTop;
        if (top < panelScroll) panelScroll = top;
        if (bottom > panelScroll + areaH) panelScroll = bottom - areaH;
        invalidate();
    }

    private boolean hit(Button b, float x, float y) {
        return b.r.contains(x, y);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getAction()) {
            case MotionEvent.ACTION_DOWN:
                downX = lastX = e.getX();
                downY = lastY = e.getY();
                dragged = false;
                return true;
            case MotionEvent.ACTION_MOVE: {
                float dx = e.getX() - lastX, dy = e.getY() - lastY;
                if (!dragged && Math.hypot(e.getX() - downX, e.getY() - downY) > 8 * density) dragged = true;
                if (dragged) {
                    if (panel != P_NONE) {
                        float max = Math.max(0, items.size() * 68 * density - (panelBottom - panelTop));
                        panelScroll = Math.max(0, Math.min(max, panelScroll - dy));
                        invalidate();
                    } else {
                        pan(-dx, -dy);
                    }
                }
                lastX = e.getX();
                lastY = e.getY();
                return true;
            }
            case MotionEvent.ACTION_UP:
                if (dragged) return true;
                if (panel != P_NONE) {
                    float x = e.getX(), y = e.getY();
                    if (hit(closeBtn, x, y)) {
                        if (panel == P_WPACT) openPanel(P_WP);
                        else closePanel();
                    } else if (y >= panelTop && y < panelBottom) {
                        activate((int) ((y - panelTop + panelScroll) / (68 * density)));
                    }
                    return true;
                }
                if (hit(zoomIn, e.getX(), e.getY())) {
                    press(B_IN);
                    return true;
                }
                if (hit(zoomOut, e.getX(), e.getY())) {
                    press(B_OUT);
                    return true;
                }
                for (Button b : mainButtons) {
                    if (hit(b, e.getX(), e.getY())) {
                        press(b.id);
                        return true;
                    }
                }
                // a tap on the map moves the crosshair there and identifies the object
                double upp = unitsPerPx();
                cx += (e.getX() - getWidth() / 2f) * upp;
                cy += (e.getY() - getHeight() / 2f) * upp;
                followGps = false;
                identify();
                return true;
            default:
                return true;
        }
    }
}
