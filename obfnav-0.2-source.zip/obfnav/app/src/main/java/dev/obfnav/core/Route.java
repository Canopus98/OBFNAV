package dev.obfnav.core;

import java.util.ArrayList;
import java.util.List;

/** A computed route: polyline in 31-bit coordinates, cumulative distances and turn instructions. */
public final class Route {
    public static final int T_STRAIGHT = 0, T_SLIGHT_LEFT = 1, T_LEFT = 2, T_SHARP_LEFT = 3,
            T_SLIGHT_RIGHT = 4, T_RIGHT = 5, T_SHARP_RIGHT = 6, T_UTURN = 7, T_ROUNDABOUT = 8,
            T_VIA = 9, T_ARRIVE = 10;

    public static final class Maneuver {
        public int type;
        /** Roundabout exit number (1-based), otherwise 0. */
        public int exit;
        /** Index of the polyline point where it happens. */
        public int pt;
        /** Distance from the route start, in meters. */
        public double at;
        /** Name of the road entered after the maneuver (may be null). */
        public String road;
    }

    /** Result of matching a position to the route. */
    public static final class Fix {
        public int seg;
        /** Meters travelled along the route. */
        public double along;
        /** Meters between the position and the route. */
        public double off;
        public int nextMan;
        public double toNext;
        public double remaining;
    }

    public int[] xy = new int[0];
    public double[] cum = new double[0];
    public final List<Maneuver> maneuvers = new ArrayList<Maneuver>();
    public double length;
    public double seconds;
    public double tollMeters;
    /** m per 31-bit unit used for all distances of this route. */
    public double mPerUnit = 0.0187;
    public String note;

    public int size() {
        return xy.length / 2;
    }

    /** Appends another leg (its first point is assumed to equal this route's last point). */
    void append(Route leg, boolean lastLeg) {
        if (xy.length == 0) {
            xy = leg.xy.clone();
            cum = leg.cum.clone();
            maneuvers.addAll(leg.maneuvers);
            length = leg.length;
            seconds = leg.seconds;
            tollMeters = leg.tollMeters;
            mPerUnit = leg.mPerUnit;
            if (!lastLeg) markVia(maneuvers);
            return;
        }
        int n0 = size();
        int[] nx = new int[xy.length + leg.xy.length - 2];
        System.arraycopy(xy, 0, nx, 0, xy.length);
        System.arraycopy(leg.xy, 2, nx, xy.length, leg.xy.length - 2);
        double[] nc = new double[cum.length + leg.cum.length - 1];
        System.arraycopy(cum, 0, nc, 0, cum.length);
        for (int i = 1; i < leg.cum.length; i++) nc[cum.length + i - 1] = length + leg.cum[i];
        for (Maneuver m : leg.maneuvers) {
            Maneuver c = new Maneuver();
            c.type = m.type;
            c.exit = m.exit;
            c.pt = m.pt + n0 - 1;
            c.at = m.at + length;
            c.road = m.road;
            maneuvers.add(c);
        }
        xy = nx;
        cum = nc;
        length += leg.length;
        seconds += leg.seconds;
        tollMeters += leg.tollMeters;
        if (!lastLeg) markVia(maneuvers);
    }

    private static void markVia(List<Maneuver> ms) {
        if (!ms.isEmpty() && ms.get(ms.size() - 1).type == T_ARRIVE) ms.get(ms.size() - 1).type = T_VIA;
    }

    /**
     * Matches a position to the route. Looks near {@code fromSeg} first (cheap, avoids jumping to a
     * parallel stretch of the route); falls back to a full search when that is far from the route.
     */
    public Fix locate(double x, double y, int fromSeg) {
        int n = size() - 1;
        Fix best = new Fix();
        if (n < 1) {
            best.off = Double.MAX_VALUE;
            return best;
        }
        int lo = Math.max(0, fromSeg - 3), hi = Math.min(n, fromSeg + 120);
        double bestD = scan(x, y, lo, hi, best);
        if (bestD * mPerUnit > 80.0 && (lo > 0 || hi < n)) {
            bestD = Math.min(bestD, scan(x, y, 0, n, best, bestD));
        }
        best.off = Math.sqrt(bestD) * mPerUnit;
        best.remaining = Math.max(0, length - best.along);
        best.nextMan = maneuvers.size();
        for (int i = 0; i < maneuvers.size(); i++) {
            if (maneuvers.get(i).at > best.along - 8.0) {
                best.nextMan = i;
                break;
            }
        }
        best.toNext = best.nextMan < maneuvers.size() ? Math.max(0, maneuvers.get(best.nextMan).at - best.along) : 0;
        return best;
    }

    private double scan(double x, double y, int lo, int hi, Fix out) {
        return scan(x, y, lo, hi, out, Double.MAX_VALUE);
    }

    private double scan(double x, double y, int lo, int hi, Fix out, double bestD) {
        for (int i = lo; i < hi; i++) {
            double ax = xy[2 * i], ay = xy[2 * i + 1], bx = xy[2 * i + 2], by = xy[2 * i + 3];
            double dx = bx - ax, dy = by - ay;
            double l2 = dx * dx + dy * dy;
            double t = l2 == 0 ? 0 : ((x - ax) * dx + (y - ay) * dy) / l2;
            if (t < 0) t = 0;
            if (t > 1) t = 1;
            double px = ax + t * dx - x, py = ay + t * dy - y;
            double d = px * px + py * py;
            if (d < bestD) {
                bestD = d;
                out.seg = i;
                out.along = cum[i] + t * (cum[i + 1] - cum[i]);
            }
        }
        return bestD;
    }
}
