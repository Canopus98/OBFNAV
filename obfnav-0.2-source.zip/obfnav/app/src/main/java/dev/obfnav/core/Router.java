package dev.obfnav.core;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;

/**
 * Offline router working on the road geometry of the OBF MAP section (no routing section needed).
 *
 * <p>Junctions are detected where two ways share an identical vertex coordinate. A* runs on the
 * vertex graph. Limits of this approach: no turn restrictions (not present in the map section), and
 * one-way / toll / access information is only as good as the tags OsmAnd kept in the map section.
 */
public final class Router {
    public static final int CAR = 0, MOTO = 1;
    /** In Indonesia motorcycles may not use toll roads; set false for countries where they may. */
    public static final boolean MOTO_BANNED_ON_TOLL = true;
    private static final int MAX_VERTICES = 3000000;
    private static final double SNAP_MAX_M = 500.0;

    public static final class Options {
        public int vehicle = CAR;
        public boolean avoidToll;
        /** true = shortest distance, false = fastest time. */
        public boolean shortest;
    }

    public static final class RouteException extends Exception {
        public RouteException(String m) {
            super(m);
        }
    }

    // ------------------------------------------------------------------ graph storage

    private final Options opt;
    private int[] xy = new int[1 << 14];
    private int nV;
    private int[] wayOf = new int[1 << 13];
    private int[] link = new int[0];
    private int nW;
    private int[] wStart = new int[1024], wEnd = new int[1024], wFlags = new int[1024];
    private byte[] wDir = new byte[1024], wCls = new byte[1024];
    private boolean[] wToll = new boolean[1024];
    private float[] wMps = new float[1024];
    private String[] wName = new String[1024];
    private double mPerUnit = 0.0187;
    private final double vmax; // m/s
    private final HashSet<Long> seen = new HashSet<Long>();
    public boolean hasOnewayInfo = true;
    private boolean overflow;

    public Router(Options o) {
        this.opt = o;
        this.vmax = (o.vehicle == MOTO ? 70 : 90) / 3.6;
    }

    private double defaultKmh(int cls) {
        boolean m = opt.vehicle == MOTO;
        switch (cls) {
            case Style.MOTORWAY:
                return 80;
            case Style.TRUNK:
                return m ? 55 : 60;
            case Style.PRIMARY:
                return m ? 45 : 50;
            case Style.SECONDARY:
                return 40;
            case Style.TERTIARY:
                return 35;
            case Style.MINOR:
                return m ? 28 : 25;
            default:
                return m ? 20 : 12; // tracks
        }
    }

    /** Adds a way if it can be used by the selected vehicle. Returns false when skipped. */
    public boolean addWay(int[] pts, int cls, int flags, int maxKmh, String name, long id) {
        if (opt.vehicle == CAR ? (cls < Style.MINOR || cls > Style.MOTORWAY)
                : (cls < Style.TRACK || cls > Style.MOTORWAY)) return false;
        if (opt.vehicle == CAR) {
            if ((flags & Style.F_NOCAR) != 0 && (flags & Style.F_CARYES) == 0) return false;
        } else if ((flags & Style.F_NOMOTO) != 0 && (flags & Style.F_MOTOYES) == 0) return false;
        if (id != 0 && !seen.add(id)) return false;
        if (nV + pts.length / 2 > MAX_VERTICES) {
            overflow = true;
            return false;
        }
        int cnt = 0;
        int first = nV;
        for (int i = 0; i < pts.length; i += 2) {
            if (nV > first && xy[2 * (nV - 1)] == pts[i] && xy[2 * (nV - 1) + 1] == pts[i + 1]) continue;
            if (2 * nV + 2 > xy.length) {
                xy = Arrays.copyOf(xy, xy.length * 2);
            }
            if (nV + 1 > wayOf.length) wayOf = Arrays.copyOf(wayOf, wayOf.length * 2);
            xy[2 * nV] = pts[i];
            xy[2 * nV + 1] = pts[i + 1];
            wayOf[nV] = nW;
            nV++;
            cnt++;
        }
        if (cnt < 2) {
            nV = first;
            return false;
        }
        if (nW == wStart.length) {
            int c = nW * 2;
            wStart = Arrays.copyOf(wStart, c);
            wEnd = Arrays.copyOf(wEnd, c);
            wFlags = Arrays.copyOf(wFlags, c);
            wDir = Arrays.copyOf(wDir, c);
            wCls = Arrays.copyOf(wCls, c);
            wToll = Arrays.copyOf(wToll, c);
            wMps = Arrays.copyOf(wMps, c);
            wName = Arrays.copyOf(wName, c);
        }
        int w = nW++;
        wStart[w] = first;
        wEnd[w] = nV;
        wFlags[w] = flags;
        wCls[w] = (byte) cls;
        wName[w] = name;
        wToll[w] = Style.isToll(cls, flags, name);
        int dir = 0;
        if ((flags & Style.F_ONEWAY) != 0) dir = 1;
        else if ((flags & Style.F_ONEWAY_REV) != 0) dir = -1;
        else if ((flags & Style.F_ONEWAY_NO) == 0 && ((flags & Style.F_ROUNDABOUT) != 0 || cls == Style.MOTORWAY)) dir = 1;
        wDir[w] = (byte) dir;
        double kmh = maxKmh > 0 ? Math.min(defaultKmh(cls), maxKmh * 0.85) : defaultKmh(cls);
        if (maxKmh > 0 && maxKmh * 0.85 > defaultKmh(cls)) kmh = Math.min(maxKmh * 0.85, vmax * 3.6);
        wMps[w] = (float) Math.max(1.5, Math.min(vmax, kmh / 3.6));
        return true;
    }

    private void buildLinks() {
        link = new int[nV];
        int cap = 1;
        while (cap < nV * 2) cap <<= 1;
        int[] table = new int[cap];
        int mask = cap - 1;
        for (int v = 0; v < nV; v++) {
            int x = xy[2 * v], y = xy[2 * v + 1];
            int h = (x * 0x9E3779B1 ^ y * 0x85EBCA6B);
            h ^= h >>> 15;
            int slot = h & mask;
            while (true) {
                int e = table[slot];
                if (e == 0) {
                    table[slot] = v + 1;
                    link[v] = v;
                    break;
                }
                int f = e - 1;
                if (xy[2 * f] == x && xy[2 * f + 1] == y) {
                    link[v] = link[f];
                    link[f] = v;
                    break;
                }
                slot = (slot + 1) & mask;
            }
        }
    }

    // ------------------------------------------------------------------ loading from OBF

    /** Reads every road in the rectangle (31-bit coordinates) into this router. */
    public void load(ObfReader reader, int l, int r, int t, int b) throws IOException {
        for (ObfReader.MapIndex mi : reader.getMaps()) {
            if (mi.levels.isEmpty()) continue;
            final int[] rc = Style.buildRuleClasses(mi);
            final int[] rf = Style.buildRuleFlags(mi);
            final int[] rs = Style.buildRuleSpeeds(mi);
            if (!Style.hasRuleTag(mi, "oneway")) hasOnewayInfo = false;
            reader.search(mi, l, r, t, b, Math.min(22, mi.maxZoom()), new ObfReader.FeatureSink() {
                @Override
                public boolean accept(ObfReader.MapIndex map, Feature f) {
                    if (f.area) return true;
                    int cls = Style.classOf(rc, f.types);
                    if (cls < Style.TRACK || cls > Style.MOTORWAY) return true;
                    int fl = 0, sp = 0;
                    for (int ty : f.types) {
                        if (ty >= 0 && ty < rf.length) {
                            fl |= rf[ty];
                            if (sp == 0) sp = rs[ty];
                        }
                    }
                    addWay(f.xy, cls, fl, sp, f.name, f.id);
                    return !overflow;
                }
            });
        }
    }

    // ------------------------------------------------------------------ public entry point

    /**
     * Computes a route through the given points (x,y pairs in 31-bit coordinates): origin, optional via
     * points, destination.
     */
    public static Route route(ObfReader reader, List<int[]> pts, Options o) throws IOException, RouteException {
        if (pts.size() < 2) throw new RouteException("Butuh asal dan tujuan");
        int minX = Integer.MAX_VALUE, maxX = 0, minY = Integer.MAX_VALUE, maxY = 0;
        for (int[] p : pts) {
            minX = Math.min(minX, p[0]);
            maxX = Math.max(maxX, p[0]);
            minY = Math.min(minY, p[1]);
            maxY = Math.max(maxY, p[1]);
        }
        double mpu = metersPerUnit(Geo.yToLat((minY + (double) maxY) / 2));
        double span = Math.max(maxX - (double) minX, maxY - (double) minY);
        double[] factors = {0.25, 0.8, 2.0};
        RouteException last = null;
        for (int attempt = 0; attempt < factors.length; attempt++) {
            double m = span * factors[attempt] + 2500.0 / mpu * (attempt + 1);
            Router rt = new Router(o);
            rt.mPerUnit = mpu;
            rt.load(reader, (int) Math.max(0, minX - m), (int) Math.min(Integer.MAX_VALUE, maxX + m),
                    (int) Math.max(0, minY - m), (int) Math.min(Integer.MAX_VALUE, maxY + m));
            if (rt.nV == 0) {
                last = new RouteException("Tidak ada data jalan di peta untuk area ini");
                continue;
            }
            rt.buildLinks();
            try {
                Route r = rt.routeLegs(pts);
                if (rt.overflow) r.note = join(r.note, "Area terlalu luas, rute mungkin tidak optimal");
                if (!rt.hasOnewayInfo) r.note = join(r.note, "Peta tidak memuat data jalan satu arah");
                return r;
            } catch (RouteException e) {
                last = e;
                if (rt.overflow) break;
            }
        }
        throw last != null ? last : new RouteException("Rute tidak ditemukan");
    }

    private static String join(String a, String b) {
        return a == null ? b : a + "; " + b;
    }

    public static double metersPerUnit(double lat) {
        return 40075016.686 / Geo.SPAN * Math.cos(Math.toRadians(lat));
    }

    // ------------------------------------------------------------------ routing

    /** For tests / callers that add ways themselves: finish the graph, then call {@link #routeThrough}. */
    public void prepare(double lat) {
        mPerUnit = metersPerUnit(lat);
        buildLinks();
    }

    public Route routeThrough(List<int[]> pts) throws RouteException {
        return routeLegs(pts);
    }

    private Route routeLegs(List<int[]> pts) throws RouteException {
        boolean forceNoToll = opt.vehicle == MOTO && MOTO_BANNED_ON_TOLL;
        int tollMode = (opt.avoidToll || forceNoToll) ? 1 : 0;
        Route total = new Route();
        total.mPerUnit = mPerUnit;
        String note = null;
        for (int i = 0; i + 1 < pts.size(); i++) {
            Route leg;
            try {
                leg = leg(pts.get(i), pts.get(i + 1), tollMode);
            } catch (RouteException e) {
                if (tollMode == 1 && !forceNoToll) {
                    leg = leg(pts.get(i), pts.get(i + 1), 0);
                    note = join(note, "Tidak ada rute tanpa tol, terpaksa lewat tol");
                } else if (forceNoToll) {
                    throw new RouteException(e.getMessage() + " (motor tidak boleh lewat tol)");
                } else {
                    throw e;
                }
            }
            total.append(leg, i + 2 == pts.size());
        }
        total.note = note;
        return total;
    }

    private boolean forbidden(int w, int tollMode) {
        return tollMode == 1 && wToll[w];
    }

    private static final class Snap {
        int a;          // vertex index of segment start (segment a -> a+1)
        double t;       // 0..1 position along the segment
        double px, py;  // projected point
        double d2;      // squared distance in units
    }

    private Snap snap(int x, int y, int tollMode) throws RouteException {
        Snap best = null;
        for (int v = 0; v + 1 < nV; v++) {
            int w = wayOf[v];
            if (wayOf[v + 1] != w || forbidden(w, tollMode)) continue;
            double ax = xy[2 * v], ay = xy[2 * v + 1], dx = xy[2 * v + 2] - ax, dy = xy[2 * v + 3] - ay;
            double l2 = dx * dx + dy * dy;
            double t = l2 == 0 ? 0 : ((x - ax) * dx + (y - ay) * dy) / l2;
            t = Math.max(0, Math.min(1, t));
            double px = ax + t * dx, py = ay + t * dy;
            double d2 = (px - x) * (px - x) + (py - y) * (py - y);
            if (best == null || d2 < best.d2) {
                if (best == null) best = new Snap();
                best.a = v;
                best.t = t;
                best.px = px;
                best.py = py;
                best.d2 = d2;
            }
        }
        if (best == null) throw new RouteException("Tidak ada jalan di sekitar titik");
        double m = Math.sqrt(best.d2) * mPerUnit;
        if (m > SNAP_MAX_M) throw new RouteException("Titik terlalu jauh dari jalan (" + (int) m + " m)");
        return best;
    }

    private double segLen(int v) {
        double dx = xy[2 * v + 2] - xy[2 * v], dy = xy[2 * v + 3] - xy[2 * v + 1];
        return Math.sqrt(dx * dx + dy * dy) * mPerUnit;
    }

    private double cost(double meters, int w) {
        return opt.shortest ? meters : meters / wMps[w];
    }

    // ---- tiny binary heap (lazy deletion)
    private int[] hNode = new int[1024];
    private float[] hKey = new float[1024];
    private int hSize;

    private void push(int n, float k) {
        if (hSize == hNode.length) {
            hNode = Arrays.copyOf(hNode, hSize * 2);
            hKey = Arrays.copyOf(hKey, hSize * 2);
        }
        int i = hSize++;
        while (i > 0) {
            int p = (i - 1) >> 1;
            if (hKey[p] <= k) break;
            hNode[i] = hNode[p];
            hKey[i] = hKey[p];
            i = p;
        }
        hNode[i] = n;
        hKey[i] = k;
    }

    private int pop() {
        int top = hNode[0];
        hSize--;
        if (hSize > 0) {
            int n = hNode[hSize];
            float k = hKey[hSize];
            int i = 0;
            while (true) {
                int c = 2 * i + 1;
                if (c >= hSize) break;
                if (c + 1 < hSize && hKey[c + 1] < hKey[c]) c++;
                if (hKey[c] >= k) break;
                hNode[i] = hNode[c];
                hKey[i] = hKey[c];
                i = c;
            }
            hNode[i] = n;
            hKey[i] = k;
        }
        return top;
    }

    private Route leg(int[] from, int[] to, int tollMode) throws RouteException {
        Snap s = snap(from[0], from[1], tollMode);
        Snap g = snap(to[0], to[1], tollMode);
        final int T = nV; // virtual goal node
        float[] gc = new float[nV + 1];
        Arrays.fill(gc, Float.MAX_VALUE);
        int[] prev = new int[nV + 1];
        Arrays.fill(prev, -2);
        boolean[] closed = new boolean[nV + 1];
        hSize = 0;

        int sw = wayOf[s.a], gw = wayOf[g.a];
        double sLen = segLen(s.a), gLen = segLen(g.a);
        int sDir = wDir[sw], gDir = wDir[gw];
        double direct = Double.MAX_VALUE;
        if (s.a == g.a) {
            double dl = Math.abs(g.t - s.t) * sLen;
            boolean fwd = g.t >= s.t;
            if ((fwd && sDir >= 0) || (!fwd && sDir <= 0)) direct = cost(dl, sw);
        }
        final double tx = to[0], ty = to[1];
        // start candidates
        if (sDir <= 0) startNode(s.a, cost(s.t * sLen, sw), gc, prev, tx, ty);
        if (sDir >= 0) startNode(s.a + 1, cost((1 - s.t) * sLen, sw), gc, prev, tx, ty);
        double goalA = gDir >= 0 ? cost(g.t * gLen, gw) : -1;        // reach T from a (travel forward)
        double goalB = gDir <= 0 ? cost((1 - g.t) * gLen, gw) : -1;  // reach T from b (travel backward)

        int found = -1;
        while (hSize > 0) {
            int v = pop();
            if (closed[v]) continue;
            closed[v] = true;
            if (v == T) {
                found = T;
                break;
            }
            float gv = gc[v];
            if (gv >= direct) break; // direct on-segment travel already beats everything left
            if (v == g.a && goalA >= 0) relax(v, T, gv + (float) goalA, gc, prev, 0.0);
            if (v == g.a + 1 && goalB >= 0) relax(v, T, gv + (float) goalB, gc, prev, 0.0);
            int w = wayOf[v];
            if (v + 1 < wEnd[w] && wDir[w] >= 0) {
                int u = v + 1;
                if (!closed[u]) relax(v, u, gv + (float) cost(segLen(v), w), gc, prev, h(u, tx, ty));
            }
            if (v - 1 >= wStart[w] && wDir[w] <= 0) {
                int u = v - 1;
                if (!closed[u]) relax(v, u, gv + (float) cost(segLen(u), w), gc, prev, h(u, tx, ty));
            }
            for (int u = link[v]; u != v; u = link[u]) {
                if (!closed[u] && !forbidden(wayOf[u], tollMode)) relax(v, u, gv, gc, prev, h(u, tx, ty));
            }
        }
        double viaGraph = found == T ? gc[T] : Double.MAX_VALUE;
        if (direct == Double.MAX_VALUE && found != T) throw new RouteException("Rute tidak ditemukan");

        // assemble polyline
        IntList px = new IntList();
        if (direct <= viaGraph) {
            px.add2((int) Math.round(s.px), (int) Math.round(s.py));
            px.add2((int) Math.round(g.px), (int) Math.round(g.py));
            return build(px, new int[]{-1, sw}, new int[]{-1, -1}, g.a, g.a);
        }
        // walk back from T
        IntList path = new IntList();
        int v = prev[T];
        while (v >= 0) {
            path.add(v);
            v = prev[v];
        }
        path.reverse();
        px.add2((int) Math.round(s.px), (int) Math.round(s.py));
        int[] segWay = new int[path.size + 4];
        int[] segVtx = new int[path.size + 4];
        int np = 1;
        segWay[0] = -1;
        segVtx[0] = -1;
        for (int i = 0; i < path.size; i++) {
            int vx = path.get(i);
            int x = xy[2 * vx], y = xy[2 * vx + 1];
            int lx = px.get(px.size - 2), ly = px.get(px.size - 1);
            if (x == lx && y == ly) {
                segVtx[np - 1] = vx; // transfer at the same coordinate: remember arrival vertex
                continue;
            }
            // way of the segment from the previous point: the way of the previous path vertex
            int pw = i > 0 ? wayOf[path.get(i - 1)] : (wayOf[vx]);
            if (i == 0) pw = wayOf[vx];
            if (np >= segWay.length) {
                segWay = Arrays.copyOf(segWay, segWay.length * 2);
                segVtx = Arrays.copyOf(segVtx, segVtx.length * 2);
            }
            px.add2(x, y);
            segWay[np] = pw;
            segVtx[np] = vx;
            np++;
        }
        int ex = (int) Math.round(g.px), ey = (int) Math.round(g.py);
        if (np >= segWay.length) {
            segWay = Arrays.copyOf(segWay, segWay.length + 2);
            segVtx = Arrays.copyOf(segVtx, segVtx.length + 2);
        }
        if (!(px.get(px.size - 2) == ex && px.get(px.size - 1) == ey)) {
            px.add2(ex, ey);
            segWay[np] = gw;
            segVtx[np] = g.a;
            np++;
        }
        return build(px, Arrays.copyOf(segWay, np), Arrays.copyOf(segVtx, np), g.a, g.a);
    }

    private double h(int u, double tx, double ty) {
        double dx = xy[2 * u] - tx, dy = xy[2 * u + 1] - ty;
        double m = Math.sqrt(dx * dx + dy * dy) * mPerUnit;
        return opt.shortest ? m : m / vmax;
    }

    private void startNode(int v, double c, float[] gc, int[] prev, double tx, double ty) {
        if (c < gc[v]) {
            gc[v] = (float) c;
            prev[v] = -1;
            push(v, (float) (c + h(v, tx, ty)));
        }
    }

    private void relax(int from, int to, float ng, float[] gc, int[] prev, double hv) {
        if (ng < gc[to]) {
            gc[to] = ng;
            prev[to] = from;
            push(to, (float) (ng + hv));
        }
    }

    // ------------------------------------------------------------------ route construction

    /** Number of segments touching this coordinate (a junction has 3 or more). */
    private int degree(int v) {
        int d = 0;
        int u = v;
        do {
            int w = wayOf[u];
            if (u > wStart[w]) d++;
            if (u + 1 < wEnd[w]) d++;
            u = link[u];
        } while (u != v);
        return d;
    }

    private static double bearing(double dx, double dy) {
        return Math.toDegrees(Math.atan2(dx, -dy));
    }

    private static double norm(double a) {
        while (a > 180) a -= 360;
        while (a <= -180) a += 360;
        return a;
    }

    /**
     * @param segWay way of the segment that ends at each point (index 0 unused)
     * @param segVtx vertex index reached at each point (or -1)
     */
    private Route build(IntList px, int[] segWay, int[] segVtx, int a, int b) {
        Route r = new Route();
        r.mPerUnit = mPerUnit;
        int n = px.size / 2;
        r.xy = Arrays.copyOf(px.a, px.size);
        r.cum = new double[n];
        for (int i = 1; i < n; i++) {
            double dx = r.xy[2 * i] - r.xy[2 * i - 2], dy = r.xy[2 * i + 1] - r.xy[2 * i - 1];
            double m = Math.sqrt(dx * dx + dy * dy) * mPerUnit;
            r.cum[i] = r.cum[i - 1] + m;
            int w = i < segWay.length ? segWay[i] : -1;
            if (w >= 0) {
                r.seconds += m / wMps[w];
                if (wToll[w]) r.tollMeters += m;
            }
        }
        r.length = r.cum[n - 1];

        Route.Maneuver round = null;
        int roundCount = 0;
        double lastAt = -1000;
        for (int i = 1; i + 1 < n; i++) {
            int wi = segWay[i], wo = segWay.length > i + 1 ? segWay[i + 1] : -1;
            if (wi < 0 || wo < 0) continue;
            boolean inR = (wFlags[wi] & Style.F_ROUNDABOUT) != 0, outR = (wFlags[wo] & Style.F_ROUNDABOUT) != 0;
            int vtx = segVtx.length > i ? segVtx[i] : -1;
            boolean sw = wi != wo;
            if (!inR && outR) {
                round = new Route.Maneuver();
                round.type = Route.T_ROUNDABOUT;
                round.pt = i;
                round.at = r.cum[i];
                round.road = null;
                roundCount = 0;
                r.maneuvers.add(round);
                lastAt = r.cum[i];
                continue;
            }
            if (inR && outR) {
                if (vtx >= 0 && degree(vtx) >= 3) roundCount++;
                if (round != null) round.exit = roundCount + 1;
                continue;
            }
            if (inR && !outR) {
                if (round != null) {
                    round.exit = Math.max(1, roundCount + 1);
                    round.road = wName[wo];
                    round = null;
                }
                continue;
            }
            // ordinary node
            double lenIn = 0;
            int j = i - 1;
            while (j > 0 && r.cum[i] - r.cum[j] < 15) j--;
            int k = i + 1;
            while (k < n - 1 && r.cum[k] - r.cum[i] < 15) k++;
            double b1 = bearing(r.xy[2 * i] - r.xy[2 * j], r.xy[2 * i + 1] - r.xy[2 * j + 1]);
            double b2 = bearing(r.xy[2 * k] - r.xy[2 * i], r.xy[2 * k + 1] - r.xy[2 * i + 1]);
            double d = norm(b2 - b1);
            double ad = Math.abs(d);
            boolean junction = sw || (vtx >= 0 && degree(vtx) >= 3);
            boolean emit = (junction && ad >= 25) || ad >= 60;
            if (!emit || r.cum[i] - lastAt < 25) continue;
            Route.Maneuver m = new Route.Maneuver();
            m.pt = i;
            m.at = r.cum[i];
            m.road = wName[wo];
            if (ad >= 170) m.type = Route.T_UTURN;
            else if (ad >= 135) m.type = d < 0 ? Route.T_SHARP_LEFT : Route.T_SHARP_RIGHT;
            else if (ad >= 45) m.type = d < 0 ? Route.T_LEFT : Route.T_RIGHT;
            else m.type = d < 0 ? Route.T_SLIGHT_LEFT : Route.T_SLIGHT_RIGHT;
            r.maneuvers.add(m);
            lastAt = m.at;
        }
        Route.Maneuver arr = new Route.Maneuver();
        arr.type = Route.T_ARRIVE;
        arr.pt = n - 1;
        arr.at = r.length;
        r.maneuvers.add(arr);
        return r;
    }

    // ------------------------------------------------------------------ small int list

    static final class IntList {
        int[] a = new int[64];
        int size;

        void add(int v) {
            if (size == a.length) a = Arrays.copyOf(a, size * 2);
            a[size++] = v;
        }

        void add2(int x, int y) {
            add(x);
            add(y);
        }

        int get(int i) {
            return a[i];
        }

        void reverse() {
            for (int i = 0, j = size - 1; i < j; i++, j--) {
                int t = a[i];
                a[i] = a[j];
                a[j] = t;
            }
        }
    }
}
