# OBFNav

Penampil peta offline yang sangat ringan untuk file **.obf** (format peta OsmAnd). Tanpa internet, tanpa library
pihak ketiga (hanya framework Android), tanpa animasi. Peta digambar sebagai garis vektor monokrom, dikendalikan lewat
D-pad/keyboard atau layar sentuh.

## Yang sudah bisa

**Peta (fase 1)**
- Membuka file `.obf` lewat pemilih file Android (memory-mapped, file besar tidak dimuat ke RAM).
- Jalan per kelas, rel, sungai, garis pantai, area air, bangunan, nama kota/desa, nama jalan di zoom tinggi.
- Pan/zoom, titik GPS dan mode ikuti GPS, tema terang/gelap, identifikasi objek bernama di tengah layar.

**Fase 2 (versi 0.2)**
- **Tombol besar**: zoom `+`/`-` 80 dp di sisi kanan, empat tombol bawah (MENU, RUTE, WP, GPS) setinggi 72 dp.
- **Palet jadul 8 warna, kontras tinggi**: laut dan danau biru, daratan hijau, jalan hitam, **jalan tol merah gelap**,
  rute magenta, waypoint kuning. Mode gelap (MENU > TEMA) membalik ke latar hijau tua.
  Laut diisi dari garis pantai (`natural=coastline`); kalau peta tidak punya garis pantai, latar tetap hijau.
- **Rute offline** untuk **mobil** dan **sepeda motor**, dihitung langsung dari geometri jalan di section peta
  (tidak butuh section routing).
- **Hindari tol** (mobil). Kalau satu-satunya jalan lewat tol, rute tetap dibuat dengan catatan "terpaksa lewat tol".
  **Motor otomatis tidak boleh masuk tol** (aturan Indonesia; ubah `Router.MOTO_BANNED_ON_TOLL` kalau perlu).
- **Tercepat atau terpendek**.
- **Peringatan tikungan**: banner besar di atas layar, misalnya panah + `200 m` + `Belok kiri ke Jl. Merdeka`.
  Ada juga bundaran (`ambil jalan keluar ke-3`), putar balik, titik singgah, dan tiba di tujuan.
  Suara Bahasa Indonesia (Text-to-speech bawaan HP) pada 400 m, 150 m, dan 30 m; bisa dimatikan di MENU.
- **Hitung ulang otomatis** kalau keluar jalur lebih dari 3 fix GPS berturut-turut.
- **Waypoint**: simpan di titik tengah atau posisi GPS, daftar, lihat di peta, navigasi ke sana, tambah sebagai
  tujuan akhir (tujuan sebelumnya jadi titik singgah), hapus. Tersimpan di perangkat.
- Opsi (kendaraan, tercepat/terpendek, tol, suara, nama, tema) diingat.

## Batasan yang perlu diketahui

- **Rute dihitung dari peta, bukan dari section routing OsmAnd.** Larangan belok, jalur khusus, dan lampu
  lalu lintas tidak diketahui. Satu arah, bundaran, `maxspeed`, dan akses kendaraan hanya dipakai kalau tag itu ikut
  tersimpan di section peta. Kalau peta tidak punya tag `oneway`, aplikasi memberi catatan di status rute.
- **Persimpangan** dikenali dari simpul yang koordinatnya sama persis di dua jalan. Jalan yang bersilangan tanpa
  simpul bersama (jembatan, terowongan) memang tidak dianggap bersimpangan.
- **Deteksi tol**: `toll=yes`, jalan kelas motorway (kecuali `toll=no`), atau nama yang mengandung kata "Tol".
  Aturannya ada di `Style.isToll`.
- Rute sangat jauh membutuhkan banyak RAM karena seluruh jalan di koridor rute dimuat. Aplikasi mencoba koridor
  yang makin lebar, lalu menyerah dengan pesan jelas kalau terlalu besar.
- Lubang pada poligon (inner polygon) tidak digambar. File di atas 2 GB belum didukung.
- Pencarian POI/alamat belum ada. Titik tujuan dipilih dengan menggeser peta (crosshair) atau dari waypoint.

## Kontrol

Layar sentuh: seret untuk geser, ketuk peta untuk memindahkan crosshair dan menyebut objek.

| Tombol layar | Fungsi |
|---|---|
| `+` / `-` | zoom |
| `MENU` | buka peta, tema, nama, suara, keluar |
| `RUTE` | kendaraan, tercepat/terpendek, hindari tol, asal, navigasi ke titik tengah, batalkan |
| `WP` | simpan waypoint, daftar waypoint |
| `GPS` | nyala + ikuti, lalu ikuti saja, lalu mati |

Cara memakai: geser peta sampai crosshair `+` ada di tujuan, buka `RUTE`, pilih opsi, ketuk
**NAVIGASI KE TITIK TENGAH**. Tanpa sinyal GPS (misalnya untuk uji di meja), ketuk **ASAL** supaya titik tengah
dipakai sebagai titik awal, lalu pilih tujuan lain.

Keyboard / D-pad: panah = geser, `+`/`-`/Volume = zoom, Enter = sebut objek, `M` menu, `R` rute, `W` waypoint,
`O` buka file, `G` GPS, `I` balik warna, `N` nama, `Q` keluar. Di dalam menu: panah atas/bawah, Enter, Back.

## Mendapatkan peta

Unduh peta `.obf` dari OsmAnd (osmand.net, menu unduhan peta) atau salin dari ponsel yang sudah memakai OsmAnd.
Android 11+ tidak mengizinkan memilih file di `Android/data/...`, jadi **salin file .obf ke folder Download** dulu,
lalu pilih dari sana lewat tombol BUKA.

## Membangun APK lewat GitHub (tanpa Android Studio)

1. Buat repository baru di GitHub (boleh private).
2. Unggah **seluruh isi folder ini**. Pastikan folder tersembunyi `.github/workflows/build.yml` ikut terunggah.
   Cara paling aman: pakai `git` (`git init`, `git add -A`, `git commit`, `git push`) atau GitHub Desktop.
   Kalau memakai unggah lewat web dan `.github` tidak ikut, buat manual: *Add file → Create new file*, ketik nama
   `.github/workflows/build.yml`, lalu tempel isi file itu.
3. Buka tab **Actions** → workflow **Build APK** (jalan otomatis setiap push, atau tekan *Run workflow*).
4. Setelah hijau, buka run-nya, unduh artifact **obfnav-debug-apk** (zip berisi `app-debug.apk`).
5. Pasang di ponsel (izinkan "pasang dari sumber tidak dikenal").

Workflow juga menjalankan uji reader OBF sebelum membangun APK. Kalau uji itu gagal, build berhenti.

Membangun sendiri: di komputer dengan JDK 17 + Android SDK, jalankan `gradle assembleDebug` (Gradle 8.9)
atau buka folder ini di Android Studio. Hasilnya `app/build/outputs/apk/debug/app-debug.apk`.

## Memeriksa file .obf nyata di PC (disarankan sebelum menyalahkan aplikasi)

Reader ini diuji dengan file sintetis dan dengan satu file .obf asli (peta kecil sekitar Karawang/Cikampek, Jawa Barat:
header, level zoom, kueri objek, dan koordinat nama kota cocok dengan lokasi sebenarnya). Peta lain, terutama yang jauh
lebih besar atau dari versi OsmAnd berbeda, belum diuji. Untuk memastikan file Anda terbaca benar:

```
mkdir out
javac -d out $(find app/src/main/java/dev/obfnav/core tools -name '*.java')
java -cp out dev.obfnav.tools.SelfTest
java -cp out dev.obfnav.tools.RouterTest                            # uji router, tikungan, bundaran, tol
java -cp out dev.obfnav.tools.CoastTest                             # uji pengisian laut dari garis pantai
java -cp out dev.obfnav.tools.ObfDump peta.obf                      # header, level zoom, jumlah aturan
java -cp out dev.obfnav.tools.ObfDump peta.obf -6.2088 106.8456 15  # objek di sekitar satu titik
```

Kalau `ObfDump` gagal atau hasilnya janggal pada file asli, kirimkan keluarannya; itu petunjuk paling cepat untuk
memperbaiki reader.

## Struktur

```
app/src/main/java/dev/obfnav/core/   reader OBF (Java murni, tanpa dependensi Android)
    ObfReader.java    parser section MAP: aturan, level zoom, R-tree box, blok data, koordinat delta
    Style.java        tabel kecil tag OSM -> kelas gambar, flag jalan (oneway, tol, akses), zoom minimum
    Router.java       graf jalan dari geometri peta, A*, deteksi tikungan dan bundaran
    Route.java        hasil rute, instruksi, pencocokan posisi GPS ke rute
    Coast.java        garis pantai -> poligon daratan (laut jadi latar biru)
    Geo.java          lat/lon <-> koordinat Mercator 31-bit
app/src/main/java/dev/obfnav/        UI: MainActivity (file, GPS), MapView (render + input)
tools/                               uji mandiri dan alat ObfDump (tidak ikut APK)
.github/workflows/build.yml          build APK di GitHub Actions
```

Cara kerja singkat: pada saat menggambar, viewport diubah menjadi kotak koordinat 31-bit. Reader menelusuri R-tree
di file, hanya membaca blok yang beririsan dengan kotak itu, lalu hasilnya disimpan sebagai array `int`. Area 1,5x
viewport dimuat sekaligus di thread terpisah supaya geser kecil tidak memicu pembacaan ulang. Layar hanya digambar ulang
saat ada input atau data baru.

## Catatan lisensi

Format .obf didefinisikan oleh OsmAnd (GPLv3). Reader di sini ditulis ulang dari awal, bukan disalin, tetapi nomor
field dan aturan decoding mengikuti kode OsmAnd (`BinaryMapIndexReader`) sebagai acuan. Jika Anda berencana
mendistribusikan aplikasi ini, pertimbangkan merilisnya dengan GPLv3 agar aman, atau minta nasihat hukum.
Data peta OpenStreetMap berlisensi ODbL dan perlu atribusi "© OpenStreetMap contributors".
