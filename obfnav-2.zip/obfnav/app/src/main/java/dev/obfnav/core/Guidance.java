package dev.obfnav.core;

import java.util.ArrayList;
import java.util.List;

/** Turns a route polyline into a list of turn instructions. Pure geometry, no graph access. */
final class Guidance {
    /** Turns smaller than this at a junction count as "straight on". */
    static final double STRAIGHT_LIMIT = 20.0;
    /** Baseline (meters) used to measure headings; shorter baselines are noisy on a 0.6 m grid. */
    private static final double BASELINE = 12.0;

    private Guidance() {
    }

    /**
     * @param x,y       route points (31-bit)
     * @param deg       number of road segments touching each point (3 or more = junction; 0 for virtual points)
     * @param legName   name of the road used between point k and k+1 (may be null)
     * @param legRound  true if that road is a roundabout
     * @param cum       cumulative meters per point
     */
    static Maneuver[] build(int[] x, int[] y, int[] deg, String[] legName, boolean[] legRound, double[] cum) {
        int n = x.length;
        List<Maneuver> out = new ArrayList<Maneuver>();
        out.add(new Maneuver(Maneuver.START, 0, 0, legName[0], 0));
        int i = 1;
        while (i <= n - 2) {
            if (legRound[i] && !legRound[i - 1]) {
                int j = i;
                while (j <= n - 2 && legRound[j]) j++;
                if (j >= n - 1) { // the route ends inside the roundabout
                    i = j;
                    continue;
                }
                int count = 0;
                for (int k = i + 1; k < j; k++) if (deg[k] >= 3) count++;
                out.add(new Maneuver(Maneuver.ROUNDABOUT, i, count + 1, legName[j], cum[i]));
                i = j + 1;
                continue;
            }
            if (legRound[i] && legRound[i - 1]) {
                i++;
                continue;
            }
            if (deg[i] < 3) {
                i++;
                continue;
            }
            double bin = bearingBefore(x, y, i);
            double bout = bearingAfter(x, y, i);
            double d = Geo.angleDiff(bin, bout);
            double ad = Math.abs(d);
            if (ad >= STRAIGHT_LIMIT) {
                int type;
                boolean right = d > 0;
                if (ad < 60) type = right ? Maneuver.SLIGHT_RIGHT : Maneuver.SLIGHT_LEFT;
                else if (ad < 120) type = right ? Maneuver.RIGHT : Maneuver.LEFT;
                else if (ad < 165) type = right ? Maneuver.SHARP_RIGHT : Maneuver.SHARP_LEFT;
                else type = Maneuver.UTURN;
                out.add(new Maneuver(type, i, 0, legName[i], cum[i]));
            }
            i++;
        }
        out.add(new Maneuver(Maneuver.ARRIVE, n - 1, 0, null, cum[n - 1]));
        return out.toArray(new Maneuver[out.size()]);
    }

    private static double bearingBefore(int[] x, int[] y, int i) {
        int j = i - 1;
        while (j > 0 && Geo.dist(x[j], y[j], x[i], y[i]) < BASELINE) j--;
        return Geo.bearing(x[j], y[j], x[i], y[i]);
    }

    private static double bearingAfter(int[] x, int[] y, int i) {
        int n = x.length;
        int j = i + 1;
        while (j < n - 1 && Geo.dist(x[i], y[i], x[j], y[j]) < BASELINE) j++;
        return Geo.bearing(x[i], y[i], x[j], y[j]);
    }
}
