package dev.obfnav.core;

/** Conversions between WGS84 degrees and OsmAnd's 31-bit Web-Mercator coordinates, plus distances. */
public final class Geo {
    public static final double SPAN = 2147483648.0; // 2^31
    public static final double EARTH_CIRCUMFERENCE = 40075016.686;

    private Geo() {
    }

    public static double lonToX(double lon) {
        return (lon + 180.0) / 360.0 * SPAN;
    }

    public static double latToY(double lat) {
        if (lat > 85.0511) lat = 85.0511;
        if (lat < -85.0511) lat = -85.0511;
        double r = Math.toRadians(lat);
        double e = Math.log(Math.tan(r) + 1.0 / Math.cos(r));
        return (1.0 - e / Math.PI) / 2.0 * SPAN;
    }

    public static double xToLon(double x) {
        return x / SPAN * 360.0 - 180.0;
    }

    public static double yToLat(double y) {
        double n = Math.PI * (1.0 - 2.0 * y / SPAN);
        return Math.toDegrees(Math.atan(Math.sinh(n)));
    }

    /** Ground meters covered by one 31-bit unit at vertical position y (Mercator scale shrinks with cos(lat)). */
    public static double metersPerUnit(double y) {
        double n = Math.PI * (1.0 - 2.0 * y / SPAN);
        return EARTH_CIRCUMFERENCE / SPAN / Math.cosh(n);
    }

    /** Ground distance in meters between two 31-bit points (accurate for the short spans used here). */
    public static double dist(double x1, double y1, double x2, double y2) {
        double dx = x2 - x1, dy = y2 - y1;
        return Math.sqrt(dx * dx + dy * dy) * metersPerUnit((y1 + y2) * 0.5);
    }

    /** Compass bearing in degrees (0 = north, 90 = east) from point 1 to point 2. */
    public static double bearing(double x1, double y1, double x2, double y2) {
        double b = Math.toDegrees(Math.atan2(x2 - x1, -(y2 - y1)));
        return b < 0 ? b + 360.0 : b;
    }

    /** Smallest signed difference to - from, in (-180, 180]; positive means clockwise (a right turn). */
    public static double angleDiff(double from, double to) {
        double d = (to - from) % 360.0;
        if (d > 180.0) d -= 360.0;
        if (d <= -180.0) d += 360.0;
        return d;
    }

    /** How many 31-bit units span the given number of meters at vertical position y. */
    public static double unitsFromMeters(double meters, double y) {
        return meters / metersPerUnit(y);
    }
}
