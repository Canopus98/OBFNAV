package dev.obfnav;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import android.speech.tts.TextToSpeech;
import android.view.WindowManager;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import dev.obfnav.core.Geo;
import dev.obfnav.core.Maneuver;
import dev.obfnav.core.NavSession;
import dev.obfnav.core.ObfReader;
import dev.obfnav.core.ObfRoadSource;
import dev.obfnav.core.Route;
import dev.obfnav.core.RouteOptions;
import dev.obfnav.core.Router;
import dev.obfnav.core.Waypoints;

/** Single-screen host: file picking, GPS, routing, voice guidance, waypoints, settings and menus. */
public final class MainActivity extends Activity implements MapView.Host, LocationListener {
    private static final int REQ_OPEN = 1;
    private static final int REQ_LOCATION = 2;
    private static final String PREFS = "obfnav";
    private static final double[] SIM_KMH = {40, 80, 160};

    private MapView map;
    private SharedPreferences prefs;
    private ObfReader reader;
    private ObfRoadSource source;
    private Waypoints waypoints = new Waypoints();

    // settings
    private boolean moto, avoidToll, shortest, voice = true, night, names = true;
    private int simSpeed;

    // GPS
    private boolean wantGps, gpsRunning;
    private boolean realFix;
    private double fixLat, fixLon, fixAcc = 10, fixSpeed;

    // route
    private Route route;
    private NavSession session;
    private boolean hasStart, hasDest;
    private double startLat, startLon, destLat, destLon;
    private int routeGen;
    private Router routing;
    private long lastReroute;
    private boolean computing;

    // simulation
    private volatile boolean simRunning;
    private boolean simulating;

    // voice
    private TextToSpeech tts;
    private boolean ttsReady;

    // menus: 0 main, 1 waypoint list, 2 waypoint actions, 3 instructions
    private int menuLevel = -1;
    private int curWpt = -1;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        moto = prefs.getBoolean("moto", false);
        avoidToll = prefs.getBoolean("notoll", false);
        shortest = prefs.getBoolean("shortest", false);
        voice = prefs.getBoolean("voice", true);
        night = prefs.getBoolean("night", false);
        names = prefs.getBoolean("names", true);
        simSpeed = prefs.getInt("simspeed", 0) % SIM_KMH.length;
        waypoints = Waypoints.parse(prefs.getString("wpts", ""));

        map = new MapView(this);
        map.setHost(this);
        map.setNight(night);
        map.setShowNames(names);
        map.setWaypoints(waypoints);
        setContentView(map);
        map.requestFocus();
        map.setCenter(Double.longBitsToDouble(prefs.getLong("lat", Double.doubleToLongBits(-6.2088))),
                Double.longBitsToDouble(prefs.getLong("lon", Double.doubleToLongBits(106.8456))));
        map.setZoom(prefs.getInt("zoom", 14));

        if (voice) initTts();
        String saved = prefs.getString("uri", null);
        if (saved != null) openMap(Uri.parse(saved));
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (wantGps) startGps();
    }

    @Override
    protected void onPause() {
        super.onPause();
        stopGpsUpdates();
        savePrefs();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        simRunning = false;
        map.close();
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
    }

    private void savePrefs() {
        prefs.edit()
                .putLong("lat", Double.doubleToLongBits(map.getCenterLat()))
                .putLong("lon", Double.doubleToLongBits(map.getCenterLon()))
                .putInt("zoom", map.getZoom())
                .putBoolean("moto", moto)
                .putBoolean("notoll", avoidToll)
                .putBoolean("shortest", shortest)
                .putBoolean("voice", voice)
                .putBoolean("night", night)
                .putBoolean("names", names)
                .putInt("simspeed", simSpeed)
                .putString("wpts", waypoints.serialize())
                .apply();
    }

    // ------------------------------------------------------------------ voice

    private void initTts() {
        if (tts != null) return;
        tts = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status != TextToSpeech.SUCCESS) {
                    ttsReady = false;
                    return;
                }
                int r = tts.setLanguage(new Locale("id", "ID"));
                ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED;
                if (!ttsReady) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            map.setStatus("Suara bahasa Indonesia tidak tersedia di perangkat");
                        }
                    });
                }
            }
        });
    }

    private void speak(String s) {
        if (voice && ttsReady && tts != null && s != null) {
            tts.speak(s, TextToSpeech.QUEUE_FLUSH, null, "nav");
        }
    }

    // ------------------------------------------------------------------ actions

    private RouteOptions options() {
        return new RouteOptions(moto, avoidToll, shortest);
    }

    @Override
    public void onAction(int act, int arg) {
        switch (act) {
            case Act.MENU:
                if (map.isMenuOpen()) closeMenu();
                else openMenu(0, 0);
                return;
            case Act.BACK:
                back();
                return;
            case Act.GPS:
                onGpsToggle();
                return;
            case Act.GOTO:
                if (route != null) cancelRoute();
                else routeTo(map.getCenterLat(), map.getCenterLon());
                return;
            case Act.CANCEL_ROUTE:
                closeMenu();
                cancelRoute();
                return;
            case Act.SET_START:
                hasStart = true;
                startLat = map.getCenterLat();
                startLon = map.getCenterLon();
                map.setMarks(true, startLat, startLon, hasDest, destLat, destLon);
                map.setStatus("Titik awal diset di kursor");
                closeMenu();
                return;
            case Act.SAVE_WPT_CURSOR:
                addWaypoint(map.getCenterLat(), map.getCenterLon());
                return;
            case Act.SAVE_WPT_GPS:
                if (!realFix && !simulating) {
                    map.setStatus("Belum ada posisi GPS");
                    closeMenu();
                } else {
                    addWaypoint(fixLat, fixLon);
                }
                return;
            case Act.WPT_LIST:
                openMenu(1, 0);
                return;
            case Act.WPT_PICK:
                curWpt = arg;
                openMenu(2, 0);
                return;
            case Act.WPT_JUMP:
                if (curWpt >= 0 && curWpt < waypoints.size()) {
                    map.setFollowGps(false);
                    map.setCenter(waypoints.get(curWpt).lat, waypoints.get(curWpt).lon);
                    if (map.getZoom() < 15) map.setZoom(15);
                }
                closeMenu();
                return;
            case Act.WPT_GOTO:
                if (curWpt >= 0 && curWpt < waypoints.size()) {
                    closeMenu();
                    routeTo(waypoints.get(curWpt).lat, waypoints.get(curWpt).lon);
                }
                return;
            case Act.WPT_START:
                if (curWpt >= 0 && curWpt < waypoints.size()) {
                    hasStart = true;
                    startLat = waypoints.get(curWpt).lat;
                    startLon = waypoints.get(curWpt).lon;
                    map.setMarks(true, startLat, startLon, hasDest, destLat, destLon);
                    map.setStatus("Titik awal: " + waypoints.get(curWpt).name);
                }
                closeMenu();
                return;
            case Act.WPT_DELETE:
                if (curWpt >= 0 && curWpt < waypoints.size()) {
                    waypoints.remove(curWpt);
                    savePrefs();
                    map.setWaypoints(waypoints);
                }
                curWpt = -1;
                openMenu(1, 0);
                return;
            case Act.TOGGLE_VEHICLE:
                moto = !moto;
                optionChanged();
                return;
            case Act.TOGGLE_TOLL:
                avoidToll = !avoidToll;
                optionChanged();
                return;
            case Act.TOGGLE_MODE:
                shortest = !shortest;
                optionChanged();
                return;
            case Act.TOGGLE_VOICE:
                voice = !voice;
                if (voice) initTts();
                else if (tts != null) tts.stop();
                savePrefs();
                openMenu(0, map.getMenuSel());
                return;
            case Act.TOGGLE_THEME:
                night = !night;
                map.setNight(night);
                savePrefs();
                openMenu(0, map.getMenuSel());
                return;
            case Act.TOGGLE_NAMES:
                names = !names;
                map.setShowNames(names);
                savePrefs();
                openMenu(0, map.getMenuSel());
                return;
            case Act.OPEN_FILE:
                closeMenu();
                openFilePicker();
                return;
            case Act.QUIT:
                finish();
                return;
            case Act.SIMULATE:
                if (simulating) stopSim();
                else startSim();
                return;
            case Act.SIM_SPEED:
                simSpeed = (simSpeed + 1) % SIM_KMH.length;
                savePrefs();
                openMenu(0, map.getMenuSel());
                return;
            case Act.INSTRUCTIONS:
                openMenu(3, 0);
                return;
            case Act.JUMP_NODE:
                if (route != null && arg >= 0 && arg < route.maneuvers.length) {
                    int n = Math.min(route.maneuvers[arg].node, route.x.length - 1);
                    map.setFollowGps(false);
                    map.setCenter(Geo.yToLat(route.y[n]), Geo.xToLon(route.x[n]));
                    if (map.getZoom() < 16) map.setZoom(16);
                }
                closeMenu();
                return;
            default:
                return;
        }
    }

    private void optionChanged() {
        savePrefs();
        if (route != null && hasDest) {
            double sLat = hasStart ? startLat : 0, sLon = hasStart ? startLon : 0;
            if (realFix || simulating) {
                sLat = fixLat;
                sLon = fixLon;
            }
            closeMenu();
            compute(sLat, sLon, destLat, destLon, true);
        } else {
            openMenu(0, map.getMenuSel());
        }
    }

    private void addWaypoint(double lat, double lon) {
        Waypoints.Waypoint w = waypoints.add(lat, lon, "");
        savePrefs();
        map.setWaypoints(waypoints);
        map.setStatus("Tersimpan: " + w.name);
        closeMenu();
    }

    @Override
    public void onBackPressed() {
        if (map.isMenuOpen()) back();
        else super.onBackPressed();
    }

    private void back() {
        if (menuLevel == 2) openMenu(1, Math.max(0, curWpt));
        else if (menuLevel == 1 || menuLevel == 3) openMenu(0, 0);
        else closeMenu();
    }

    private void closeMenu() {
        menuLevel = -1;
        map.hideMenu();
    }

    // ------------------------------------------------------------------ menus

    private static String yn(boolean b) {
        return b ? "YA" : "TIDAK";
    }

    private void openMenu(int level, int sel) {
        menuLevel = level;
        List<Item> l = new ArrayList<Item>();
        String title;
        if (level == 0) {
            title = "MENU";
            l.add(new Item("TUJU KE KURSOR", null, Act.GOTO, 0));
            l.add(new Item("MULAI DARI KURSOR", hasStart ? "(ada)" : null, Act.SET_START, 0));
            l.add(new Item("SIMPAN WAYPOINT: KURSOR", null, Act.SAVE_WPT_CURSOR, 0));
            l.add(new Item("SIMPAN WAYPOINT: GPS", null, Act.SAVE_WPT_GPS, 0));
            l.add(new Item("DAFTAR WAYPOINT", String.valueOf(waypoints.size()), Act.WPT_LIST, 0));
            l.add(new Item("KENDARAAN", moto ? "MOTOR" : "MOBIL", Act.TOGGLE_VEHICLE, 0));
            l.add(new Item("HINDARI TOL", yn(avoidToll), Act.TOGGLE_TOLL, 0));
            l.add(new Item("RUTE", shortest ? "TERPENDEK" : "TERCEPAT", Act.TOGGLE_MODE, 0));
            l.add(new Item("SUARA", yn(voice), Act.TOGGLE_VOICE, 0));
            l.add(new Item("TEMA", night ? "MALAM" : "SIANG", Act.TOGGLE_THEME, 0));
            l.add(new Item("NAMA OBJEK", yn(names), Act.TOGGLE_NAMES, 0));
            if (route != null) {
                l.add(new Item("PETUNJUK RUTE", String.valueOf(route.maneuvers.length), Act.INSTRUCTIONS, 0));
                l.add(new Item("BATALKAN RUTE", null, Act.CANCEL_ROUTE, 0));
            }
            l.add(new Item("SIMULASI BERKENDARA", simulating ? "BERHENTI" : "MULAI", Act.SIMULATE, 0));
            l.add(new Item("KECEPATAN SIMULASI", (int) SIM_KMH[simSpeed] + " km/j", Act.SIM_SPEED, 0));
            l.add(new Item("BUKA PETA", null, Act.OPEN_FILE, 0));
            l.add(new Item("KELUAR", null, Act.QUIT, 0));
        } else if (level == 1) {
            title = "WAYPOINT (" + waypoints.size() + ")";
            double cx = Geo.lonToX(map.getCenterLon()), cy = Geo.latToY(map.getCenterLat());
            for (int i = 0; i < waypoints.size(); i++) {
                Waypoints.Waypoint w = waypoints.get(i);
                double d = Geo.dist(cx, cy, Geo.lonToX(w.lon), Geo.latToY(w.lat));
                l.add(new Item(w.name, Maneuver.fmtDist(d), Act.WPT_PICK, i));
            }
            if (l.isEmpty()) l.add(new Item("(kosong)", null, Act.NONE, 0));
        } else if (level == 2) {
            title = curWpt >= 0 && curWpt < waypoints.size() ? waypoints.get(curWpt).name : "WAYPOINT";
            l.add(new Item("PINDAH KE SINI", null, Act.WPT_JUMP, 0));
            l.add(new Item("TUJU KE SINI", null, Act.WPT_GOTO, 0));
            l.add(new Item("MULAI DARI SINI", null, Act.WPT_START, 0));
            l.add(new Item("HAPUS", null, Act.WPT_DELETE, 0));
        } else {
            title = "PETUNJUK RUTE";
            if (route != null) {
                for (int i = 0; i < route.maneuvers.length; i++) {
                    Maneuver m = route.maneuvers[i];
                    l.add(new Item(m.text(), Maneuver.fmtDist(m.distFromStart), Act.JUMP_NODE, i));
                }
            }
        }
        map.showMenu(title, l.toArray(new Item[0]), sel);
    }

    // ------------------------------------------------------------------ routing

    private void routeTo(double dLat, double dLon) {
        if (reader == null || source == null) {
            map.setStatus("Buka peta dulu (MENU > BUKA PETA)");
            return;
        }
        double sLat, sLon;
        if (realFix || simulating) {
            sLat = fixLat;
            sLon = fixLon;
        } else if (hasStart) {
            sLat = startLat;
            sLon = startLon;
        } else {
            map.setStatus("Nyalakan GPS atau pakai MENU > MULAI DARI KURSOR");
            return;
        }
        closeMenu();
        compute(sLat, sLon, dLat, dLon, false);
    }

    private void compute(final double sLat, final double sLon, final double dLat, final double dLon,
                         final boolean reroute) {
        if (source == null) return;
        if (routing != null) routing.cancel();
        final int gen = ++routeGen;
        final Router rt = new Router(source, options());
        routing = rt;
        computing = true;
        map.setStatus("Menghitung rute...");
        new Thread(new Runnable() {
            @Override
            public void run() {
                Route r = null;
                String err = null;
                try {
                    r = rt.route(sLat, sLon, dLat, dLon);
                } catch (Router.RouteException e) {
                    err = e.getMessage();
                } catch (IOException e) {
                    err = "Gagal: " + e.getMessage();
                } catch (RuntimeException e) {
                    err = "Gagal: " + e;
                }
                final Route fr = r;
                final String ferr = err;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (gen != routeGen) return;
                        computing = false;
                        if (fr == null) {
                            map.setStatus(ferr == null ? "Rute tidak ditemukan" : ferr);
                            return;
                        }
                        applyRoute(fr, sLat, sLon, dLat, dLon, reroute);
                    }
                });
            }
        }, "router").start();
    }

    private void applyRoute(Route r, double sLat, double sLon, double dLat, double dLon, boolean reroute) {
        route = r;
        session = new NavSession(r);
        hasDest = true;
        destLat = dLat;
        destLon = dLon;
        map.setRoute(r);
        map.setMarks(true, sLat, sLon, true, dLat, dLon);
        map.setStatus(r.summary());
        if (!reroute || !(realFix || simulating)) {
            int l = Integer.MAX_VALUE, rr = 0, t = Integer.MAX_VALUE, b = 0;
            for (int i = 0; i < r.x.length; i++) {
                l = Math.min(l, r.x[i]);
                rr = Math.max(rr, r.x[i]);
                t = Math.min(t, r.y[i]);
                b = Math.max(b, r.y[i]);
            }
            map.fitBounds(l, rr, t, b);
        }
        speak(reroute ? "Rute baru siap" : "Rute siap. " + Maneuver.fmtDist(r.totalDist));
        if (realFix || simulating) feedSession(fixLat, fixLon, fixAcc);
    }

    private void cancelRoute() {
        routeGen++;
        if (routing != null) routing.cancel();
        computing = false;
        stopSim();
        route = null;
        session = null;
        hasDest = false;
        map.setRoute(null);
        map.setMarks(hasStart, startLat, startLon, false, 0, 0);
        map.setStatus("Rute dibatalkan");
        if (tts != null) tts.stop();
    }

    private void feedSession(double lat, double lon, double acc) {
        if (session == null) return;
        NavSession.State st = session.update(Geo.lonToX(lon), Geo.latToY(lat), acc);
        map.setNav(st);
        if (st.speech.size() > 0) {
            speak(st.speech.get(st.speech.size() - 1));
        }
        if (st.arrived) {
            map.setStatus("Tiba di tujuan");
            if (simulating) stopSim();
        } else if (st.offRoute && !simulating && !computing && hasDest
                && System.currentTimeMillis() - lastReroute > 8000) {
            lastReroute = System.currentTimeMillis();
            speak("Menghitung ulang rute");
            compute(lat, lon, destLat, destLon, true);
        } else if (!computing) {
            map.setStatus("");
        }
    }

    // ------------------------------------------------------------------ simulation

    private void startSim() {
        if (route == null) {
            map.setStatus("Buat rute dulu, lalu jalankan simulasi");
            closeMenu();
            return;
        }
        closeMenu();
        simulating = true;
        simRunning = true;
        final Route r = route;
        session = new NavSession(r);
        map.setFollowGps(true);
        if (map.getZoom() < 16) map.setZoom(16);
        final double mps = SIM_KMH[simSpeed] / 3.6;
        new Thread(new Runnable() {
            @Override
            public void run() {
                double along = 0;
                int seg = 0;
                while (simRunning) {
                    along = Math.min(r.totalDist, along + mps);
                    while (seg < r.x.length - 2 && r.cumDist[seg + 1] < along) seg++;
                    double len = r.cumDist[seg + 1] - r.cumDist[seg];
                    double t = len <= 0 ? 0 : Math.max(0, Math.min(1, (along - r.cumDist[seg]) / len));
                    final double x = r.x[seg] + t * (r.x[seg + 1] - r.x[seg]);
                    final double y = r.y[seg] + t * (r.y[seg + 1] - r.y[seg]);
                    final boolean last = along >= r.totalDist;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (!simulating) return;
                            fixLat = Geo.yToLat(y);
                            fixLon = Geo.xToLon(x);
                            fixAcc = 5;
                            fixSpeed = SIM_KMH[simSpeed];
                            map.setGps(true, fixLat, fixLon, fixSpeed);
                            feedSession(fixLat, fixLon, 5);
                        }
                    });
                    if (last) break;
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        break;
                    }
                }
                simRunning = false;
            }
        }, "sim").start();
    }

    private void stopSim() {
        if (!simulating) return;
        simulating = false;
        simRunning = false;
        realFix = false;
        map.setGps(false, 0, 0, 0);
        map.setFollowGps(false);
    }

    // ------------------------------------------------------------------ file picking

    private void openFilePicker() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try {
            startActivityForResult(i, REQ_OPEN);
        } catch (Exception e) {
            map.setStatus("Tidak ada pemilih file di perangkat ini");
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_OPEN || res != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) {
            // some providers do not support persistable grants; the file just will not auto-reopen
        }
        prefs.edit().putString("uri", uri.toString()).apply();
        openMap(uri);
    }

    private String displayName(Uri uri) {
        Cursor c = null;
        try {
            c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null);
            if (c != null && c.moveToFirst()) return c.getString(0);
        } catch (Exception ignored) {
            // fall through
        } finally {
            if (c != null) c.close();
        }
        String p = uri.getLastPathSegment();
        return p == null ? "map.obf" : p;
    }

    private void openMap(final Uri uri) {
        map.setStatus("Membuka peta...");
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    final String name = displayName(uri);
                    ParcelFileDescriptor pfd = getContentResolver().openFileDescriptor(uri, "r");
                    if (pfd == null) throw new IOException("file tidak bisa dibuka");
                    final ObfReader rd;
                    try {
                        FileInputStream in = new FileInputStream(pfd.getFileDescriptor());
                        FileChannel ch = in.getChannel();
                        long size = ch.size();
                        if (size > Integer.MAX_VALUE) throw new IOException("file > 2 GB belum didukung");
                        MappedByteBuffer mb = ch.map(FileChannel.MapMode.READ_ONLY, 0, size);
                        rd = new ObfReader(mb); // the mapping stays valid after the descriptor is closed
                    } finally {
                        pfd.close();
                    }
                    final ObfRoadSource src = new ObfRoadSource(rd);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            reader = rd;
                            source = src;
                            if (route != null) cancelRoute();
                            map.setReader(rd, name);
                            map.setStatus(rd.getMaps().isEmpty() ? "File ini tidak berisi data peta" : "");
                        }
                    });
                } catch (final Exception e) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            map.setStatus("GAGAL: " + e.getMessage());
                        }
                    });
                }
            }
        }, "obf-open").start();
    }

    // ------------------------------------------------------------------ GPS

    private void onGpsToggle() {
        if (simulating) {
            map.setFollowGps(true);
            return;
        }
        if (!wantGps) {
            wantGps = true;
            startGps();
            map.setFollowGps(true);
        } else if (map.isFollowGps()) {
            wantGps = false;
            stopGpsUpdates();
            realFix = false;
            map.setGps(false, 0, 0, 0);
            map.setFollowGps(false);
            map.setStatus("");
        } else {
            map.setFollowGps(true);
        }
    }

    private boolean hasLocationPermission() {
        return Build.VERSION.SDK_INT < 23
                || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void startGps() {
        if (!hasLocationPermission()) {
            if (Build.VERSION.SDK_INT >= 23) {
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQ_LOCATION);
            }
            return;
        }
        if (gpsRunning) return;
        LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (lm == null || !lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            map.setStatus("GPS mati. Aktifkan lokasi di pengaturan.");
            return;
        }
        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, this);
            gpsRunning = true;
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            map.setStatus("Mencari sinyal GPS...");
            Location last = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (last != null) onLocationChanged(last);
        } catch (SecurityException e) {
            map.setStatus("Izin lokasi ditolak");
        }
    }

    private void stopGpsUpdates() {
        if (!gpsRunning) return;
        LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (lm != null) lm.removeUpdates(this);
        gpsRunning = false;
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == REQ_LOCATION) {
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) {
                startGps();
            } else {
                wantGps = false;
                map.setFollowGps(false);
                map.setStatus("Izin lokasi ditolak");
            }
        }
    }

    @Override
    public void onLocationChanged(Location l) {
        if (simulating) return;
        realFix = true;
        fixLat = l.getLatitude();
        fixLon = l.getLongitude();
        fixAcc = l.getAccuracy() > 0 ? l.getAccuracy() : 10;
        fixSpeed = l.getSpeed() * 3.6;
        map.setGps(true, fixLat, fixLon, fixSpeed);
        if (session != null) feedSession(fixLat, fixLon, fixAcc);
        else map.setStatus("GPS " + (int) fixAcc + " m");
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
    }

    @Override
    public void onProviderEnabled(String provider) {
    }

    @Override
    public void onProviderDisabled(String provider) {
        map.setStatus("GPS dimatikan");
    }
}
