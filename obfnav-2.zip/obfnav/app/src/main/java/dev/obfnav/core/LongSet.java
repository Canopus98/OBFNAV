package dev.obfnav.core;

import java.util.Arrays;

/** Minimal open-addressing set of longs (no boxing). Keys must not equal Long.MIN_VALUE. */
final class LongSet {
    private static final long EMPTY = Long.MIN_VALUE;
    private long[] keys = new long[1024];
    private int size;

    LongSet() {
        Arrays.fill(keys, EMPTY);
    }

    private static int slot(long k, int mask) {
        long h = k * 0x9E3779B97F4A7C15L;
        return (int) (h >>> 32) & mask;
    }

    /** @return true if the key was newly added. */
    boolean add(long k) {
        if ((size + 1) * 2 > keys.length) grow();
        int mask = keys.length - 1;
        int i = slot(k, mask);
        while (keys[i] != EMPTY) {
            if (keys[i] == k) return false;
            i = (i + 1) & mask;
        }
        keys[i] = k;
        size++;
        return true;
    }

    boolean contains(long k) {
        int mask = keys.length - 1;
        int i = slot(k, mask);
        while (keys[i] != EMPTY) {
            if (keys[i] == k) return true;
            i = (i + 1) & mask;
        }
        return false;
    }

    int size() {
        return size;
    }

    void clear() {
        keys = new long[1024];
        Arrays.fill(keys, EMPTY);
        size = 0;
    }

    private void grow() {
        long[] old = keys;
        keys = new long[old.length * 2];
        Arrays.fill(keys, EMPTY);
        int mask = keys.length - 1;
        for (long k : old) {
            if (k == EMPTY) continue;
            int i = slot(k, mask);
            while (keys[i] != EMPTY) i = (i + 1) & mask;
            keys[i] = k;
        }
    }
}
