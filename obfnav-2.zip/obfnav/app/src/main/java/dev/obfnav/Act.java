package dev.obfnav;

/** Action ids shared by the buttons, the menus and the activity. */
final class Act {
    static final int NONE = 0;
    static final int MENU = 1;
    static final int ZOOM_IN = 2;
    static final int ZOOM_OUT = 3;
    static final int GPS = 4;
    static final int GOTO = 5;            // route to the crosshair
    static final int CANCEL_ROUTE = 6;
    static final int SET_START = 7;
    static final int SAVE_WPT_CURSOR = 8;
    static final int SAVE_WPT_GPS = 9;
    static final int WPT_LIST = 10;
    static final int WPT_PICK = 11;       // arg = index
    static final int WPT_JUMP = 12;       // arg = index
    static final int WPT_GOTO = 13;       // arg = index
    static final int WPT_START = 14;      // arg = index
    static final int WPT_DELETE = 15;     // arg = index
    static final int TOGGLE_VEHICLE = 16;
    static final int TOGGLE_TOLL = 17;
    static final int TOGGLE_MODE = 18;
    static final int TOGGLE_VOICE = 19;
    static final int TOGGLE_THEME = 20;
    static final int TOGGLE_NAMES = 21;
    static final int OPEN_FILE = 22;
    static final int QUIT = 23;
    static final int SIMULATE = 24;
    static final int SIM_SPEED = 25;
    static final int INSTRUCTIONS = 26;
    static final int IDENTIFY = 27;
    static final int BACK = 28;
    static final int JUMP_NODE = 29;      // arg = maneuver index

    private Act() {
    }
}
