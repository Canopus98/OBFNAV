package dev.obfnav.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Follows a vehicle along a {@link Route}: snaps GPS fixes onto the route, tracks the distance to the next
 * turn, produces spoken warnings at fixed distances before each turn, and detects leaving the route.
 * Pure logic with no Android dependency, so it can be unit tested with simulated drives.
 */
public final class NavSession {

    /** Result of one position update. */
    public static final class State {
        /** Meters travelled along the route. */
        public double along;
        public double remainingDist, remainingTime;
        /** Index into {@link Route#maneuvers} of the next maneuver. */
        public int nextIndex;
        public Maneuver next;
        /** Meters until {@link #next}. */
        public double distToNext;
        /** Distance in meters from the fix to the route line. */
        public double offset;
        /** True after several consecutive fixes far from the route: the caller should reroute. */
        public boolean offRoute;
        public boolean arrived;
        /** Sentences to speak now (usually empty). */
        public final List<String> speech = new ArrayList<String>();
        /** Snapped position on the route (31-bit coordinates). */
        public double snapX, snapY;
    }

    private static final int OFF_ROUTE_FIXES = 3;
    private static final double PASSED_MARGIN = 15.0;
    private static final double ARRIVE_DIST = 25.0;

    private final Route route;
    private final double[] levels;
    private final int[] announced;
    private final int segCount;
    private int seg;
    private int nextIdx = 1;
    private int offCount;
    private boolean started;
    private boolean arrivalSpoken;

    public NavSession(Route route) {
        this.route = route;
        // warning distances (meters before the turn): a motorcycle is slower, so warns later
        this.levels = route.options != null && route.options.motorcycle
                ? new double[]{300, 120, 40} : new double[]{500, 200, 60};
        this.announced = new int[route.maneuvers.length];
        Arrays.fill(announced, -1);
        this.segCount = Math.max(1, route.x.length - 1);
        if (route.maneuvers.length < 2) nextIdx = 0;
    }

    public Route route() {
        return route;
    }

    /**
     * @param x,y      position in 31-bit coordinates
     * @param accuracy GPS accuracy in meters (use 10 if unknown)
     */
    public State update(double x, double y, double accuracy) {
        State st = new State();
        double threshold = Math.max(40.0, accuracy * 2.0);

        // 1) find the closest route segment, searching ahead of where we were first
        int lo = Math.max(0, seg - 3), hi = Math.min(segCount - 1, seg + 80);
        double[] best = scan(x, y, lo, hi);
        if (best[0] > threshold) {
            double[] global = scan(x, y, 0, segCount - 1);
            if (global[0] < best[0]) best = global;
        }
        double dist = best[0];
        if (dist <= threshold) {
            seg = (int) best[1];
            offCount = 0;
        } else {
            offCount++;
        }
        double t = best[2];
        int s = (int) best[1];
        double segLen = route.cumDist[s + 1] - route.cumDist[s];
        double along = route.cumDist[s] + t * segLen;
        if (dist <= threshold) {
            // never go backwards by more than GPS noise
            st.snapX = route.x[s] + t * (route.x[s + 1] - route.x[s]);
            st.snapY = route.y[s] + t * (route.y[s + 1] - route.y[s]);
        } else {
            st.snapX = x;
            st.snapY = y;
        }
        st.along = along;
        st.offset = dist;
        st.offRoute = offCount >= OFF_ROUTE_FIXES;
        double segTime = route.cumTime[s + 1] - route.cumTime[s];
        st.remainingTime = Math.max(0, route.totalTime - (route.cumTime[s] + t * segTime));
        st.remainingDist = Math.max(0, route.totalDist - along);

        // 2) advance to the next maneuver
        Maneuver[] mv = route.maneuvers;
        while (nextIdx < mv.length - 1 && mv[nextIdx].distFromStart < along - PASSED_MARGIN) nextIdx++;
        st.nextIndex = nextIdx;
        st.next = mv[nextIdx];
        st.distToNext = Math.max(0, mv[nextIdx].distFromStart - along);

        // 3) arrival
        if (st.remainingDist < ARRIVE_DIST && dist <= threshold) st.arrived = true;

        // 4) spoken warnings (only while on the route)
        if (!st.offRoute && dist <= threshold) {
            if (!started) {
                started = true;
                st.speech.add(mv[0].speech(0));
            }
            if (st.arrived) {
                if (!arrivalSpoken) {
                    arrivalSpoken = true;
                    st.speech.add(mv[mv.length - 1].speech(0));
                }
            } else if (nextIdx >= 1 || mv.length < 2) {
                int j = -1;
                if (mv[nextIdx].type == Maneuver.ARRIVE) {
                    // the destination is announced only once, at the middle warning distance
                    if (st.distToNext <= levels[1]) j = 1;
                } else {
                    for (int k = 0; k < levels.length; k++) if (st.distToNext <= levels[k]) j = k;
                }
                if (j > announced[nextIdx]) {
                    announced[nextIdx] = j;
                    boolean last = j == levels.length - 1;
                    double ahead = mv[nextIdx].type == Maneuver.ARRIVE ? Math.max(1, st.distToNext)
                            : (last ? 0 : st.distToNext);
                    st.speech.add(mv[nextIdx].speech(ahead));
                }
            }
        }
        return st;
    }

    /** @return {distance, segment index, parameter t in [0,1]} of the closest segment in [lo, hi]. */
    private double[] scan(double x, double y, int lo, int hi) {
        double bestD = Double.MAX_VALUE, bestT = 0;
        int bestI = lo;
        for (int i = lo; i <= hi; i++) {
            double ax = route.x[i], ay = route.y[i], bx = route.x[i + 1], by = route.y[i + 1];
            double dx = bx - ax, dy = by - ay;
            double len2 = dx * dx + dy * dy;
            double t = len2 == 0 ? 0 : ((x - ax) * dx + (y - ay) * dy) / len2;
            if (t < 0) t = 0;
            else if (t > 1) t = 1;
            double d = Geo.dist(x, y, ax + t * dx, ay + t * dy);
            if (d < bestD) {
                bestD = d;
                bestI = i;
                bestT = t;
            }
        }
        return new double[]{bestD, bestI, bestT};
    }
}
