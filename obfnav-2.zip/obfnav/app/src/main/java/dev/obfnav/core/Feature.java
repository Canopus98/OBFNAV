package dev.obfnav.core;

/** One map object (road, building, water polygon, place point...) in 31-bit Mercator coordinates. */
public final class Feature {
    /** x0,y0,x1,y1,... in 31-bit Mercator units. */
    public int[] xy;
    /** Rule ids (see {@link ObfReader.MapIndex#rule(int)}). */
    public int[] types;
    /** True when the geometry is a closed area (polygon), false for lines and points. */
    public boolean area;
    public String name;
    /** Road reference such as "A1" or "Tol Jakarta-Cikampek" (the OSM ref tag), or null. */
    public String ref;
    public long id;
    /** Drawing class assigned by {@link Style}; 0 means "do not draw". */
    public int cls;
    /** {@link Style} F_* flags (oneway, toll, ...). */
    public int flags;
    public int minX, maxX, minY, maxY;

    /** Indexes into the block string table, resolved when the block is finished. */
    int nameRef = -1;
    int refRef = -1;
}
