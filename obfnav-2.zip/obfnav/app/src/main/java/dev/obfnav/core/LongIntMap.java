package dev.obfnav.core;

import java.util.Arrays;

/** Minimal open-addressing map long -> int (no boxing). Keys must not equal Long.MIN_VALUE. */
final class LongIntMap {
    private static final long EMPTY = Long.MIN_VALUE;
    private long[] keys;
    private int[] vals;
    private int size;

    LongIntMap(int capacityPow2) {
        keys = new long[capacityPow2];
        vals = new int[capacityPow2];
        Arrays.fill(keys, EMPTY);
    }

    private static int slot(long k, int mask) {
        long h = k * 0x9E3779B97F4A7C15L;
        return (int) (h >>> 32) & mask;
    }

    /** @return the stored value, or {@code missing} if the key is absent. */
    int get(long k, int missing) {
        int mask = keys.length - 1;
        int i = slot(k, mask);
        while (keys[i] != EMPTY) {
            if (keys[i] == k) return vals[i];
            i = (i + 1) & mask;
        }
        return missing;
    }

    void put(long k, int v) {
        if ((size + 1) * 2 > keys.length) grow();
        int mask = keys.length - 1;
        int i = slot(k, mask);
        while (keys[i] != EMPTY) {
            if (keys[i] == k) {
                vals[i] = v;
                return;
            }
            i = (i + 1) & mask;
        }
        keys[i] = k;
        vals[i] = v;
        size++;
    }

    int size() {
        return size;
    }

    private void grow() {
        long[] ok = keys;
        int[] ov = vals;
        keys = new long[ok.length * 2];
        vals = new int[ok.length * 2];
        Arrays.fill(keys, EMPTY);
        int mask = keys.length - 1;
        for (int j = 0; j < ok.length; j++) {
            if (ok[j] == EMPTY) continue;
            int i = slot(ok[j], mask);
            while (keys[i] != EMPTY) i = (i + 1) & mask;
            keys[i] = ok[j];
            vals[i] = ov[j];
        }
    }
}
