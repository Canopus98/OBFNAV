package dev.obfnav.core;

import java.util.Locale;

/** One turn instruction along a {@link Route}. */
public final class Maneuver {
    public static final int START = 0;
    public static final int SLIGHT_LEFT = 1;
    public static final int LEFT = 2;
    public static final int SHARP_LEFT = 3;
    public static final int SLIGHT_RIGHT = 4;
    public static final int RIGHT = 5;
    public static final int SHARP_RIGHT = 6;
    public static final int UTURN = 7;
    public static final int ROUNDABOUT = 8;
    public static final int ARRIVE = 9;

    public final int type;
    /** Index of the route point where the maneuver happens. */
    public final int node;
    /** For roundabouts: which exit to take (1 = first). */
    public final int exitNo;
    /** Name (or road number) of the road to take, or null. */
    public final String street;
    /** Meters from the start of the route. */
    public final double distFromStart;

    public Maneuver(int type, int node, int exitNo, String street, double distFromStart) {
        this.type = type;
        this.node = node;
        this.exitNo = exitNo;
        this.street = street;
        this.distFromStart = distFromStart;
    }

    private String action() {
        switch (type) {
            case SLIGHT_LEFT:
                return "serong ke kiri";
            case LEFT:
                return "belok kiri";
            case SHARP_LEFT:
                return "belok tajam ke kiri";
            case SLIGHT_RIGHT:
                return "serong ke kanan";
            case RIGHT:
                return "belok kanan";
            case SHARP_RIGHT:
                return "belok tajam ke kanan";
            case UTURN:
                return "putar balik";
            case ROUNDABOUT:
                return "masuk bundaran, ambil jalan keluar ke-" + exitNo;
            case ARRIVE:
                return "tiba di tujuan";
            default:
                return "lurus";
        }
    }

    private static String cap(String s) {
        return s.length() == 0 ? s : Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }

    /** Short instruction for the screen, e.g. "Belok kiri ke Jalan Merdeka". */
    public String text() {
        if (type == START) return street == null ? "Mulai perjalanan" : "Ikuti " + street;
        if (type == ARRIVE) return "Tiba di tujuan";
        String s = cap(action());
        if (street != null && street.length() > 0) s += (type == ROUNDABOUT ? ", ke " : " ke ") + street;
        return s;
    }

    /** Spoken warning given {@code metersAhead} before the maneuver (0 = now). */
    public String speech(double metersAhead) {
        if (type == START) return text();
        if (type == ARRIVE) return metersAhead <= 0 ? "Anda telah tiba di tujuan" : "Dalam " + spoken(metersAhead)
                + ", tujuan Anda";
        String tail = street != null && street.length() > 0 ? " ke " + street : "";
        if (metersAhead < 30) return cap(action()) + tail + " sekarang";
        return "Dalam " + spoken(metersAhead) + ", " + action() + tail;
    }

    // ------------------------------------------------------------------ formatting helpers

    /** Distance for the screen: "80 m", "350 m", "1,2 km", "15 km". */
    public static String fmtDist(double m) {
        if (m < 1000) {
            int r = m < 100 ? (int) (Math.round(m / 10.0) * 10) : (int) (Math.round(m / 50.0) * 50);
            if (r >= 1000) return "1 km";
            return r + " m";
        }
        if (m < 10000) return String.format(Locale.US, "%.1f", m / 1000.0).replace('.', ',') + " km";
        return Math.round(m / 1000.0) + " km";
    }

    private static String spoken(double m) {
        if (m >= 950) {
            double km = Math.round(m / 100.0) / 10.0;
            if (km == Math.floor(km)) return ((int) km) + " kilometer";
            return String.format(Locale.US, "%.1f", km).replace(".", " koma ") + " kilometer";
        }
        int r = m < 100 ? (int) (Math.round(m / 10.0) * 10) : (int) (Math.round(m / 50.0) * 50);
        return r + " meter";
    }

    /** Duration for the screen: "7 mnt", "1 j 20 mnt". */
    public static String fmtTime(double sec) {
        int min = (int) Math.round(sec / 60.0);
        if (min < 1) return "<1 mnt";
        if (min < 60) return min + " mnt";
        return (min / 60) + " j " + (min % 60) + " mnt";
    }
}
