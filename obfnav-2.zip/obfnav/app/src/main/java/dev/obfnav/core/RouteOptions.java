package dev.obfnav.core;

/** What kind of route to compute. Immutable. */
public final class RouteOptions {
    public final boolean motorcycle;
    public final boolean avoidToll;
    public final boolean shortest;

    public RouteOptions(boolean motorcycle, boolean avoidToll, boolean shortest) {
        this.motorcycle = motorcycle;
        this.avoidToll = avoidToll;
        this.shortest = shortest;
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof RouteOptions)) return false;
        RouteOptions r = (RouteOptions) o;
        return r.motorcycle == motorcycle && r.avoidToll == avoidToll && r.shortest == shortest;
    }

    @Override
    public int hashCode() {
        return (motorcycle ? 1 : 0) | (avoidToll ? 2 : 0) | (shortest ? 4 : 0);
    }

    /** Typical travel speed in m/s for a road class; 0 means the vehicle may not use it. */
    public double speed(int cls, int flags) {
        double kmh;
        switch (cls) {
            case Style.MOTORWAY:
                kmh = motorcycle ? 0 : 80;
                break;
            case Style.TRUNK:
                kmh = motorcycle ? 50 : 55;
                break;
            case Style.PRIMARY:
                kmh = motorcycle ? 42 : 45;
                break;
            case Style.SECONDARY:
                kmh = motorcycle ? 38 : 40;
                break;
            case Style.TERTIARY:
                kmh = motorcycle ? 34 : 35;
                break;
            case Style.MINOR:
                kmh = motorcycle ? 28 : 25;
                break;
            case Style.TRACK:
                kmh = motorcycle ? 20 : 15;
                break;
            default:
                kmh = 0;
                break;
        }
        if ((flags & Style.F_LOWSPEED) != 0 && kmh > 0) kmh = Math.min(kmh, 8);
        return kmh / 3.6;
    }

    /** True if this vehicle may drive the way at all. */
    public boolean allowed(RoadSource.Road r) {
        if (motorcycle ? r.noMoto : r.noCar) return false;
        if (speed(r.cls, r.flags) <= 0) return false;
        boolean toll = (r.flags & Style.F_TOLL) != 0;
        if (toll && (avoidToll || motorcycle)) return false; // motorcycles are not allowed on toll roads
        return true;
    }

    /** Upper bound of {@link #speed} over all allowed roads (for the A* heuristic). */
    public double maxSpeed() {
        if (motorcycle) return 50 / 3.6;
        return avoidToll ? 55 / 3.6 : 80 / 3.6;
    }
}
