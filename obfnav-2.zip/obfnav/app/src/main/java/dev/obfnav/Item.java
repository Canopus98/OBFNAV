package dev.obfnav;

/** One row of the full-screen menu. */
final class Item {
    final String label;
    final String value;   // shown right-aligned, may be null
    final int act;
    final int arg;

    Item(String label, String value, int act, int arg) {
        this.label = label;
        this.value = value;
        this.act = act;
        this.arg = arg;
    }
}
