package dev.obfnav.core;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** A small list of saved places, serialised to one text string (stored in SharedPreferences by the app). */
public final class Waypoints {

    public static final class Waypoint {
        public final double lat, lon;
        public final String name;

        public Waypoint(double lat, double lon, String name) {
            this.lat = lat;
            this.lon = lon;
            this.name = name;
        }
    }

    public static final int MAX = 200;

    private final List<Waypoint> list = new ArrayList<Waypoint>();
    private int counter;

    public int size() {
        return list.size();
    }

    public Waypoint get(int i) {
        return list.get(i);
    }

    /** Adds a waypoint; an empty name becomes "WPT 001", "WPT 002", ... @return the stored waypoint. */
    public Waypoint add(double lat, double lon, String name) {
        String n = clean(name);
        if (n.length() == 0) n = String.format(Locale.US, "WPT %03d", ++counter);
        Waypoint w = new Waypoint(lat, lon, n);
        list.add(w);
        if (list.size() > MAX) list.remove(0);
        return w;
    }

    public void remove(int i) {
        if (i >= 0 && i < list.size()) list.remove(i);
    }

    public int nearestIndex(double lat, double lon) {
        int best = -1;
        double bd = Double.MAX_VALUE;
        double x = Geo.lonToX(lon), y = Geo.latToY(lat);
        for (int i = 0; i < list.size(); i++) {
            Waypoint w = list.get(i);
            double d = Geo.dist(x, y, Geo.lonToX(w.lon), Geo.latToY(w.lat));
            if (d < bd) {
                bd = d;
                best = i;
            }
        }
        return best;
    }

    private static String clean(String s) {
        if (s == null) return "";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length() && sb.length() < 60; i++) {
            char c = s.charAt(i);
            if (c == '\n' || c == '\r' || c == '\t') c = ' ';
            sb.append(c);
        }
        return sb.toString().trim();
    }

    // ------------------------------------------------------------------ persistence

    /** One line per waypoint: {@code lat TAB lon TAB name}; the first line holds the name counter. */
    public String serialize() {
        StringBuilder sb = new StringBuilder();
        sb.append("v1 ").append(counter).append('\n');
        for (Waypoint w : list) {
            sb.append(String.format(Locale.US, "%.7f\t%.7f\t%s\n", w.lat, w.lon, w.name));
        }
        return sb.toString();
    }

    /** Parses {@link #serialize()} output; damaged lines are skipped. */
    public static Waypoints parse(String text) {
        Waypoints out = new Waypoints();
        if (text == null) return out;
        String[] lines = text.split("\n");
        for (int i = 0; i < lines.length; i++) {
            String ln = lines[i];
            if (i == 0 && ln.startsWith("v1 ")) {
                try {
                    out.counter = Integer.parseInt(ln.substring(3).trim());
                } catch (NumberFormatException ignored) {
                    out.counter = 0;
                }
                continue;
            }
            String[] f = ln.split("\t", 3);
            if (f.length < 3) continue;
            try {
                double lat = Double.parseDouble(f[0]), lon = Double.parseDouble(f[1]);
                if (Math.abs(lat) > 90 || Math.abs(lon) > 180) continue;
                out.list.add(new Waypoint(lat, lon, clean(f[2])));
            } catch (NumberFormatException ignored) {
                // skip damaged line
            }
        }
        return out;
    }
}
