package dev.obfnav.core;

/**
 * Tiny rule table: maps OSM tag=value pairs (decoded from the OBF rule table) to a drawing class and
 * to routing flags. Classes are numbered in drawing order: a higher number is drawn later (on top).
 */
public final class Style {
    public static final int NONE = 0;
    public static final int URBAN = 1;      // residential / industrial / commercial landuse (fill)
    public static final int VEG = 2;        // forest, grass, farmland, parks (fill)
    public static final int WATER = 3;      // water polygons (fill)
    public static final int COAST = 4;      // natural=coastline
    public static final int WATERWAY = 5;   // rivers, streams, canals
    public static final int BUILDING = 6;
    public static final int RAIL = 7;
    public static final int PATH = 8;       // footway, path, cycleway, steps (not drivable)
    public static final int TRACK = 9;      // first drivable class
    public static final int MINOR = 10;     // residential, service, unclassified
    public static final int TERTIARY = 11;
    public static final int SECONDARY = 12;
    public static final int PRIMARY = 13;
    public static final int TRUNK = 14;
    public static final int MOTORWAY = 15;  // last drivable class
    public static final int PLACE_SMALL = 20; // village, suburb, hamlet...
    public static final int PLACE_BIG = 21;   // city, town

    // ---- per-object flags (OR of the flags of its rules)
    public static final int F_ONEWAY = 1;
    public static final int F_REVERSE = 2;       // oneway=-1: allowed only against the drawing direction
    public static final int F_TOLL = 4;
    public static final int F_LOWSPEED = 8;      // driveway, parking aisle, alley
    public static final int F_ONEWAY_NO = 16;    // explicit oneway=no (cancels implied oneway)
    public static final int F_ROUNDABOUT = 32;
    public static final int F_TOLL_NO = 64;      // explicit toll=no (cancels the motorway-is-toll assumption)

    private static final int A_ACCESS = 1, A_VEHICLE = 2, A_MOTOR_VEHICLE = 3, A_MOTORCAR = 4, A_MOTORCYCLE = 5;
    private static final int A_BLOCK = 8;

    private Style() {
    }

    /** Everything derived from one map index's rule table. */
    public static final class Rules {
        /** Drawing class per rule id. */
        public final int[] cls;
        /** Routing flags per rule id. */
        public final int[] flags;
        private final byte[] acc;
        /** True if the file carries toll=yes tags (then only they mark tolls, not highway=motorway). */
        public final boolean hasTollTag;

        Rules(int n, boolean hasTollTag) {
            cls = new int[n];
            flags = new int[n];
            acc = new byte[n];
            this.hasTollTag = hasTollTag;
        }
    }

    public static Rules buildRules(ObfReader.MapIndex mi) {
        boolean toll = false;
        for (ObfReader.Rule r : mi.rules) {
            if (r != null && "toll".equals(r.tag) && "yes".equals(r.value)) toll = true;
        }
        Rules out = new Rules(mi.rules.length, toll);
        for (int i = 0; i < mi.rules.length; i++) {
            ObfReader.Rule r = mi.rules[i];
            if (r == null || r.tag == null) continue;
            String t = r.tag, v = r.value == null ? "" : r.value;
            out.cls[i] = classify(t, v);
            out.flags[i] = flagsOf(t, v, toll);
            out.acc[i] = (byte) accessOf(t, v);
        }
        return out;
    }

    /** Highest drawing class among the object's rules. */
    public static int classOf(Rules r, int[] types) {
        int best = NONE;
        for (int t : types) {
            if (t >= 0 && t < r.cls.length && r.cls[t] > best) best = r.cls[t];
        }
        return best;
    }

    public static int flagsOf(Rules r, int[] types) {
        int f = 0;
        for (int t : types) {
            if (t >= 0 && t < r.flags.length) f |= r.flags[t];
        }
        if ((f & F_ONEWAY_NO) != 0) f &= ~(F_ONEWAY | F_REVERSE);
        if ((f & F_TOLL_NO) != 0) f &= ~F_TOLL;
        return f;
    }

    /**
     * True if the object may not be driven by the given vehicle. The most specific access tag wins
     * (motorcar / motorcycle over motor_vehicle over vehicle over access).
     */
    public static boolean accessBlocked(Rules r, int[] types, boolean motorcycle) {
        int bestKind = 0;
        boolean blocked = false;
        for (int t : types) {
            if (t < 0 || t >= r.acc.length) continue;
            int a = r.acc[t];
            if (a == 0) continue;
            int kind = a & 7;
            if (kind == (motorcycle ? A_MOTORCAR : A_MOTORCYCLE)) continue; // other vehicle's tag
            if (kind > bestKind) {
                bestKind = kind;
                blocked = (a & A_BLOCK) != 0;
            }
        }
        return blocked;
    }

    private static int accessOf(String tag, String v) {
        int kind;
        if (tag.equals("access")) kind = A_ACCESS;
        else if (tag.equals("vehicle")) kind = A_VEHICLE;
        else if (tag.equals("motor_vehicle")) kind = A_MOTOR_VEHICLE;
        else if (tag.equals("motorcar")) kind = A_MOTORCAR;
        else if (tag.equals("motorcycle")) kind = A_MOTORCYCLE;
        else return 0;
        boolean block = v.equals("no") || v.equals("private") || v.equals("customers") || v.equals("permit")
                || v.equals("delivery") || v.equals("agricultural") || v.equals("forestry");
        return kind | (block ? A_BLOCK : 0);
    }

    private static int flagsOf(String tag, String v, boolean fileHasTollTag) {
        if (tag.equals("oneway")) {
            if (v.equals("yes") || v.equals("1") || v.equals("true")) return F_ONEWAY;
            if (v.equals("-1") || v.equals("reverse")) return F_REVERSE;
            if (v.equals("no") || v.equals("0") || v.equals("false")) return F_ONEWAY_NO;
            return 0;
        }
        if (tag.equals("junction")) {
            return v.equals("roundabout") || v.equals("circular") ? (F_ONEWAY | F_ROUNDABOUT) : 0;
        }
        if (tag.equals("toll")) return v.equals("yes") ? F_TOLL : (v.equals("no") ? F_TOLL_NO : 0);
        if (tag.equals("highway")) {
            // Motorways are one-way by default. In Indonesia (where this app is meant to be used) every
            // motorway is a toll road and most of them carry no toll=yes tag, so they count as tolls
            // unless tagged toll=no.
            if (v.startsWith("motorway")) return F_ONEWAY | F_TOLL;
            return 0;
        }
        if (tag.equals("service")) {
            return v.equals("driveway") || v.equals("parking_aisle") || v.equals("alley") ? F_LOWSPEED : 0;
        }
        return 0;
    }

    public static int classify(String tag, String v) {
        if (tag == null) return NONE;
        if (v == null) v = "";
        if (tag.equals("highway")) {
            if (v.startsWith("motorway")) return MOTORWAY;
            if (v.startsWith("trunk")) return TRUNK;
            if (v.startsWith("primary")) return PRIMARY;
            if (v.startsWith("secondary")) return SECONDARY;
            if (v.startsWith("tertiary")) return TERTIARY;
            if (v.equals("residential") || v.equals("unclassified") || v.equals("living_street")
                    || v.equals("service") || v.equals("road")) return MINOR;
            if (v.equals("track")) return TRACK;
            if (v.equals("footway") || v.equals("path") || v.equals("cycleway") || v.equals("steps")
                    || v.equals("pedestrian") || v.equals("bridleway")) return PATH;
            return NONE;
        }
        if (tag.equals("building")) return v.equals("no") ? NONE : BUILDING;
        if (tag.equals("natural")) {
            if (v.equals("water") || v.equals("bay")) return WATER;
            if (v.equals("coastline")) return COAST;
            if (v.equals("wood") || v.equals("scrub") || v.equals("grassland") || v.equals("heath")
                    || v.equals("wetland")) return VEG;
            return NONE;
        }
        if (tag.equals("waterway")) {
            if (v.equals("riverbank") || v.equals("dock")) return WATER;
            if (v.equals("river") || v.equals("stream") || v.equals("canal") || v.equals("drain")
                    || v.equals("ditch")) return WATERWAY;
            return NONE;
        }
        if (tag.equals("landuse")) {
            if (v.equals("reservoir") || v.equals("basin")) return WATER;
            if (v.equals("forest") || v.equals("farmland") || v.equals("meadow") || v.equals("grass")
                    || v.equals("orchard") || v.equals("vineyard") || v.equals("village_green")
                    || v.equals("recreation_ground") || v.equals("greenhouse_horticulture")
                    || v.equals("plant_nursery") || v.equals("cemetery") || v.equals("allotments")) return VEG;
            if (v.equals("residential") || v.equals("industrial") || v.equals("commercial")
                    || v.equals("retail") || v.equals("construction") || v.equals("railway")
                    || v.equals("military") || v.equals("religious") || v.equals("garages")) return URBAN;
            return NONE;
        }
        if (tag.equals("leisure")) {
            if (v.equals("park") || v.equals("garden") || v.equals("nature_reserve") || v.equals("golf_course")
                    || v.equals("common")) return VEG;
            return NONE;
        }
        if (tag.equals("railway")) {
            if (v.equals("rail") || v.equals("light_rail") || v.equals("narrow_gauge")
                    || v.equals("tram") || v.equals("subway")) return RAIL;
            return NONE;
        }
        if (tag.equals("place")) {
            if (v.equals("city") || v.equals("town")) return PLACE_BIG;
            if (v.equals("village") || v.equals("suburb") || v.equals("hamlet")
                    || v.equals("neighbourhood") || v.equals("quarter")) return PLACE_SMALL;
            return NONE;
        }
        return NONE;
    }

    /** Lowest zoom at which a class is drawn (keeps low zoom levels fast and uncluttered). */
    public static int minZoom(int cls) {
        switch (cls) {
            case WATER:
            case COAST:
            case MOTORWAY:
            case TRUNK:
            case PRIMARY:
                return 0;
            case VEG:
                return 10;
            case URBAN:
                return 11;
            case PLACE_BIG:
                return 6;
            case SECONDARY:
                return 10;
            case RAIL:
                return 11;
            case WATERWAY:
            case TERTIARY:
            case PLACE_SMALL:
                return 12;
            case MINOR:
                return 14;
            case TRACK:
                return 15;
            case BUILDING:
            case PATH:
                return 16;
            default:
                return 99;
        }
    }

    /** Indonesian toll roads are usually named "Jalan Tol ..." even when the toll tag is missing. */
    public static boolean tollByName(String name) {
        if (name == null) return false;
        String ln = name.toLowerCase(java.util.Locale.ROOT);
        return ln.startsWith("jalan tol") || ln.startsWith("tol ");
    }

    public static boolean isRoad(int cls) {
        return cls >= MINOR && cls <= MOTORWAY;
    }

    /** Roads a car or motorcycle can use (includes tracks, excludes footpaths). */
    public static boolean isDrivable(int cls) {
        return cls >= TRACK && cls <= MOTORWAY;
    }

    public static boolean isPlace(int cls) {
        return cls >= PLACE_SMALL;
    }

    /** True for classes drawn as filled polygons when the object is an area. */
    public static boolean isFill(int cls) {
        return cls == URBAN || cls == VEG || cls == WATER || cls == BUILDING;
    }
}
