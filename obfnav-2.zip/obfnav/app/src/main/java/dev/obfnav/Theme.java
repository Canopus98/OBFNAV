package dev.obfnav;

/**
 * Small fixed palettes in the spirit of old handheld GPS units: few colours, high contrast.
 * Day: green land, blue water, black roads, dark-red toll roads. Night: the same idea on dark backgrounds
 * (toll red is brighter there, because dark red would vanish on a dark screen).
 */
final class Theme {
    final int land, vegetation, urban, water, waterLine, building, rail;
    final int road, toll, route, routeCasing, gps;
    final int barBg, barFg, labelBg, waypoint;

    private Theme(int land, int vegetation, int urban, int water, int waterLine, int building, int rail,
                  int road, int toll, int route, int routeCasing, int gps,
                  int barBg, int barFg, int labelBg, int waypoint) {
        this.land = land;
        this.vegetation = vegetation;
        this.urban = urban;
        this.water = water;
        this.waterLine = waterLine;
        this.building = building;
        this.rail = rail;
        this.road = road;
        this.toll = toll;
        this.route = route;
        this.routeCasing = routeCasing;
        this.gps = gps;
        this.barBg = barBg;
        this.barFg = barFg;
        this.labelBg = labelBg;
        this.waypoint = waypoint;
    }

    static final Theme DAY = new Theme(
            0xFFC4E5A4,  // land: light green
            0xFF86C46E,  // forest / farmland / parks: mid green
            0xFFEFE9CC,  // built-up areas: pale sand
            0xFF4A90E2,  // water: blue
            0xFF1858B8,  // rivers, coast: dark blue
            0xFF8A8A8A,  // buildings: grey
            0xFF404040,  // railway
            0xFF000000,  // roads: black
            0xFF8B0000,  // toll roads: dark red
            0xFFE000E0,  // route: magenta
            0xFFFFFFFF,  // route casing
            0xFF0000FF,  // GPS position
            0xFFFFFFFF, 0xFF000000, 0xFFFFFFFF, 0xFFB35A00);

    static final Theme NIGHT = new Theme(
            0xFF10280F,
            0xFF1B4720,
            0xFF2B2B2B,
            0xFF0F3E86,
            0xFF4E9BFF,
            0xFF777777,
            0xFFB0B0B0,
            0xFFF2F2F2,
            0xFFFF5A5A,
            0xFFFF40FF,
            0xFF000000,
            0xFF40E0FF,
            0xFF000000, 0xFFFFFFFF, 0xFF000000, 0xFFFFB347);
}
