package dev.obfnav.core;

/** A computed route: a polyline plus turn instructions. */
public final class Route {
    /** Polyline in 31-bit coordinates. */
    public int[] x, y;
    /** Meters and seconds from the start to each polyline point. */
    public double[] cumDist, cumTime;
    public Maneuver[] maneuvers;
    public double totalDist, totalTime;
    /** True if the route uses at least one toll road. */
    public boolean usesToll;
    public RouteOptions options;

    public int size() {
        return x.length;
    }

    public String summary() {
        return Maneuver.fmtDist(totalDist) + " - " + Maneuver.fmtTime(totalTime) + (usesToll ? " - TOL" : "");
    }
}
