package dev.obfnav;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

import dev.obfnav.core.Feature;
import dev.obfnav.core.Geo;
import dev.obfnav.core.Maneuver;
import dev.obfnav.core.NavSession;
import dev.obfnav.core.ObfReader;
import dev.obfnav.core.Route;
import dev.obfnav.core.Style;
import dev.obfnav.core.Waypoints;

/**
 * Vector map view with big touch buttons, a navigation panel and a full-screen menu.
 * No bitmaps, no animation: it redraws only on input or when the worker thread delivered new data.
 */
public final class MapView extends View {

    public interface Host {
        void onAction(int act, int arg);
    }

    private static final int MAX_FEATURES = 60000;
    private static final int MIN_ZOOM = 1;
    private static final int MAX_ZOOM = 19;

    private static final class Loaded {
        List<Feature> feats;
        int left, right, top, bottom;
        int zoom;
        boolean truncated;
    }

    private static final class Button {
        final int id;
        final RectF r = new RectF();
        String label = "";
        boolean on;

        Button(int id) {
            this.id = id;
        }
    }

    private Host host;
    private ObfReader reader;
    private Style.Rules[] rules;
    private String fileName = "";
    private String status = "";
    private String info = "";

    private double cx = Geo.lonToX(106.8456), cy = Geo.latToY(-6.2088);
    private int zoom = 14;
    private int minZoom = MIN_ZOOM, maxZoom = MAX_ZOOM;
    private Theme theme = Theme.DAY;
    private boolean showNames = true;

    private boolean hasGps;
    private double gpsLat, gpsLon, gpsSpeed;
    private boolean followGps;

    private Route route;
    private NavSession.State nav;
    private boolean hasStartMark, hasDestMark;
    private double startLat, startLon, destLat, destLon;
    private Waypoints waypoints;

    // menu
    private boolean menuOpen;
    private String menuTitle = "";
    private Item[] menuItems = new Item[0];
    private int menuSel;
    private float menuScroll;

    private volatile Loaded loaded;
    private final Object lock = new Object();
    private boolean pending;
    private int rl, rr, rt, rb, rz;
    private boolean closed;

    private final float density, sp;
    private final Paint line = new Paint();
    private final Paint fill = new Paint();
    private final Paint text = new Paint();
    private final Path path = new Path();
    private final Button[] buttons = {
            new Button(Act.ZOOM_OUT), new Button(Act.ZOOM_IN), new Button(Act.GPS),
            new Button(Act.GOTO), new Button(Act.MENU)};
    private final RectF closeBtn = new RectF();
    private final List<float[]> labelRects = new ArrayList<float[]>();
    private float downX, downY, lastX, lastY;
    private boolean dragged, pinching;
    private double pinchStart;
    private int pinchZoom;

    public MapView(Context ctx) {
        super(ctx);
        density = ctx.getResources().getDisplayMetrics().density;
        sp = ctx.getResources().getDisplayMetrics().scaledDensity;
        setFocusable(true);
        setFocusableInTouchMode(true);
        line.setAntiAlias(true);
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeCap(Paint.Cap.ROUND);
        line.setStrokeJoin(Paint.Join.ROUND);
        fill.setAntiAlias(false);
        fill.setStyle(Paint.Style.FILL);
        text.setAntiAlias(true);
        text.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        text.setTextSize(14f * sp);
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                loop();
            }
        }, "obf-loader");
        t.setPriority(Thread.NORM_PRIORITY - 1);
        t.setDaemon(true);
        t.start();
    }

    private float dp(float v) {
        return v * density;
    }

    // ------------------------------------------------------------------ state set by the activity

    public void setHost(Host h) {
        host = h;
    }

    public void setStatus(String s) {
        status = s == null ? "" : s;
        postInvalidate();
    }

    public void setNight(boolean n) {
        theme = n ? Theme.NIGHT : Theme.DAY;
        postInvalidate();
    }

    public void setShowNames(boolean v) {
        showNames = v;
        postInvalidate();
    }

    public int getZoom() {
        return zoom;
    }

    public void setZoom(int z) {
        zoom = Math.max(minZoom, Math.min(maxZoom, z));
        postInvalidate();
    }

    public double getCenterLat() {
        return Geo.yToLat(cy);
    }

    public double getCenterLon() {
        return Geo.xToLon(cx);
    }

    public void setCenter(double lat, double lon) {
        cx = Geo.lonToX(lon);
        cy = Geo.latToY(lat);
        postInvalidate();
    }

    public void setGps(boolean has, double lat, double lon, double speedKmh) {
        hasGps = has;
        gpsLat = lat;
        gpsLon = lon;
        gpsSpeed = speedKmh;
        if (has && followGps) {
            cx = Geo.lonToX(lon);
            cy = Geo.latToY(lat);
        }
        postInvalidate();
    }

    public boolean isFollowGps() {
        return followGps;
    }

    public void setFollowGps(boolean f) {
        followGps = f;
        if (f && hasGps) {
            cx = Geo.lonToX(gpsLon);
            cy = Geo.latToY(gpsLat);
        }
        postInvalidate();
    }

    public void setRoute(Route r) {
        route = r;
        nav = null;
        postInvalidate();
    }

    public void setNav(NavSession.State st) {
        nav = st;
        postInvalidate();
    }

    public void setMarks(boolean hasStart, double sLat, double sLon, boolean hasDest, double dLat, double dLon) {
        hasStartMark = hasStart;
        startLat = sLat;
        startLon = sLon;
        hasDestMark = hasDest;
        destLat = dLat;
        destLon = dLon;
        postInvalidate();
    }

    public void setWaypoints(Waypoints w) {
        waypoints = w;
        postInvalidate();
    }

    /** Centres the view on a rectangle (31-bit coordinates) and picks the largest zoom that shows all of it. */
    public void fitBounds(double l, double r, double t, double b) {
        int w = Math.max(1, getWidth()), h = Math.max(1, getHeight());
        cx = (l + r) / 2;
        cy = (t + b) / 2;
        int z = maxZoom;
        while (z > minZoom) {
            double upp = Math.pow(2.0, 23 - z) / density;
            if ((r - l) / upp <= w * 0.85 && (b - t) / upp <= h * 0.5) break;
            z--;
        }
        zoom = z;
        followGps = false;
        postInvalidate();
    }

    public void showMenu(String title, Item[] items, int sel) {
        menuTitle = title;
        menuItems = items;
        menuSel = Math.max(0, Math.min(items.length - 1, sel));
        menuOpen = true;
        menuScroll = 0;
        ensureMenuVisible();
        postInvalidate();
    }

    public void hideMenu() {
        menuOpen = false;
        postInvalidate();
    }

    public boolean isMenuOpen() {
        return menuOpen;
    }

    public int getMenuSel() {
        return menuSel;
    }

    /** Installs a new map file; the view jumps to the middle of its coverage if the view is outside it. */
    public void setReader(ObfReader r, String name) {
        synchronized (lock) {
            reader = r;
            fileName = name;
            loaded = null;
            info = "";
            if (r == null) {
                rules = null;
                minZoom = MIN_ZOOM;
                maxZoom = MAX_ZOOM;
                postInvalidate();
                return;
            }
            List<ObfReader.MapIndex> maps = r.getMaps();
            rules = new Style.Rules[maps.size()];
            int lo = Integer.MAX_VALUE, hi = 0;
            boolean inside = false;
            for (int i = 0; i < maps.size(); i++) {
                ObfReader.MapIndex mi = maps.get(i);
                rules[i] = Style.buildRules(mi);
                if (!mi.levels.isEmpty()) {
                    lo = Math.min(lo, mi.minZoom());
                    hi = Math.max(hi, mi.maxZoom());
                    for (ObfReader.Level lv : mi.levels) {
                        if (cx >= lv.left && cx <= lv.right && cy >= lv.top && cy <= lv.bottom) inside = true;
                    }
                }
            }
            if (hi > 0) {
                minZoom = Math.max(MIN_ZOOM, lo);
                maxZoom = Math.min(MAX_ZOOM, hi);
            }
            if (!inside && !maps.isEmpty() && maps.get(0).centerX() >= 0) {
                cx = maps.get(0).centerX();
                cy = maps.get(0).centerY();
            }
            zoom = Math.max(minZoom, Math.min(maxZoom, Math.max(zoom, 12)));
        }
        postInvalidate();
    }

    public void close() {
        synchronized (lock) {
            closed = true;
            lock.notifyAll();
        }
    }

    // ------------------------------------------------------------------ loading

    private void requestLoad(int l, int r, int t, int b, int z) {
        synchronized (lock) {
            rl = l;
            rr = r;
            rt = t;
            rb = b;
            rz = z;
            pending = true;
            lock.notifyAll();
        }
    }

    private void loop() {
        while (true) {
            int l, r, t, b, z;
            ObfReader rd;
            Style.Rules[] rs;
            synchronized (lock) {
                while (!pending && !closed) {
                    try {
                        lock.wait();
                    } catch (InterruptedException e) {
                        return;
                    }
                }
                if (closed) return;
                l = rl;
                r = rr;
                t = rt;
                b = rb;
                z = rz;
                pending = false;
                rd = reader;
                rs = rules;
            }
            if (rd == null || rs == null) continue;
            final List<Feature> out = new ArrayList<Feature>();
            final boolean[] truncated = {false};
            final int zz = z;
            try {
                List<ObfReader.MapIndex> maps = rd.getMaps();
                for (int i = 0; i < maps.size(); i++) {
                    final Style.Rules rl2 = rs[i];
                    rd.search(maps.get(i), l, r, t, b, z, new ObfReader.TypeFilter() {
                        @Override
                        public boolean accept(ObfReader.MapIndex map, int[] types) {
                            for (int ty : types) {
                                if (ty >= 0 && ty < rl2.cls.length) {
                                    int c = rl2.cls[ty];
                                    if (c != Style.NONE && zz >= Style.minZoom(c)) return true;
                                }
                            }
                            return false;
                        }
                    }, new ObfReader.FeatureSink() {
                        @Override
                        public boolean accept(ObfReader.MapIndex map, Feature f) {
                            f.cls = Style.classOf(rl2, f.types);
                            if (f.cls == Style.NONE || zz < Style.minZoom(f.cls)) return true;
                            if (Style.isPlace(f.cls) && f.name == null) return true;
                            f.flags = Style.flagsOf(rl2, f.types);
                            if (Style.isRoad(f.cls) && (f.flags & Style.F_TOLL) == 0 && Style.tollByName(f.name)) {
                                f.flags |= Style.F_TOLL;
                            }
                            out.add(f);
                            if (out.size() >= MAX_FEATURES) {
                                truncated[0] = true;
                                return false;
                            }
                            return true;
                        }
                    });
                    if (truncated[0]) break;
                }
            } catch (IOException e) {
                setStatus("ERR " + e.getMessage());
                continue;
            }
            Collections.sort(out, new Comparator<Feature>() {
                @Override
                public int compare(Feature x, Feature y) {
                    int a = order(x), c = order(y);
                    return a < c ? -1 : (a == c ? 0 : 1);
                }
            });
            Loaded ld = new Loaded();
            ld.feats = out;
            ld.left = l;
            ld.right = r;
            ld.top = t;
            ld.bottom = b;
            ld.zoom = z;
            ld.truncated = truncated[0];
            loaded = ld;
            postInvalidate();
        }
    }

    /** Draw order: by class, but toll roads after every other road so the dark red stays visible. */
    private static int order(Feature f) {
        return Style.isRoad(f.cls) && (f.flags & Style.F_TOLL) != 0 ? 100 + f.cls : f.cls;
    }

    // ------------------------------------------------------------------ drawing

    private double unitsPerPx() {
        return Math.pow(2.0, 23 - zoom) / density;
    }

    private float zoomScale() {
        if (zoom <= 11) return 0.6f;
        if (zoom <= 13) return 0.8f;
        if (zoom <= 15) return 1.0f;
        if (zoom == 16) return 1.3f;
        if (zoom == 17) return 1.8f;
        if (zoom == 18) return 2.4f;
        return 3.2f;
    }

    private float roadWidth(int cls) {
        float base;
        switch (cls) {
            case Style.MOTORWAY:
            case Style.TRUNK:
                base = 3.0f;
                break;
            case Style.PRIMARY:
                base = 2.6f;
                break;
            case Style.SECONDARY:
                base = 2.2f;
                break;
            case Style.TERTIARY:
                base = 1.8f;
                break;
            case Style.MINOR:
                base = 1.4f;
                break;
            default:
                base = 1.0f;
                break;
        }
        return Math.max(1.5f, dp(base * zoomScale()));
    }

    private int colorOf(Feature f) {
        switch (f.cls) {
            case Style.URBAN:
                return theme.urban;
            case Style.VEG:
                return theme.vegetation;
            case Style.WATER:
                return theme.water;
            case Style.COAST:
            case Style.WATERWAY:
                return theme.waterLine;
            case Style.BUILDING:
                return theme.building;
            case Style.RAIL:
                return theme.rail;
            default:
                if (Style.isRoad(f.cls) && (f.flags & Style.F_TOLL) != 0) return theme.toll;
                return theme.road;
        }
    }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        if (menuOpen) {
            drawMenu(c, w, h);
            return;
        }
        c.drawColor(theme.land);

        double upp = unitsPerPx();
        double halfW = w / 2.0 * upp, halfH = h / 2.0 * upp;
        int vl = (int) Math.max(0, cx - halfW), vr = (int) Math.min(Integer.MAX_VALUE, cx + halfW);
        int vt = (int) Math.max(0, cy - halfH), vb = (int) Math.min(Integer.MAX_VALUE, cy + halfH);

        Loaded ld = loaded;
        if (reader != null && w > 0) {
            boolean covered = ld != null && ld.zoom == zoom && vl >= ld.left && vr <= ld.right
                    && vt >= ld.top && vb <= ld.bottom;
            if (!covered) {
                int ml = (int) (halfW * 1.5), mt = (int) (halfH * 1.5);
                requestLoad((int) Math.max(0, cx - halfW - ml), (int) Math.min(Integer.MAX_VALUE, cx + halfW + ml),
                        (int) Math.max(0, cy - halfH - mt), (int) Math.min(Integer.MAX_VALUE, cy + halfH + mt),
                        zoom);
            }
        }

        labelRects.clear();
        double ox = cx - halfW, oy = cy - halfH;
        double inv = 1.0 / upp;
        if (ld != null) {
            for (int i = 0; i < ld.feats.size(); i++) {
                Feature f = ld.feats.get(i);
                if (zoom < Style.minZoom(f.cls)) continue;
                if (f.maxX < vl || f.minX > vr || f.maxY < vt || f.minY > vb) continue;
                if (Style.isPlace(f.cls)) continue;
                drawFeature(c, f, ox, oy, inv);
            }
            line.setPathEffect(null);
        }
        drawRoute(c, ox, oy, inv);
        drawWaypoints(c, ox, oy, inv, w, h);
        drawMarks(c, ox, oy, inv);
        if (ld != null && showNames) drawLabels(c, ld, ox, oy, inv, vl, vr, vt, vb, w, h);
        drawGps(c, ox, oy, inv);
        drawChrome(c, w, h, ld);
    }

    private void drawFeature(Canvas c, Feature f, double ox, double oy, double inv) {
        int[] xy = f.xy;
        if (f.area && Style.isFill(f.cls)) {
            buildPath(xy, ox, oy, inv, true);
            fill.setColor(colorOf(f));
            c.drawPath(path, fill);
            return;
        }
        line.setColor(colorOf(f));
        line.setPathEffect(null);
        float w = dp(1f);
        if (Style.isDrivable(f.cls) || Style.isRoad(f.cls)) {
            w = roadWidth(f.cls);
        } else if (f.cls == Style.TRACK) {
            line.setPathEffect(new DashPathEffect(new float[]{dp(6), dp(4)}, 0));
        } else if (f.cls == Style.PATH) {
            line.setPathEffect(new DashPathEffect(new float[]{dp(2), dp(3)}, 0));
        } else if (f.cls == Style.RAIL) {
            line.setPathEffect(new DashPathEffect(new float[]{dp(10), dp(4)}, 0));
            w = dp(1.5f);
        } else if (f.cls == Style.WATERWAY || f.cls == Style.COAST) {
            w = Math.max(dp(1.5f), dp(1.5f * zoomScale()));
        }
        line.setStrokeWidth(w);
        buildPath(xy, ox, oy, inv, f.area);
        c.drawPath(path, line);
    }

    private void buildPath(int[] xy, double ox, double oy, double inv, boolean close) {
        path.rewind();
        float lastX = 0, lastY = 0;
        boolean started = false;
        for (int i = 0; i < xy.length; i += 2) {
            float sx = (float) ((xy[i] - ox) * inv);
            float sy = (float) ((xy[i + 1] - oy) * inv);
            if (!started) {
                path.moveTo(sx, sy);
                started = true;
            } else if (Math.abs(sx - lastX) >= 1f || Math.abs(sy - lastY) >= 1f) {
                path.lineTo(sx, sy);
            } else {
                continue;
            }
            lastX = sx;
            lastY = sy;
        }
        if (close) path.close();
    }

    private void drawRoute(Canvas c, double ox, double oy, double inv) {
        Route r = route;
        if (r == null || r.x.length < 2) return;
        path.rewind();
        for (int i = 0; i < r.x.length; i++) {
            float sx = (float) ((r.x[i] - ox) * inv);
            float sy = (float) ((r.y[i] - oy) * inv);
            if (i == 0) path.moveTo(sx, sy);
            else path.lineTo(sx, sy);
        }
        line.setPathEffect(null);
        line.setColor(theme.routeCasing);
        line.setStrokeWidth(dp(9));
        c.drawPath(path, line);
        line.setColor(theme.route);
        line.setStrokeWidth(dp(5));
        c.drawPath(path, line);
    }

    private float sx(double lon, double ox, double inv) {
        return (float) ((Geo.lonToX(lon) - ox) * inv);
    }

    private float sy(double lat, double oy, double inv) {
        return (float) ((Geo.latToY(lat) - oy) * inv);
    }

    private void drawDiamond(Canvas c, float x, float y, float r, int color) {
        path.rewind();
        path.moveTo(x, y - r);
        path.lineTo(x + r, y);
        path.lineTo(x, y + r);
        path.lineTo(x - r, y);
        path.close();
        fill.setColor(theme.labelBg);
        c.drawPath(path, fill);
        line.setColor(color);
        line.setStrokeWidth(dp(3));
        c.drawPath(path, line);
    }

    private void drawWaypoints(Canvas c, double ox, double oy, double inv, int w, int h) {
        Waypoints wp = waypoints;
        if (wp == null || zoom < 9) return;
        line.setPathEffect(null);
        for (int i = 0; i < wp.size(); i++) {
            Waypoints.Waypoint p = wp.get(i);
            float x = sx(p.lon, ox, inv), y = sy(p.lat, oy, inv);
            if (x < -50 || y < -50 || x > w + 50 || y > h + 50) continue;
            drawDiamond(c, x, y, dp(9), theme.waypoint);
            if (showNames && zoom >= 12) placeLabel(c, p.name, x, y - dp(12), w, h);
        }
    }

    private void drawMark(Canvas c, float x, float y, String s, int color) {
        float r = dp(13);
        fill.setColor(color);
        c.drawCircle(x, y, r, fill);
        line.setColor(theme.labelBg);
        line.setStrokeWidth(dp(2));
        c.drawCircle(x, y, r, line);
        text.setTextSize(15f * sp);
        text.setColor(theme.labelBg);
        c.drawText(s, x - text.measureText(s) / 2, y + dp(5), text);
        text.setTextSize(14f * sp);
    }

    private void drawMarks(Canvas c, double ox, double oy, double inv) {
        line.setPathEffect(null);
        if (hasStartMark) drawMark(c, sx(startLon, ox, inv), sy(startLat, oy, inv), "A", theme.road);
        if (hasDestMark) drawMark(c, sx(destLon, ox, inv), sy(destLat, oy, inv), "B", theme.toll);
    }

    private boolean placeLabel(Canvas c, String s, float x, float y, int w, int h) {
        if (s == null || s.length() == 0) return false;
        float tw = text.measureText(s);
        float th = text.getTextSize();
        float l = x - tw / 2, t = y - th, r = x + tw / 2, b = y + 4;
        if (l < 2 || r > w - 2 || t < dp(34) || b > h - dp(120)) return false;
        for (float[] q : labelRects) {
            if (l < q[2] && r > q[0] && t < q[3] && b > q[1]) return false;
        }
        labelRects.add(new float[]{l, t, r, b});
        fill.setColor(theme.labelBg);
        c.drawRect(l - 2, t, r + 2, b, fill);
        text.setColor(theme.barFg);
        c.drawText(s, l, y, text);
        return true;
    }

    private void drawLabels(Canvas c, Loaded ld, double ox, double oy, double inv,
                            int vl, int vr, int vt, int vb, int w, int h) {
        int roadLabels = 0;
        for (int pass = 0; pass < 2; pass++) {
            for (int i = ld.feats.size() - 1; i >= 0; i--) {
                Feature f = ld.feats.get(i);
                if (f.name == null) continue;
                if (pass == 0 && !Style.isPlace(f.cls)) continue;
                if (pass == 1 && (!Style.isRoad(f.cls) || zoom < 15 || roadLabels > 40)) continue;
                if (f.maxX < vl || f.minX > vr || f.maxY < vt || f.minY > vb) continue;
                int n = f.xy.length / 2;
                int mid = (n / 2) * 2;
                float x = (float) ((f.xy[mid] - ox) * inv);
                float y = (float) ((f.xy[mid + 1] - oy) * inv);
                if (placeLabel(c, f.name, x, y, w, h) && pass == 1) roadLabels++;
            }
        }
    }

    private void drawGps(Canvas c, double ox, double oy, double inv) {
        if (!hasGps) return;
        float x = sx(gpsLon, ox, inv), y = sy(gpsLat, oy, inv);
        line.setPathEffect(null);
        fill.setColor(theme.labelBg);
        c.drawCircle(x, y, dp(11), fill);
        fill.setColor(theme.gps);
        c.drawCircle(x, y, dp(8), fill);
        line.setColor(theme.barFg);
        line.setStrokeWidth(dp(2));
        c.drawCircle(x, y, dp(11), line);
    }

    // ------------------------------------------------------------------ chrome: top panel, info strip, buttons

    private float barH() {
        return dp(64);
    }

    private void drawChrome(Canvas c, int w, int h, Loaded ld) {
        line.setPathEffect(null);
        float mx = w / 2f, my = h / 2f, cr = dp(9);
        line.setColor(theme.barFg);
        line.setStrokeWidth(dp(2));
        c.drawLine(mx - cr, my, mx + cr, my, line);
        c.drawLine(mx, my - cr, mx, my + cr, line);

        if (reader == null) {
            text.setTextSize(18f * sp);
            text.setColor(theme.barFg);
            String[] hint = {"Belum ada peta.", "Buka MENU > BUKA PETA", "lalu pilih file .obf"};
            for (int i = 0; i < hint.length; i++) {
                float tw = text.measureText(hint[i]);
                fill.setColor(theme.labelBg);
                c.drawRect(mx - tw / 2 - 6, my + dp(40) + i * dp(30) - dp(20), mx + tw / 2 + 6,
                        my + dp(40) + i * dp(30) + dp(8), fill);
                c.drawText(hint[i], mx - tw / 2, my + dp(40) + i * dp(30), text);
            }
            text.setTextSize(14f * sp);
        }

        float top = drawTopPanel(c, w, ld);

        // info strip above the buttons
        float bh = barH();
        float sh = dp(40);
        float sy0 = h - bh - sh;
        fill.setColor(theme.barBg);
        c.drawRect(0, sy0, w, h - bh, fill);
        line.setColor(theme.barFg);
        line.setStrokeWidth(dp(2));
        c.drawLine(0, sy0, w, sy0, line);
        text.setTextSize(16f * sp);
        text.setColor(theme.barFg);
        String s;
        if (status.length() > 0) s = status;
        else if (info.length() > 0) s = info;
        else if (nav != null && route != null) {
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.SECOND, (int) nav.remainingTime);
            s = String.format(Locale.US, "%s  %s  ETA %02d:%02d  %d km/j", Maneuver.fmtDist(nav.remainingDist),
                    Maneuver.fmtTime(nav.remainingTime), cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE),
                    (int) Math.round(gpsSpeed));
        } else {
            s = String.format(Locale.US, "%.5f %.5f", getCenterLat(), getCenterLon());
        }
        c.drawText(fit(s, w - dp(12)), dp(6), sy0 + sh / 2 + dp(6), text);
        text.setTextSize(14f * sp);

        // buttons
        buttons[0].label = "-";
        buttons[1].label = "+";
        buttons[2].label = "GPS";
        buttons[3].label = route != null ? "BATAL" : "TUJU";
        buttons[4].label = "MENU";
        buttons[2].on = followGps;
        float by = h - bh;
        fill.setColor(theme.barBg);
        c.drawRect(0, by, w, h, fill);
        float bw = w / (float) buttons.length;
        for (int i = 0; i < buttons.length; i++) {
            Button b = buttons[i];
            b.r.set(i * bw + dp(3), by + dp(4), (i + 1) * bw - dp(3), h - dp(4));
            if (b.on) {
                fill.setColor(theme.barFg);
                c.drawRect(b.r, fill);
            }
            line.setColor(theme.barFg);
            line.setStrokeWidth(dp(3));
            c.drawRect(b.r, line);
            float size = (i < 2 ? 34f : 20f) * sp;
            text.setTextSize(size);
            while (size > 10 * sp && text.measureText(b.label) > b.r.width() - dp(8)) {
                size -= sp;
                text.setTextSize(size);
            }
            text.setColor(b.on ? theme.barBg : theme.barFg);
            c.drawText(b.label, b.r.centerX() - text.measureText(b.label) / 2, b.r.centerY() + size / 3, text);
        }
        text.setTextSize(14f * sp);
    }

    private String fit(String s, float maxW) {
        if (text.measureText(s) <= maxW) return s;
        while (s.length() > 1 && text.measureText(s + "..") > maxW) s = s.substring(0, s.length() - 1);
        return s + "..";
    }

    /** @return height of the panel. */
    private float drawTopPanel(Canvas c, int w, Loaded ld) {
        if (route == null) {
            float th = dp(30);
            fill.setColor(theme.barBg);
            c.drawRect(0, 0, w, th, fill);
            line.setColor(theme.barFg);
            line.setStrokeWidth(dp(2));
            c.drawLine(0, th, w, th, line);
            text.setTextSize(14f * sp);
            text.setColor(theme.barFg);
            String t = (fileName.length() == 0 ? "(belum ada peta)" : fileName) + "  Z" + zoom
                    + (ld != null && ld.truncated ? " [PENUH]" : "");
            c.drawText(fit(t, w - dp(10)), dp(6), th - dp(9), text);
            return th;
        }
        float ph = dp(96);
        fill.setColor(theme.barBg);
        c.drawRect(0, 0, w, ph, fill);
        line.setColor(theme.barFg);
        line.setStrokeWidth(dp(3));
        c.drawLine(0, ph, w, ph, line);
        text.setColor(theme.barFg);
        if (nav == null || nav.next == null) {
            text.setTextSize(22f * sp);
            c.drawText(fit(route.summary(), w - dp(16)), dp(10), dp(40), text);
            text.setTextSize(15f * sp);
            c.drawText(fit("Tekan GPS atau mulai simulasi", w - dp(16)), dp(10), dp(70), text);
            text.setTextSize(14f * sp);
            return ph;
        }
        Maneuver m = nav.next;
        drawArrow(c, m.type, dp(48), ph / 2, dp(34));
        float tx = dp(100);
        text.setTextSize(34f * sp);
        String d = m.type == Maneuver.START ? "" : Maneuver.fmtDist(nav.distToNext);
        c.drawText(d, tx, dp(44), text);
        text.setTextSize(16f * sp);
        c.drawText(fit(m.text(), w - tx - dp(8)), tx, dp(78), text);
        text.setTextSize(14f * sp);
        return ph;
    }

    /** Draws a turn arrow of the given maneuver type centred at (x,y); r is the half size. */
    private void drawArrow(Canvas c, int type, float x, float y, float r) {
        line.setPathEffect(null);
        line.setColor(theme.barFg);
        line.setStrokeWidth(dp(6));
        if (type == Maneuver.ARRIVE) {
            c.drawLine(x - r / 2, y + r, x - r / 2, y - r, line);
            fill.setColor(theme.barFg);
            c.drawRect(x - r / 2, y - r, x + r, y, fill);
            return;
        }
        if (type == Maneuver.ROUNDABOUT) {
            line.setStrokeWidth(dp(5));
            c.drawCircle(x, y - r * 0.1f, r * 0.55f, line);
            c.drawLine(x, y + r, x, y + r * 0.45f, line);
            c.drawLine(x + r * 0.4f, y - r * 0.5f, x + r * 0.9f, y - r * 0.9f, line);
            return;
        }
        if (type == Maneuver.UTURN) {
            c.drawLine(x + r * 0.5f, y + r, x + r * 0.5f, y - r * 0.4f, line);
            c.drawLine(x + r * 0.5f, y - r * 0.4f, x - r * 0.5f, y - r * 0.4f, line);
            c.drawLine(x - r * 0.5f, y - r * 0.4f, x - r * 0.5f, y + r * 0.6f, line);
            c.drawLine(x - r * 0.5f, y + r, x - r * 0.9f, y + r * 0.45f, line);
            c.drawLine(x - r * 0.5f, y + r, x - r * 0.1f, y + r * 0.45f, line);
            return;
        }
        double ang;
        switch (type) {
            case Maneuver.SLIGHT_LEFT:
                ang = -45;
                break;
            case Maneuver.LEFT:
                ang = -90;
                break;
            case Maneuver.SHARP_LEFT:
                ang = -135;
                break;
            case Maneuver.SLIGHT_RIGHT:
                ang = 45;
                break;
            case Maneuver.RIGHT:
                ang = 90;
                break;
            case Maneuver.SHARP_RIGHT:
                ang = 135;
                break;
            default:
                ang = 0;
                break;
        }
        float jx = x, jy = y + r * 0.2f;           // bend point
        c.drawLine(x, y + r, jx, jy, line);        // stem from below
        double a = Math.toRadians(ang);
        float ex = jx + (float) Math.sin(a) * r * 1.2f, ey = jy - (float) Math.cos(a) * r * 1.2f;
        c.drawLine(jx, jy, ex, ey, line);
        // arrow head
        double h1 = a + Math.toRadians(150), h2 = a - Math.toRadians(150);
        float hl = r * 0.7f;
        c.drawLine(ex, ey, ex + (float) Math.sin(h1) * hl, ey - (float) Math.cos(h1) * hl, line);
        c.drawLine(ex, ey, ex + (float) Math.sin(h2) * hl, ey - (float) Math.cos(h2) * hl, line);
    }

    // ------------------------------------------------------------------ menu

    private float rowH() {
        return dp(60);
    }

    private float titleH() {
        return dp(56);
    }

    private void ensureMenuVisible() {
        int h = Math.max(getHeight(), (int) dp(400));
        float vis = h - titleH();
        float top = menuSel * rowH(), bot = top + rowH();
        if (top < menuScroll) menuScroll = top;
        if (bot > menuScroll + vis) menuScroll = bot - vis;
        clampScroll(h);
    }

    private void clampScroll(int h) {
        float max = Math.max(0, menuItems.length * rowH() - (h - titleH()));
        if (menuScroll > max) menuScroll = max;
        if (menuScroll < 0) menuScroll = 0;
    }

    private void drawMenu(Canvas c, int w, int h) {
        c.drawColor(theme.barBg);
        clampScroll(h);
        float th = titleH(), rh = rowH();
        line.setPathEffect(null);
        for (int i = 0; i < menuItems.length; i++) {
            float y = th + i * rh - menuScroll;
            if (y + rh < th || y > h) continue;
            Item it = menuItems[i];
            boolean sel = i == menuSel;
            if (sel) {
                fill.setColor(theme.barFg);
                c.drawRect(0, y, w, y + rh, fill);
            }
            text.setColor(sel ? theme.barBg : theme.barFg);
            text.setTextSize(18f * sp);
            float vw = it.value == null ? 0 : text.measureText(it.value);
            c.drawText(fit(it.label, w - vw - dp(30)), dp(12), y + rh / 2 + dp(6), text);
            if (it.value != null) c.drawText(it.value, w - vw - dp(12), y + rh / 2 + dp(6), text);
            line.setColor(theme.barFg);
            line.setStrokeWidth(dp(1));
            c.drawLine(0, y + rh, w, y + rh, line);
        }
        fill.setColor(theme.barBg);
        c.drawRect(0, 0, w, th, fill);
        line.setColor(theme.barFg);
        line.setStrokeWidth(dp(3));
        c.drawLine(0, th, w, th, line);
        text.setColor(theme.barFg);
        text.setTextSize(20f * sp);
        c.drawText(fit(menuTitle, w - dp(120)), dp(12), th / 2 + dp(7), text);
        closeBtn.set(w - dp(104), dp(6), w - dp(6), th - dp(6));
        c.drawRect(closeBtn, line);
        text.setTextSize(16f * sp);
        c.drawText("TUTUP", closeBtn.centerX() - text.measureText("TUTUP") / 2, closeBtn.centerY() + dp(6), text);
        text.setTextSize(14f * sp);
    }

    private void activate() {
        if (menuSel >= 0 && menuSel < menuItems.length && host != null) {
            Item it = menuItems[menuSel];
            host.onAction(it.act, it.arg);
        }
    }

    // ------------------------------------------------------------------ input

    private void pan(double dxPx, double dyPx) {
        double upp = unitsPerPx();
        cx = Math.max(0, Math.min(Geo.SPAN - 1, cx + dxPx * upp));
        cy = Math.max(0, Math.min(Geo.SPAN - 1, cy + dyPx * upp));
        followGps = false;
        info = "";
        invalidate();
    }

    private void zoomBy(int d) {
        int z = Math.max(minZoom, Math.min(maxZoom, zoom + d));
        if (z != zoom) {
            zoom = z;
            info = "";
            invalidate();
        }
    }

    private void press(int id) {
        if (id == Act.ZOOM_OUT) zoomBy(-1);
        else if (id == Act.ZOOM_IN) zoomBy(1);
        else if (host != null) host.onAction(id, 0);
    }

    /** Describes the nearest named object around the crosshair. */
    private void identify() {
        Loaded ld = loaded;
        info = "";
        if (ld == null || reader == null) {
            invalidate();
            return;
        }
        double bestD = 40 * density * unitsPerPx();
        bestD *= bestD;
        Feature best = null;
        for (Feature f : ld.feats) {
            if (f.name == null) continue;
            for (int i = 0; i < f.xy.length; i += 2) {
                double dx = f.xy[i] - cx, dy = f.xy[i + 1] - cy;
                double d = dx * dx + dy * dy;
                if (d < bestD) {
                    bestD = d;
                    best = f;
                }
            }
        }
        if (best != null) {
            info = best.name + ((best.flags & Style.F_TOLL) != 0 && Style.isRoad(best.cls) ? " [TOL]" : "");
        }
        invalidate();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent e) {
        if (menuOpen) {
            switch (keyCode) {
                case KeyEvent.KEYCODE_DPAD_UP:
                    if (menuItems.length > 0) menuSel = (menuSel + menuItems.length - 1) % menuItems.length;
                    ensureMenuVisible();
                    invalidate();
                    return true;
                case KeyEvent.KEYCODE_DPAD_DOWN:
                    if (menuItems.length > 0) menuSel = (menuSel + 1) % menuItems.length;
                    ensureMenuVisible();
                    invalidate();
                    return true;
                case KeyEvent.KEYCODE_DPAD_CENTER:
                case KeyEvent.KEYCODE_ENTER:
                case KeyEvent.KEYCODE_DPAD_RIGHT:
                    if (e.getRepeatCount() == 0) activate();
                    return true;
                case KeyEvent.KEYCODE_DPAD_LEFT:
                    if (host != null) host.onAction(Act.BACK, 0);
                    return true;
                case KeyEvent.KEYCODE_MENU:
                case KeyEvent.KEYCODE_M:
                    if (host != null) host.onAction(Act.MENU, 0);
                    return true;
                default:
                    return super.onKeyDown(keyCode, e);
            }
        }
        float step = Math.min(getWidth(), getHeight()) / 6f;
        if (e.getRepeatCount() > 8) step *= 3;
        switch (keyCode) {
            case KeyEvent.KEYCODE_DPAD_LEFT:
                pan(-step, 0);
                return true;
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                pan(step, 0);
                return true;
            case KeyEvent.KEYCODE_DPAD_UP:
                pan(0, -step);
                return true;
            case KeyEvent.KEYCODE_DPAD_DOWN:
                pan(0, step);
                return true;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
                if (e.getRepeatCount() == 0) identify();
                return true;
            case KeyEvent.KEYCODE_PLUS:
            case KeyEvent.KEYCODE_EQUALS:
            case KeyEvent.KEYCODE_NUMPAD_ADD:
            case KeyEvent.KEYCODE_PAGE_UP:
            case KeyEvent.KEYCODE_VOLUME_UP:
                if (e.getRepeatCount() == 0) zoomBy(1);
                return true;
            case KeyEvent.KEYCODE_MINUS:
            case KeyEvent.KEYCODE_NUMPAD_SUBTRACT:
            case KeyEvent.KEYCODE_PAGE_DOWN:
            case KeyEvent.KEYCODE_VOLUME_DOWN:
                if (e.getRepeatCount() == 0) zoomBy(-1);
                return true;
            case KeyEvent.KEYCODE_MENU:
            case KeyEvent.KEYCODE_M:
                press(Act.MENU);
                return true;
            case KeyEvent.KEYCODE_G:
                press(Act.GPS);
                return true;
            case KeyEvent.KEYCODE_T:
                press(Act.GOTO);
                return true;
            case KeyEvent.KEYCODE_N:
                showNames = !showNames;
                invalidate();
                return true;
            default:
                return super.onKeyDown(keyCode, e);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int act = e.getActionMasked();
        if (menuOpen) return menuTouch(e, act);
        if (act == MotionEvent.ACTION_POINTER_DOWN && e.getPointerCount() == 2) {
            pinching = true;
            pinchStart = Math.hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1));
            pinchZoom = zoom;
            return true;
        }
        if (pinching) {
            if (act == MotionEvent.ACTION_MOVE && e.getPointerCount() >= 2 && pinchStart > 0) {
                double d = Math.hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1));
                int z = pinchZoom + (int) Math.round(Math.log(d / pinchStart) / Math.log(2.0));
                z = Math.max(minZoom, Math.min(maxZoom, z));
                if (z != zoom) {
                    zoom = z;
                    invalidate();
                }
            } else if (act == MotionEvent.ACTION_UP || act == MotionEvent.ACTION_CANCEL) {
                pinching = false;
                dragged = true;
            }
            return true;
        }
        switch (act) {
            case MotionEvent.ACTION_DOWN:
                downX = lastX = e.getX();
                downY = lastY = e.getY();
                dragged = false;
                return true;
            case MotionEvent.ACTION_MOVE: {
                float dx = e.getX() - lastX, dy = e.getY() - lastY;
                if (!dragged && Math.hypot(e.getX() - downX, e.getY() - downY) > dp(10)) dragged = true;
                if (dragged) pan(-dx, -dy);
                lastX = e.getX();
                lastY = e.getY();
                return true;
            }
            case MotionEvent.ACTION_UP:
                if (!dragged) {
                    for (Button b : buttons) {
                        if (b.r.contains(e.getX(), e.getY())) {
                            press(b.id);
                            return true;
                        }
                    }
                    if (e.getY() > getHeight() - barH() - dp(40)) return true; // info strip
                    double upp = unitsPerPx();
                    cx += (e.getX() - getWidth() / 2f) * upp;
                    cy += (e.getY() - getHeight() / 2f) * upp;
                    followGps = false;
                    identify();
                }
                return true;
            default:
                return true;
        }
    }

    private boolean menuTouch(MotionEvent e, int act) {
        switch (act) {
            case MotionEvent.ACTION_DOWN:
                downX = lastX = e.getX();
                downY = lastY = e.getY();
                dragged = false;
                return true;
            case MotionEvent.ACTION_MOVE: {
                float dy = e.getY() - lastY;
                if (!dragged && Math.abs(e.getY() - downY) > dp(10)) dragged = true;
                if (dragged) {
                    menuScroll -= dy;
                    clampScroll(getHeight());
                    invalidate();
                }
                lastY = e.getY();
                return true;
            }
            case MotionEvent.ACTION_UP:
                if (!dragged) {
                    if (closeBtn.contains(e.getX(), e.getY()) || e.getY() < titleH()) {
                        if (closeBtn.contains(e.getX(), e.getY()) && host != null) host.onAction(Act.BACK, 0);
                        return true;
                    }
                    int i = (int) ((e.getY() - titleH() + menuScroll) / rowH());
                    if (i >= 0 && i < menuItems.length) {
                        menuSel = i;
                        invalidate();
                        activate();
                    }
                }
                return true;
            default:
                return true;
        }
    }
}
