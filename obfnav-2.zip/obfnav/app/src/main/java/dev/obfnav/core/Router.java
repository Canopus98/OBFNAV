package dev.obfnav.core;

import java.io.IOException;
import java.util.Arrays;

/**
 * A* route finder over the road ways of a {@link RoadSource}.
 *
 * <p>The graph is built lazily: roads are loaded tile by tile (about 5 km wide) only when the search
 * reaches them, so a route across a province does not need the whole province in memory. Junctions are
 * points shared by several ways; one-way, toll and access tags are applied while edges are created, so the
 * search itself is plain A*. A router instance is tied to one {@link RouteOptions}; create a new one when
 * the options change. Turn restrictions are not part of the map section and are therefore not honoured.
 */
public final class Router {

    public static final class RouteException extends IOException {
        public RouteException(String message) {
            super(message);
        }
    }

    private static final int TILE_SHIFT = 18; // 2^18 units = one zoom-13 tile (about 5 km at the equator)
    private static final int MAX_EXPANSIONS = 3000000;
    private static final int RESET_NODES = 1500000;

    private final RoadSource src;
    private final RouteOptions opt;
    private volatile boolean cancelled;

    // ---- nodes
    private LongIntMap nodeMap;
    private int nodes;
    private int[] nx, ny, head, rHead, prevNode, prevWay, seen, closed;
    private double[] g;
    private byte[] deg;
    // ---- edges
    private int edges;
    private int[] eTo, eNext, eWay, eFrom, rNext;
    private float[] eLen;
    // ---- ways (one per accepted road)
    private int ways;
    private String[] wName;
    private int[] wFlags;
    private float[] wSpeed, wPen;
    private LongIntMap roadWay;
    private LongSet tiles;
    private int searchId;

    // ---- open set
    private int[] heapN = new int[1 << 14];
    private double[] heapF = new double[1 << 14];
    private int heapSize;

    public Router(RoadSource src, RouteOptions opt) {
        this.src = src;
        this.opt = opt;
        reset();
    }

    public RouteOptions options() {
        return opt;
    }

    public void cancel() {
        cancelled = true;
    }

    private void reset() {
        nodeMap = new LongIntMap(1 << 16);
        nodes = 0;
        int c = 1 << 16;
        nx = new int[c];
        ny = new int[c];
        head = new int[c];
        rHead = new int[c];
        prevNode = new int[c];
        prevWay = new int[c];
        seen = new int[c];
        closed = new int[c];
        g = new double[c];
        deg = new byte[c];
        edges = 0;
        eTo = new int[c];
        eNext = new int[c];
        eWay = new int[c];
        eFrom = new int[c];
        rNext = new int[c];
        eLen = new float[c];
        ways = 0;
        wName = new String[1 << 14];
        wFlags = new int[1 << 14];
        wSpeed = new float[1 << 14];
        wPen = new float[1 << 14];
        roadWay = new LongIntMap(1 << 14);
        tiles = new LongSet();
    }

    // ------------------------------------------------------------------ graph building

    private int newNode(int x, int y) {
        if (nodes == nx.length) {
            int c = nodes * 2;
            nx = Arrays.copyOf(nx, c);
            ny = Arrays.copyOf(ny, c);
            head = Arrays.copyOf(head, c);
            rHead = Arrays.copyOf(rHead, c);
            prevNode = Arrays.copyOf(prevNode, c);
            prevWay = Arrays.copyOf(prevWay, c);
            seen = Arrays.copyOf(seen, c);
            closed = Arrays.copyOf(closed, c);
            g = Arrays.copyOf(g, c);
            deg = Arrays.copyOf(deg, c);
        }
        int id = nodes++;
        nx[id] = x;
        ny[id] = y;
        head[id] = -1;
        rHead[id] = -1;
        prevNode[id] = -1;
        prevWay[id] = -1;
        seen[id] = 0;
        closed[id] = 0;
        deg[id] = 0;
        return id;
    }

    private int node(int x, int y) {
        long key = ((long) (x & 0x7FFFFFFF) << 31) | (y & 0x7FFFFFFFL);
        int id = nodeMap.get(key, -1);
        if (id < 0) {
            id = newNode(x, y);
            nodeMap.put(key, id);
        }
        return id;
    }

    private void addEdge(int a, int b, int way, float len) {
        if (edges == eTo.length) {
            int c = edges * 2;
            eTo = Arrays.copyOf(eTo, c);
            eNext = Arrays.copyOf(eNext, c);
            eWay = Arrays.copyOf(eWay, c);
            eFrom = Arrays.copyOf(eFrom, c);
            rNext = Arrays.copyOf(rNext, c);
            eLen = Arrays.copyOf(eLen, c);
        }
        eTo[edges] = b;
        eWay[edges] = way;
        eLen[edges] = len;
        eFrom[edges] = a;
        eNext[edges] = head[a];
        rNext[edges] = rHead[b];
        head[a] = edges;
        rHead[b] = edges;
        edges++;
    }

    private int newWay(RoadSource.Road r, int flags) {
        if (ways == wName.length) {
            int c = ways * 2;
            wName = Arrays.copyOf(wName, c);
            wFlags = Arrays.copyOf(wFlags, c);
            wSpeed = Arrays.copyOf(wSpeed, c);
            wPen = Arrays.copyOf(wPen, c);
        }
        int w = ways++;
        wName[w] = r.name != null && r.name.length() > 0 ? r.name : r.ref;
        wFlags[w] = flags;
        wSpeed[w] = (float) opt.speed(r.cls, flags);
        wPen[w] = (flags & Style.F_LOWSPEED) != 0 ? 3f : 1f;
        return w;
    }

    private static long roadKey(RoadSource.Road r) {
        long k = r.id * 31 + r.xy.length;
        k = k * 1000003L + r.xy[0];
        k = k * 1000003L + r.xy[1];
        return k & Long.MAX_VALUE;
    }

    /** Adds a road to the graph (once). @return its way index, or -1 if this vehicle may not use it. */
    private int addRoad(RoadSource.Road r) {
        long key = roadKey(r);
        int existing = roadWay.get(key, -2);
        if (existing != -2) return existing;
        int[] xy = r.xy;
        int flags = r.flags;
        int n = xy.length / 2;
        if ((flags & Style.F_ONEWAY) != 0 && (flags & Style.F_ROUNDABOUT) == 0 && r.cls != Style.MOTORWAY
                && n >= 4 && xy[0] == xy[2 * n - 2] && xy[1] == xy[2 * n - 1]) {
            double per = 0;
            for (int i = 0; i + 3 < xy.length; i += 2) per += Geo.dist(xy[i], xy[i + 1], xy[i + 2], xy[i + 3]);
            if (per <= 500) flags |= Style.F_ROUNDABOUT; // small closed one-way loop: a roundabout
        }
        boolean ok = opt.allowed(r);
        int w = ok ? newWay(r, flags) : -1;
        roadWay.put(key, w);
        boolean fwd = (flags & Style.F_REVERSE) == 0;
        boolean bwd = (flags & Style.F_ONEWAY) == 0;
        for (int i = 0; i + 3 < xy.length; i += 2) {
            int a = node(xy[i], xy[i + 1]);
            int b = node(xy[i + 2], xy[i + 3]);
            if (a == b) continue;
            if (deg[a] < 100) deg[a]++;
            if (deg[b] < 100) deg[b]++;
            if (!ok) continue;
            float len = (float) Geo.dist(xy[i], xy[i + 1], xy[i + 2], xy[i + 3]);
            if (fwd) addEdge(a, b, w, len);
            if (bwd) addEdge(b, a, w, len);
        }
        return w;
    }

    private void ensureTile(int x, int y) throws IOException {
        int tx = x >> TILE_SHIFT, ty = y >> TILE_SHIFT;
        long key = ((long) tx << 32) | (ty & 0xFFFFFFFFL);
        if (!tiles.add(key)) return;
        int l = tx << TILE_SHIFT, t = ty << TILE_SHIFT;
        src.roads(l, l + (1 << TILE_SHIFT) - 1, t, t + (1 << TILE_SHIFT) - 1, new RoadSource.Sink() {
            @Override
            public void road(RoadSource.Road r) {
                addRoad(r);
            }
        });
    }

    // ------------------------------------------------------------------ snapping

    /** Extra "distance" (meters) charged for snapping a destination onto a motorway/toll road. */
    private static final double TOLL_SNAP_PENALTY = 1500;
    /** A road piece must reach at least this many nodes to count as part of the real network. */
    private static final int CONNECTED_NODES = 1500;
    private static final int MAX_CANDIDATES = 6;

    private static final class Snap {
        int a, b, way;
        double px, py, t, dist, score;
        boolean fwd, bwd, penalized;
    }

    /**
     * Collects the nearest usable road segments (one per road), best first. With {@code preferOrdinary}
     * (used for destinations) motorway and toll roads only win if no ordinary road is within about 3 km: a
     * destination is practically never on a toll road, and one next to a toll road is usually reached from
     * the ordinary road beside it.
     */
    private java.util.List<Snap> snapCandidates(final double x, final double y, final boolean preferOrdinary)
            throws IOException {
        final java.util.HashMap<Integer, Snap> byWay = new java.util.HashMap<Integer, Snap>();
        double[] radii = {300, 1500, 3000};
        for (double meters : radii) {
            double u = Geo.unitsFromMeters(meters, y);
            int l = (int) Math.max(0, x - u), r = (int) Math.min(Integer.MAX_VALUE, x + u);
            int t = (int) Math.max(0, y - u), b = (int) Math.min(Integer.MAX_VALUE, y + u);
            src.roads(l, r, t, b, new RoadSource.Sink() {
                @Override
                public void road(RoadSource.Road road) {
                    int w = addRoad(road);
                    if (w < 0) return;
                    int fl = wFlags[w];
                    boolean fwd = (fl & Style.F_REVERSE) == 0, bwd = (fl & Style.F_ONEWAY) == 0;
                    if (!fwd && !bwd) return;
                    boolean penal = preferOrdinary && (road.cls == Style.MOTORWAY || (fl & Style.F_TOLL) != 0);
                    int[] xy = road.xy;
                    for (int i = 0; i + 3 < xy.length; i += 2) {
                        double ax = xy[i], ay = xy[i + 1], bx = xy[i + 2], by = xy[i + 3];
                        double dx = bx - ax, dy = by - ay;
                        double len2 = dx * dx + dy * dy;
                        double tt = len2 == 0 ? 0 : ((x - ax) * dx + (y - ay) * dy) / len2;
                        if (tt < 0) tt = 0;
                        else if (tt > 1) tt = 1;
                        double px = ax + tt * dx, py = ay + tt * dy;
                        double d = Geo.dist(x, y, px, py);
                        double score = d + (penal ? TOLL_SNAP_PENALTY : 0);
                        Snap old = byWay.get(w);
                        if (old != null && old.score <= score) continue;
                        Snap s = new Snap();
                        s.a = node(xy[i], xy[i + 1]);
                        s.b = node(xy[i + 2], xy[i + 3]);
                        if (s.a == s.b) continue;
                        s.way = w;
                        s.px = px;
                        s.py = py;
                        s.t = tt;
                        s.dist = d;
                        s.score = score;
                        s.fwd = fwd;
                        s.bwd = bwd;
                        s.penalized = penal;
                        byWay.put(w, s);
                    }
                }
            });
            int good = 0;
            for (Snap s : byWay.values()) if (!s.penalized && s.dist <= meters) good++;
            if (good >= MAX_CANDIDATES) break;
        }
        java.util.ArrayList<Snap> list = new java.util.ArrayList<Snap>();
        for (Snap s : byWay.values()) if (s.dist <= 3000) list.add(s);
        java.util.Collections.sort(list, new java.util.Comparator<Snap>() {
            @Override
            public int compare(Snap p, Snap q) {
                return p.score < q.score ? -1 : (p.score > q.score ? 1 : 0);
            }
        });
        return list.size() > MAX_CANDIDATES ? new java.util.ArrayList<Snap>(list.subList(0, MAX_CANDIDATES)) : list;
    }

    /**
     * Picks the best candidate that belongs to the real road network, not to a tiny isolated piece.
     * A start must be able to LEAVE into the network, a destination must be possible to REACH from it.
     */
    private Snap pickConnected(java.util.List<Snap> cands, boolean destination) throws IOException {
        for (Snap s : cands) {
            boolean ok;
            if (destination) {
                // arriving happens through a (if driving a->b) or b (if driving b->a): walk the graph backwards
                ok = (s.fwd && reachesManyNodes(s.a, true)) || (s.bwd && reachesManyNodes(s.b, true));
            } else {
                ok = (s.fwd && reachesManyNodes(s.b, false)) || (s.bwd && reachesManyNodes(s.a, false));
            }
            if (ok) return s;
        }
        return cands.isEmpty() ? null : cands.get(0);
    }

    /** Breadth-first walk from a node (forwards, or backwards along edges); true once it covers many nodes. */
    private boolean reachesManyNodes(int from, boolean reverse) throws IOException {
        searchId++;
        int sid = searchId;
        int[] queue = new int[CONNECTED_NODES + 4];
        int qh = 0, tail = 0;
        closed[from] = sid;
        queue[tail++] = from;
        while (qh < tail) {
            int u = queue[qh++];
            ensureTile(nx[u], ny[u]);
            if (reverse) {
                for (int e = rHead[u]; e >= 0; e = rNext[e]) {
                    int v = eFrom[e];
                    if (closed[v] == sid) continue;
                    closed[v] = sid;
                    queue[tail++] = v;
                    if (tail >= CONNECTED_NODES) return true;
                }
            } else {
                for (int e = head[u]; e >= 0; e = eNext[e]) {
                    int v = eTo[e];
                    if (closed[v] == sid) continue;
                    closed[v] = sid;
                    queue[tail++] = v;
                    if (tail >= CONNECTED_NODES) return true;
                }
            }
        }
        return false;
    }

    // ------------------------------------------------------------------ open set

    private void push(int n, double f) {
        if (heapSize == heapN.length) {
            heapN = Arrays.copyOf(heapN, heapSize * 2);
            heapF = Arrays.copyOf(heapF, heapSize * 2);
        }
        int i = heapSize++;
        while (i > 0) {
            int p = (i - 1) >> 1;
            if (heapF[p] <= f) break;
            heapN[i] = heapN[p];
            heapF[i] = heapF[p];
            i = p;
        }
        heapN[i] = n;
        heapF[i] = f;
    }

    private int pop() {
        int top = heapN[0];
        heapSize--;
        if (heapSize > 0) {
            int n = heapN[heapSize];
            double f = heapF[heapSize];
            int i = 0;
            while (true) {
                int c = 2 * i + 1;
                if (c >= heapSize) break;
                if (c + 1 < heapSize && heapF[c + 1] < heapF[c]) c++;
                if (heapF[c] >= f) break;
                heapN[i] = heapN[c];
                heapF[i] = heapF[c];
                i = c;
            }
            heapN[i] = n;
            heapF[i] = f;
        }
        return top;
    }

    // ------------------------------------------------------------------ search

    private double cost(int way, double len) {
        return opt.shortest ? len * wPen[way] : len / wSpeed[way];
    }

    private double heuristic(int n, double dx, double dy, double mpu) {
        double ex = nx[n] - dx, ey = ny[n] - dy;
        double m = Math.sqrt(ex * ex + ey * ey) * mpu * 0.99;
        return opt.shortest ? m : m / opt.maxSpeed();
    }

    private void relax(int u, int v, int way, double len, double dx, double dy, double mpu) {
        if (closed[v] == searchId) return;
        double ng = g[u] + cost(way, len);
        if (seen[v] != searchId || ng < g[v]) {
            seen[v] = searchId;
            g[v] = ng;
            prevNode[v] = u;
            prevWay[v] = way;
            push(v, ng + heuristic(v, dx, dy, mpu));
        }
    }

    /** Finds a route between two WGS84 points. Throws {@link RouteException} with a user-readable reason. */
    public synchronized Route route(double lat1, double lon1, double lat2, double lon2) throws IOException {
        cancelled = false;
        if (nodes > RESET_NODES) reset();
        double x1 = Geo.lonToX(lon1), y1 = Geo.latToY(lat1);
        double x2 = Geo.lonToX(lon2), y2 = Geo.latToY(lat2);
        String noToll = opt.avoidToll || opt.motorcycle ? " (jalan tol tidak dipakai)" : "";
        Snap s = pickConnected(snapCandidates(x1, y1, false), false);
        if (s == null) throw new RouteException("Titik awal terlalu jauh dari jalan yang bisa dilalui" + noToll);
        Snap d = pickConnected(snapCandidates(x2, y2, true), true);
        if (d == null) throw new RouteException("Tujuan terlalu jauh dari jalan yang bisa dilalui" + noToll);

        searchId++;
        int S = newNode((int) Math.round(s.px), (int) Math.round(s.py));
        int D = newNode((int) Math.round(d.px), (int) Math.round(d.py));
        seen[S] = searchId;
        g[S] = 0;
        heapSize = 0;
        double dx = nx[D], dy = ny[D];
        double mpu = Geo.metersPerUnit(dy);

        // leave the start point along the snapped segment (a -> b is the drawing direction)
        if (s.fwd) {
            double len = Geo.dist(nx[S], ny[S], nx[s.b], ny[s.b]);
            relax(S, s.b, s.way, len, dx, dy, mpu);
        }
        if (s.bwd) {
            double len = Geo.dist(nx[S], ny[S], nx[s.a], ny[s.a]);
            relax(S, s.a, s.way, len, dx, dy, mpu);
        }
        // start and destination on the same segment: drive directly
        if (s.a == d.a && s.b == d.b && s.way == d.way) {
            double len = Geo.dist(nx[S], ny[S], nx[D], ny[D]);
            if ((d.t >= s.t && s.fwd) || (d.t <= s.t && s.bwd)) relax(S, D, s.way, len, dx, dy, mpu);
        }

        int expansions = 0;
        boolean found = false;
        while (heapSize > 0) {
            int u = pop();
            if (closed[u] == searchId) continue;
            closed[u] = searchId;
            if (u == D) {
                found = true;
                break;
            }
            if (++expansions > MAX_EXPANSIONS) throw new RouteException("Rute terlalu jauh untuk dihitung di perangkat ini");
            if ((expansions & 1023) == 0 && cancelled) throw new RouteException("Dibatalkan");
            if (u != S) ensureTile(nx[u], ny[u]);
            for (int e = head[u]; e >= 0; e = eNext[e]) relax(u, eTo[e], eWay[e], eLen[e], dx, dy, mpu);
            // entering the destination segment from either of its ends
            if (u == d.a && d.fwd) {
                relax(u, D, d.way, Geo.dist(nx[u], ny[u], nx[D], ny[D]), dx, dy, mpu);
            }
            if (u == d.b && d.bwd) {
                relax(u, D, d.way, Geo.dist(nx[u], ny[u], nx[D], ny[D]), dx, dy, mpu);
            }
        }
        if (!found) {
            throw new RouteException(opt.avoidToll || opt.motorcycle
                    ? "Tidak ada rute tanpa jalan tol ke tujuan ini" : "Tidak ada rute ke tujuan ini");
        }
        return build(S, D);
    }

    private Route build(int S, int D) {
        int cnt = 0;
        for (int v = D; v != -1; v = prevNode[v]) cnt++;
        int[] path = new int[cnt];
        int k = cnt - 1;
        for (int v = D; v != -1; v = prevNode[v]) path[k--] = v;

        int[] x = new int[cnt], y = new int[cnt], dg = new int[cnt];
        double[] cd = new double[cnt], ct = new double[cnt];
        String[] legName = new String[Math.max(1, cnt - 1)];
        boolean[] legRound = new boolean[Math.max(1, cnt - 1)];
        boolean toll = false;
        for (int i = 0; i < cnt; i++) {
            int n = path[i];
            x[i] = nx[n];
            y[i] = ny[n];
            dg[i] = n == S || n == D ? 0 : deg[n];
            if (i > 0) {
                int w = prevWay[n];
                double len = Geo.dist(x[i - 1], y[i - 1], x[i], y[i]);
                cd[i] = cd[i - 1] + len;
                ct[i] = ct[i - 1] + len / wSpeed[w];
                legName[i - 1] = wName[w];
                legRound[i - 1] = (wFlags[w] & Style.F_ROUNDABOUT) != 0;
                if ((wFlags[w] & Style.F_TOLL) != 0) toll = true;
            }
        }
        Route r = new Route();
        r.x = x;
        r.y = y;
        r.cumDist = cd;
        r.cumTime = ct;
        r.totalDist = cd[cnt - 1];
        r.totalTime = ct[cnt - 1];
        r.usesToll = toll;
        r.options = opt;
        r.maneuvers = Guidance.build(x, y, dg, legName, legRound, cd);
        return r;
    }
}
