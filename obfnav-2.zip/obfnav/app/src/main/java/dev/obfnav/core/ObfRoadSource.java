package dev.obfnav.core;

import java.io.IOException;
import java.util.List;

/** {@link RoadSource} backed by the MAP section of an OBF file (the most detailed zoom level). */
public final class ObfRoadSource implements RoadSource {
    private final ObfReader reader;
    private final Style.Rules[] rules;
    private final int[] zoom;

    public ObfRoadSource(ObfReader reader) {
        this.reader = reader;
        List<ObfReader.MapIndex> maps = reader.getMaps();
        rules = new Style.Rules[maps.size()];
        zoom = new int[maps.size()];
        for (int i = 0; i < rules.length; i++) {
            ObfReader.MapIndex mi = maps.get(i);
            rules[i] = Style.buildRules(mi);
            // the level with the highest minZoom holds the full-detail geometry
            int z = 0;
            int best = -1;
            for (ObfReader.Level lv : mi.levels) {
                if (lv.minZoom > best) {
                    best = lv.minZoom;
                    z = lv.minZoom;
                }
            }
            zoom[i] = z;
        }
    }

    @Override
    public void roads(int left, int right, int top, int bottom, final Sink sink) throws IOException {
        List<ObfReader.MapIndex> maps = reader.getMaps();
        for (int i = 0; i < maps.size(); i++) {
            final Style.Rules rl = rules[i];
            ObfReader.MapIndex mi = maps.get(i);
            ObfReader.TypeFilter filter = new ObfReader.TypeFilter() {
                @Override
                public boolean accept(ObfReader.MapIndex map, int[] types) {
                    for (int t : types) {
                        if (t >= 0 && t < rl.cls.length && Style.isDrivable(rl.cls[t])) return true;
                    }
                    return false;
                }
            };
            reader.search(mi, left, right, top, bottom, zoom[i], filter, new ObfReader.FeatureSink() {
                @Override
                public boolean accept(ObfReader.MapIndex map, Feature f) {
                    if (f.area || f.xy.length < 4) return true;
                    int cls = Style.classOf(rl, f.types);
                    if (!Style.isDrivable(cls)) return true;
                    Road r = new Road();
                    r.xy = f.xy;
                    r.id = f.id;
                    r.name = f.name;
                    r.ref = f.ref;
                    r.cls = cls;
                    r.flags = Style.flagsOf(rl, f.types);
                    if ((r.flags & Style.F_TOLL) == 0 && Style.tollByName(f.name)) r.flags |= Style.F_TOLL;
                    r.noCar = Style.accessBlocked(rl, f.types, false);
                    r.noMoto = Style.accessBlocked(rl, f.types, true);
                    sink.road(r);
                    return true;
                }
            });
        }
    }
}
