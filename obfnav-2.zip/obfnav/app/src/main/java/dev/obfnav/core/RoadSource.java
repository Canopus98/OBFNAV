package dev.obfnav.core;

import java.io.IOException;

/** Supplies drivable roads inside a rectangle (31-bit coordinates). Implemented over OBF files and by tests. */
public interface RoadSource {

    /** One drivable way. */
    final class Road {
        /** x0,y0,x1,y1,... in 31-bit Mercator units. */
        public int[] xy;
        public long id;
        public String name;
        public String ref;
        /** {@link Style} drivable class (TRACK..MOTORWAY). */
        public int cls;
        /** {@link Style} F_* flags. */
        public int flags;
        public boolean noCar;
        public boolean noMoto;
    }

    interface Sink {
        void road(Road r);
    }

    /** Streams every drivable road whose bounding box touches the rectangle. May stream a road more than once. */
    void roads(int left, int right, int top, int bottom, Sink sink) throws IOException;
}
