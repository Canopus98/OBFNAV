# OBFNav

Penampil peta offline yang sangat ringan untuk file **.obf** (format peta OsmAnd). Tanpa internet, tanpa library
pihak ketiga (hanya framework Android), tanpa animasi. Peta digambar sebagai garis vektor monokrom, dikendalikan lewat
D-pad/keyboard atau layar sentuh.

## Fitur

- Membuka file `.obf` (memory-mapped; file besar tidak dimuat ke RAM).
- Warna ala perangkat GPS jadul, palet kecil dan kontras tinggi: tanah hijau muda, hutan/kebun hijau, area kota krem,
  **air biru**, bangunan abu-abu, jalan hitam, **jalan tol merah tua**, rute magenta. Ada tema malam.
- Tombol bawah besar (tinggi 64 dp, teks 20-34 sp): `-` `+` `GPS` `TUJU/BATAL` `MENU`. Cubit dua jari juga zoom.
- **Navigasi** mobil dan sepeda motor (motor tidak boleh masuk tol). Pilihan **hindari tol** dan rute
  **tercepat / terpendek**. Rute dihitung offline langsung dari peta (A*), dihitung ulang otomatis kalau keluar jalur.
- **Peringatan tikungan**: panel atas menampilkan panah, jarak ke tikungan berikutnya dan arah ("Belok kiri ke Jalan X"),
  plus suara bahasa Indonesia (mobil: 500/200/60 m, motor: 300/120/40 m). Bundaran: "ambil jalan keluar ke-N".
- Info sisa jarak, sisa waktu, jam tiba (ETA), kecepatan.
- **Waypoint**: simpan dari kursor atau GPS, daftar, pindah ke sana, tuju, jadikan titik awal, hapus.
- **Simulasi berkendara** (MENU) untuk mencoba rute tanpa keluar rumah (40/80/160 km/j).
- Semua pengaturan, waypoint, posisi dan zoom terakhir diingat.

## Cara memakai navigasi

1. MENU > BUKA PETA, pilih file `.obf`.
2. Geser peta / ketuk sampai crosshair di tujuan, tekan `TUJU`. Titik awal = posisi GPS; kalau GPS mati, pakai
   MENU > MULAI DARI KURSOR terlebih dulu.
3. MENU untuk ganti kendaraan, hindari tol, tercepat/terpendek (rute langsung dihitung ulang).
4. `BATAL` membatalkan rute.

## Asumsi dan batasan (jujur)

- Di Indonesia semua `highway=motorway` dianggap jalan tol (kebanyakan tidak bertag `toll=yes`); jalan bernama
  "Jalan Tol ..." juga dianggap tol. Kalau file punya tag `toll=yes`/`toll=no`, tag itu dihormati.
- Larangan belok (turn restriction) **tidak** dipakai, karena tidak ada di section MAP; section routing OsmAnd tidak dipakai.
  Rute bisa menyuruh belok yang di dunia nyata dilarang. Selalu ikuti rambu.
- Deteksi bundaran bersifat heuristik; ganti nama jalan tanpa persimpangan tidak diberi instruksi.
- Rute sangat jauh (ratusan km) bisa ditolak karena batas memori perangkat.
- Lubang poligon tidak digambar; laut (di luar garis pantai) tidak diwarnai. File di atas 2 GB belum didukung.
- Nama waypoint otomatis ("WPT 001"), belum bisa diganti nama.
- Zoom maksimum 19.

## Kontrol keyboard / D-pad

| Tombol | Fungsi |
|---|---|
| D-pad / panah | geser peta (tahan = makin cepat); di menu: atas/bawah pilih, tengah/kanan jalankan, kiri kembali |
| `+` / `-`, Page Up/Down, Volume | zoom |
| D-pad tengah / Enter | sebut objek bernama terdekat dari crosshair |
| `M` atau Menu | buka/tutup menu |
| `T` | tuju ke crosshair / batalkan rute |
| `G` | GPS: nyala + ikuti, lalu ikuti saja, lalu mati |
| `N` | nama tampil/sembunyi |

## Mendapatkan peta

Unduh peta `.obf` dari OsmAnd (osmand.net, menu unduhan peta) atau salin dari ponsel yang sudah memakai OsmAnd.
Android 11+ tidak mengizinkan memilih file di `Android/data/...`, jadi **salin file .obf ke folder Download** dulu,
lalu pilih dari sana lewat MENU > BUKA PETA.

## Membangun APK lewat GitHub (tanpa Android Studio)

1. Buat repository baru di GitHub (boleh private).
2. Unggah **seluruh isi folder ini**. Pastikan folder tersembunyi `.github/workflows/build.yml` ikut terunggah.
   Cara paling aman: pakai `git` (`git init`, `git add -A`, `git commit`, `git push`) atau GitHub Desktop.
   Kalau memakai unggah lewat web dan `.github` tidak ikut, buat manual: *Add file → Create new file*, ketik nama
   `.github/workflows/build.yml`, lalu tempel isi file itu.
3. Buka tab **Actions** → workflow **Build APK** (jalan otomatis setiap push, atau tekan *Run workflow*).
4. Setelah hijau, buka run-nya, unduh artifact **obfnav-debug-apk** (zip berisi `app-debug.apk`).
5. Pasang di ponsel (izinkan "pasang dari sumber tidak dikenal").

Workflow juga menjalankan uji reader dan router (SelfTest, RouterTest, NavSessionTest) sebelum membangun APK. Kalau uji itu gagal, build berhenti.

Membangun sendiri: di komputer dengan JDK 17 + Android SDK, jalankan `gradle assembleDebug` (Gradle 8.9)
atau buka folder ini di Android Studio. Hasilnya `app/build/outputs/apk/debug/app-debug.apk`.

## Memeriksa file .obf nyata di PC (disarankan sebelum menyalahkan aplikasi)

Reader ini diuji dengan file sintetis dan dengan satu file .obf asli (peta kecil sekitar Karawang/Cikampek, Jawa Barat:
header, level zoom, kueri objek, dan koordinat nama kota cocok dengan lokasi sebenarnya). Peta lain, terutama yang jauh
lebih besar atau dari versi OsmAnd berbeda, belum diuji. Untuk memastikan file Anda terbaca benar:

```
mkdir out
javac -d out $(find app/src/main/java/dev/obfnav/core tools -name '*.java')
java -cp out dev.obfnav.tools.SelfTest
java -cp out dev.obfnav.tools.RouterTest
java -cp out dev.obfnav.tools.NavSessionTest
java -cp out dev.obfnav.tools.RouteDump peta.obf LAT1 LON1 LAT2 LON2 [car|moto] [notoll] [short]   # uji rute di PC
java -cp out dev.obfnav.tools.ObfDump peta.obf                      # header, level zoom, jumlah aturan
java -cp out dev.obfnav.tools.ObfDump peta.obf -6.2088 106.8456 15  # objek di sekitar satu titik
```

Kalau `ObfDump` gagal atau hasilnya janggal pada file asli, kirimkan keluarannya; itu petunjuk paling cepat untuk
memperbaiki reader.

## Struktur

```
app/src/main/java/dev/obfnav/core/   reader OBF (Java murni, tanpa dependensi Android)
    ObfReader.java    parser section MAP: aturan, level zoom, R-tree box, blok data, koordinat delta
    Style.java        tabel kecil tag OSM -> kelas gambar + zoom minimum
    Geo.java          lat/lon <-> koordinat Mercator 31-bit
    Router/Guidance/NavSession/Waypoints   routing A*, instruksi belok, pelacak rute, waypoint
app/src/main/java/dev/obfnav/        UI: MainActivity (file, GPS, rute, suara), MapView (render, panel, menu), Theme
tools/                               uji mandiri dan alat ObfDump (tidak ikut APK)
.github/workflows/build.yml          build APK di GitHub Actions
```

Cara kerja singkat: pada saat menggambar, viewport diubah menjadi kotak koordinat 31-bit. Reader menelusuri R-tree
di file, hanya membaca blok yang beririsan dengan kotak itu, lalu hasilnya disimpan sebagai array `int`. Area 1,5x
viewport dimuat sekaligus di thread terpisah supaya geser kecil tidak memicu pembacaan ulang. Layar hanya digambar ulang
saat ada input atau data baru.

## Catatan lisensi

Format .obf didefinisikan oleh OsmAnd (GPLv3). Reader di sini ditulis ulang dari awal, bukan disalin, tetapi nomor
field dan aturan decoding mengikuti kode OsmAnd (`BinaryMapIndexReader`) sebagai acuan. Jika Anda berencana
mendistribusikan aplikasi ini, pertimbangkan merilisnya dengan GPLv3 agar aman, atau minta nasihat hukum.
Data peta OpenStreetMap berlisensi ODbL dan perlu atribusi "© OpenStreetMap contributors".
