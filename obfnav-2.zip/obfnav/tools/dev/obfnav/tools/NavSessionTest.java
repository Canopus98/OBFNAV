package dev.obfnav.tools;

import dev.obfnav.core.Geo;
import dev.obfnav.core.Maneuver;
import dev.obfnav.core.NavSession;
import dev.obfnav.core.Route;
import dev.obfnav.core.RouteOptions;
import dev.obfnav.core.Router;
import dev.obfnav.core.Style;
import dev.obfnav.core.Waypoints;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Simulated drives against {@link NavSession}, plus waypoint storage tests. */
public final class NavSessionTest {
    private static int checks;

    static void check(boolean ok, String msg) {
        checks++;
        if (!ok) throw new AssertionError("FAILED: " + msg);
    }

    static GridSource network() {
        GridSource gs = new GridSource();
        gs.addStraight(1, "Jalan Timur", Style.SECONDARY, 0, 0, 0, 1500, 0, 100);
        gs.addStraight(2, "Jalan Utara", Style.SECONDARY, 0, 1000, -300, 1000, 300, 100);
        return gs;
    }

    /** Position (31-bit) at {@code s} meters along the route polyline. */
    static double[] pointAt(Route r, double s) {
        int i = 0;
        while (i < r.size() - 2 && r.cumDist[i + 1] < s) i++;
        double seg = r.cumDist[i + 1] - r.cumDist[i];
        double t = seg == 0 ? 0 : Math.min(1, Math.max(0, (s - r.cumDist[i]) / seg));
        return new double[]{r.x[i] + t * (r.x[i + 1] - r.x[i]), r.y[i] + t * (r.y[i + 1] - r.y[i])};
    }

    static List<String> drive(NavSession ns, Route r, double speed, double noiseMeters, long seed, boolean[] sawOffRoute,
                              double[] lastAlong, boolean[] arrived) {
        Random rnd = new Random(seed);
        List<String> spoken = new ArrayList<String>();
        double mpu = Geo.metersPerUnit(r.y[0]);
        double prevAlong = -1e9;
        for (double s = 0; s <= r.totalDist + 20; s += speed) {
            double[] p = pointAt(r, Math.min(s, r.totalDist));
            double nx = p[0] + (rnd.nextDouble() * 2 - 1) * noiseMeters / mpu;
            double ny = p[1] + (rnd.nextDouble() * 2 - 1) * noiseMeters / mpu;
            NavSession.State st = ns.update(nx, ny, 10);
            spoken.addAll(st.speech);
            if (st.offRoute) sawOffRoute[0] = true;
            check(st.along >= prevAlong - 2 * noiseMeters - 1, "progress never jumps backwards: " + st.along + " < " + prevAlong);
            prevAlong = st.along;
            lastAlong[0] = st.along;
            if (st.arrived) arrived[0] = true;
        }
        return spoken;
    }

    public static void main(String[] args) throws Exception {
        GridSource gs = network();
        Router rc = new Router(gs, new RouteOptions(false, false, false));
        Route car = rc.route(GridSource.lat(0), GridSource.lon(0), GridSource.lat(300), GridSource.lon(1000));
        check(car.maneuvers.length == 3 && car.maneuvers[1].type == Maneuver.LEFT, "fixture route: left turn at 1000 m");

        // ---- car drive with GPS noise
        boolean[] off = {false}, arr = {false};
        double[] along = {0};
        List<String> sp = drive(new NavSession(car), car, 10, 6, 1, off, along, arr);
        System.out.println("car speech: " + sp);
        check(sp.size() == 6, "six utterances (start, 500, 200, now, destination ahead, arrive): " + sp);
        check(sp.get(0).equals("Ikuti Jalan Timur"), "start: " + sp.get(0));
        check(sp.get(1).matches("Dalam (450|500) meter, belok kiri ke Jalan Utara"), "first warning: " + sp.get(1));
        check(sp.get(2).matches("Dalam (150|200|250) meter, belok kiri ke Jalan Utara"), "second warning: " + sp.get(2));
        check(sp.get(3).equals("Belok kiri ke Jalan Utara sekarang"), "final warning: " + sp.get(3));
        check(sp.get(4).matches("Dalam (150|200|250) meter, tujuan Anda"), "destination ahead: " + sp.get(4));
        check(sp.get(5).equals("Anda telah tiba di tujuan"), "arrival: " + sp.get(5));
        check(!off[0], "6 m GPS noise never counts as off-route");
        check(arr[0], "arrival detected");
        check(Math.abs(along[0] - car.totalDist) < 15, "ended at the end of the route: " + along[0] + " / " + car.totalDist);

        // ---- motorcycle warns later
        Route moto = new Router(gs, new RouteOptions(true, false, false))
                .route(GridSource.lat(0), GridSource.lon(0), GridSource.lat(300), GridSource.lon(1000));
        off[0] = false;
        arr[0] = false;
        List<String> ms = drive(new NavSession(moto), moto, 8, 4, 2, off, along, arr);
        System.out.println("moto speech: " + ms);
        check(ms.size() == 6, "six utterances: " + ms);
        check(ms.get(1).matches("Dalam (250|300) meter, belok kiri ke Jalan Utara"), "motorcycle first warning: " + ms.get(1));
        check(ms.get(2).matches("Dalam (100|150) meter, belok kiri ke Jalan Utara"), "motorcycle second warning: " + ms.get(2));

        // ---- live state while driving: distance to the turn and the turn itself
        NavSession ns = new NavSession(car);
        double[] p = pointAt(car, 700);
        NavSession.State st = ns.update(p[0], p[1], 10);
        check(st.next.type == Maneuver.LEFT && "Jalan Utara".equals(st.next.street), "next maneuver at 700 m");
        check(Math.abs(st.distToNext - 300) < 3, "300 m to the turn: " + st.distToNext);
        check(Math.abs(st.remainingDist - (car.totalDist - 700)) < 3, "remaining distance");
        check(st.remainingTime > 0 && st.remainingTime < car.totalTime, "remaining time");
        p = pointAt(car, 1100);
        st = ns.update(p[0], p[1], 10); // just past the turn, on Jalan Utara
        check(st.next.type == Maneuver.ARRIVE, "after the turn the next maneuver is the arrival");
        check(Math.abs(st.distToNext - (car.totalDist - 1100)) < 3, "distance to arrival");

        // ---- leaving the route
        ns = new NavSession(car);
        p = pointAt(car, 400);
        double mpu = Geo.metersPerUnit(p[1]);
        double offY = p[1] + 120 / mpu; // 120 m south of the road
        for (int i = 0; i < 2; i++) {
            st = ns.update(p[0], offY, 10);
            check(!st.offRoute, "not yet off-route after " + (i + 1) + " bad fix(es)");
            check(st.speech.isEmpty(), "no speech while off the road");
        }
        st = ns.update(p[0], offY, 10);
        check(st.offRoute, "off-route after three consecutive bad fixes");
        check(Math.abs(st.offset - 120) < 3, "offset " + st.offset);
        st = ns.update(p[0], p[1], 10);
        check(!st.offRoute, "back on the road clears the flag");

        // ---- a single GPS spike does not trigger a reroute
        ns = new NavSession(car);
        ns.update(p[0], p[1], 10);
        ns.update(p[0], offY, 10);
        st = ns.update(p[0] + 20 / mpu, p[1], 10);
        check(!st.offRoute, "isolated spike is ignored");

        // ---- poor GPS accuracy widens the tolerance
        ns = new NavSession(car);
        st = ns.update(p[0], p[1] + 60 / mpu, 50);
        check(st.offset > 55 && st.offset < 65 && !st.offRoute, "60 m off with 50 m accuracy is tolerated");
        for (int i = 0; i < 3; i++) st = ns.update(p[0], p[1] + 60 / mpu, 10);
        check(st.offRoute, "the same fix with 10 m accuracy is off-route");

        // ---- jumping ahead (tunnel / lost fixes) re-synchronises
        ns = new NavSession(car);
        ns.update(pointAt(car, 50)[0], pointAt(car, 50)[1], 10);
        p = pointAt(car, 1200);
        st = ns.update(p[0], p[1], 10);
        check(Math.abs(st.along - 1200) < 3 && !st.offRoute, "re-synchronised after a long gap: " + st.along);

        // ---- a straight route: start sentence then arrival
        Route straight = rc.route(GridSource.lat(0), GridSource.lon(100), GridSource.lat(0), GridSource.lon(900));
        off[0] = false;
        arr[0] = false;
        List<String> ss = drive(new NavSession(straight), straight, 10, 3, 3, off, along, arr);
        check(ss.size() == 3 && ss.get(2).equals("Anda telah tiba di tujuan"), "straight route speech: " + ss);

        waypoints();
        System.out.println("NAV TESTS PASSED (" + checks + " checks)");
    }

    static void waypoints() {
        System.out.println("-- waypoints");
        Waypoints w = new Waypoints();
        Waypoints.Waypoint a = w.add(-6.2088, 106.8456, "");
        Waypoints.Waypoint b = w.add(-6.9175, 107.6191, "Rumah\tNenek\n");
        Waypoints.Waypoint c = w.add(-6.3025, 107.3043, "  ");
        check(a.name.equals("WPT 001") && c.name.equals("WPT 002"), "auto names: " + a.name + ", " + c.name);
        check(b.name.equals("Rumah Nenek"), "control characters cleaned: '" + b.name + "'");
        check(w.size() == 3, "three waypoints");
        check(w.nearestIndex(-6.9170, 107.6190) == 1, "nearest waypoint");

        Waypoints r = Waypoints.parse(w.serialize());
        check(r.size() == 3, "round trip count");
        for (int i = 0; i < 3; i++) {
            check(Math.abs(r.get(i).lat - w.get(i).lat) < 1e-6 && Math.abs(r.get(i).lon - w.get(i).lon) < 1e-6
                    && r.get(i).name.equals(w.get(i).name), "round trip item " + i);
        }
        Waypoints.Waypoint d = r.add(1, 1, "");
        check(d.name.equals("WPT 003"), "counter survives a round trip: " + d.name);

        Waypoints bad = Waypoints.parse("v1 5\nabc\t1\tx\n-6.1\t106.8\tOK\n999\t1\tout of range\n-6.2\n\n");
        check(bad.size() == 1 && bad.get(0).name.equals("OK"), "damaged lines skipped: " + bad.size());
        check(Waypoints.parse(null).size() == 0 && Waypoints.parse("").size() == 0, "empty input");

        w.remove(0);
        check(w.size() == 2 && w.get(0).name.equals("Rumah Nenek"), "remove");
        w.remove(99);
        check(w.size() == 2, "remove out of range is ignored");

        Waypoints many = new Waypoints();
        for (int i = 0; i < Waypoints.MAX + 5; i++) many.add(0, 0, "p" + i);
        check(many.size() == Waypoints.MAX && many.get(0).name.equals("p5"), "oldest dropped beyond the limit");
        check(Waypoints.parse("v1 0\n-6.1\t106.8\tNama, dengan koma\n").get(0).name.equals("Nama, dengan koma"), "commas in names");
    }
}
