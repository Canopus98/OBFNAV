package dev.obfnav.tools;

import dev.obfnav.core.Maneuver;
import dev.obfnav.core.Route;
import dev.obfnav.core.RouteOptions;
import dev.obfnav.core.Router;
import dev.obfnav.core.Style;

import java.io.IOException;

/** Router and turn-instruction tests on small hand-made road networks (expected values computed by hand). */
public final class RouterTest {
    private static int checks;

    static void check(boolean ok, String msg) {
        checks++;
        if (!ok) throw new AssertionError("FAILED: " + msg);
    }

    static void near(double actual, double expected, double tol, String msg) {
        check(Math.abs(actual - expected) <= tol, msg + " (expected " + expected + " +-" + tol + ", got " + actual + ")");
    }

    static Route route(GridSource gs, RouteOptions o, double e1, double n1, double e2, double n2) throws IOException {
        return new Router(gs, o).route(GridSource.lat(n1), GridSource.lon(e1), GridSource.lat(n2), GridSource.lon(e2));
    }

    static String describe(Route r) {
        StringBuilder sb = new StringBuilder();
        for (Maneuver m : r.maneuvers) sb.append(m.type).append(':').append(m.street).append('@')
                .append(Math.round(m.distFromStart)).append(' ');
        return sb.toString();
    }

    static final RouteOptions CAR = new RouteOptions(false, false, false);
    static final RouteOptions CAR_NOTOLL = new RouteOptions(false, true, false);
    static final RouteOptions CAR_SHORT = new RouteOptions(false, false, true);
    static final RouteOptions MOTO = new RouteOptions(true, false, false);

    public static void main(String[] args) throws Exception {
        fastestVersusShortest();
        tolls();
        access();
        maneuvers();
        roundabout();
        dedupeAndTiles();
        failures();
        textFormatting();
        System.out.println("ROUTER TESTS PASSED (" + checks + " checks)");
    }

    // ------------------------------------------------------------------

    static void fastestVersusShortest() throws Exception {
        System.out.println("-- fastest vs shortest");
        GridSource gs = new GridSource();
        gs.addStraight(1, "Jalan Langsung", Style.MINOR, 0, 0, 0, 1000, 0, 100);        // 1000 m
        gs.add(2, "Jalan Utama", Style.PRIMARY, 0, 0, 0, 0, 300, 1000, 300, 1000, 0);   // 1600 m, faster
        Route car = route(gs, CAR, 0, 0, 1000, 0);
        near(car.totalDist, 1600, 3, "car fastest takes the faster, longer road");
        near(car.totalTime, 1600 / (45 / 3.6), 1, "car fastest time");
        Route shortest = route(gs, CAR_SHORT, 0, 0, 1000, 0);
        near(shortest.totalDist, 1000, 3, "shortest takes the direct road");
        check(shortest.totalTime > car.totalTime, "shortest is slower than fastest");
        Route moto = route(gs, MOTO, 0, 0, 1000, 0);
        near(moto.totalDist, 1000, 3, "motorcycle (28 vs 42 km/h) prefers the direct road");
        near(moto.totalTime, 1000 / (28 / 3.6), 1, "motorcycle time");
    }

    static void tolls() throws Exception {
        System.out.println("-- toll, oneway");
        GridSource gs = new GridSource();
        gs.addStraight(1, "Jalan Lambat", Style.MINOR, 0, 0, 0, 5000, 0, 250);
        gs.add(10, "Tol Cepat", Style.MOTORWAY, Style.F_TOLL | Style.F_ONEWAY, 0, 0, 1000, 100, 4000, 100, 5000, 0);
        Route car = route(gs, CAR, 0, 0, 5000, 0);
        check(car.usesToll, "car uses the toll road by default");
        check(car.totalTime < 300, "toll route is fast: " + car.totalTime);
        Route avoid = route(gs, CAR_NOTOLL, 0, 0, 5000, 0);
        check(!avoid.usesToll, "avoid-toll does not use toll");
        near(avoid.totalDist, 5000, 5, "avoid-toll takes the slow road");
        Route moto = route(gs, MOTO, 0, 0, 5000, 0);
        check(!moto.usesToll, "motorcycle never uses toll roads");
        Route back = route(gs, CAR, 5000, 0, 0, 0);
        check(!back.usesToll, "toll road is one-way A->B, so B->A cannot use it");
        near(back.totalDist, 5000, 5, "return trip on the slow road");

        // toll=yes on an ordinary trunk road (not a motorway): motorcycles must still stay off it
        GridSource trunk = new GridSource();
        trunk.addStraight(1, "Jalan Biasa", Style.MINOR, 0, 0, 0, 3000, 0, 250);
        trunk.add(2, "Trunk Berbayar", Style.TRUNK, Style.F_TOLL, 0, 0, 1500, 200, 3000, 0);
        check(route(trunk, CAR, 0, 0, 3000, 0).usesToll, "car takes the faster toll trunk");
        Route motoTrunk = route(trunk, MOTO, 0, 0, 3000, 0);
        check(!motoTrunk.usesToll, "motorcycle stays off a toll road of any class");
        near(motoTrunk.totalDist, 3000, 5, "motorcycle takes the ordinary road");

        // two ordinary roads connected only through a toll road
        GridSource only = new GridSource();
        only.addStraight(1, "Jalan Awal", Style.MINOR, 0, 0, 0, 500, 0, 100);
        only.add(2, "Tol Saja", Style.MOTORWAY, Style.F_TOLL | Style.F_ONEWAY, 500, 0, 1000, 0, 1500, 0);
        only.addStraight(3, "Jalan Akhir", Style.MINOR, 0, 1500, 0, 2000, 0, 100);
        check(route(only, CAR, 100, 0, 1900, 0).usesToll, "toll-only trip allowed when tolls are allowed");
        try {
            route(only, CAR_NOTOLL, 100, 0, 1900, 0);
            check(false, "avoid-toll must fail when only toll connects");
        } catch (Router.RouteException e) {
            check(e.getMessage().contains("tanpa jalan tol"), "message mentions toll: " + e.getMessage());
        }
        try {
            route(only, MOTO, 100, 0, 1900, 0);
            check(false, "motorcycle must fail when only toll connects");
        } catch (Router.RouteException e) {
            check(e.getMessage().contains("tanpa jalan tol"), "motorcycle message: " + e.getMessage());
        }
        // standing on a toll road while avoiding tolls snaps to the nearest ordinary road (500 m away here)
        try {
            route(only, CAR_NOTOLL, 1000, 0, 1900, 0);
            check(false, "no toll-free connection exists");
        } catch (Router.RouteException e) {
            check(e.getMessage().contains("tanpa jalan tol"), "start on toll road: " + e.getMessage());
        }
        // too far from every usable road: the message says that toll roads are not being used
        try {
            route(only, CAR_NOTOLL, 0, -9000, 1900, 0);
            check(false, "start 9 km from any road must fail");
        } catch (Router.RouteException e) {
            check(e.getMessage().contains("jalan tol tidak dipakai"), "snap failure explained: " + e.getMessage());
        }
        // a motorway that is NOT toll (toll flag absent) is allowed for cars with avoidToll
        GridSource free = new GridSource();
        free.add(1, "Jalan Bebas Hambatan", Style.MOTORWAY, Style.F_ONEWAY, 0, 0, 1000, 0, 2000, 0);
        check(!route(free, CAR_NOTOLL, 0, 0, 2000, 0).usesToll, "free motorway usable with avoid-toll");
    }

    static void access() throws Exception {
        System.out.println("-- access restrictions");
        GridSource gs = new GridSource();
        GridSource.Road shortcut = gs.addStraight(1, "Jalan Pintas", Style.MINOR, 0, 0, 0, 1000, 0, 100);
        shortcut.noCar = true;
        gs.add(2, "Jalan Memutar", Style.MINOR, 0, 0, 0, 0, 400, 1000, 400, 1000, 0);
        near(route(gs, CAR, 0, 0, 1000, 0).totalDist, 1800, 4, "car must avoid the no-car road");
        near(route(gs, MOTO, 0, 0, 1000, 0).totalDist, 1000, 3, "motorcycle may use it");
        GridSource gs2 = new GridSource();
        gs2.addStraight(1, "Jalan Searah", Style.MINOR, Style.F_REVERSE, 0, 0, 1000, 0, 100); // only west-bound
        gs2.add(2, "Jalan Memutar", Style.MINOR, 0, 0, 0, 0, 400, 1000, 400, 1000, 0);
        near(route(gs2, CAR, 0, 0, 1000, 0).totalDist, 1800, 4, "eastbound cannot use a reverse one-way");
        near(route(gs2, CAR, 1000, 0, 0, 0).totalDist, 1000, 3, "westbound can");
    }

    static void maneuvers() throws Exception {
        System.out.println("-- turn instructions");
        GridSource gs = new GridSource();
        gs.addStraight(20, "Jalan Timur", Style.SECONDARY, 0, 0, 0, 1000, 0, 100);
        gs.addStraight(21, "Jalan Utara", Style.SECONDARY, 0, 500, -300, 500, 300, 100);
        gs.add(22, "Jalan Kelok", Style.TERTIARY, 0, 500, 300, 500, 500, 800, 500);

        Route left = route(gs, CAR, 0, 0, 500, 300);
        check(left.maneuvers.length == 3, "left route has 3 maneuvers: " + describe(left));
        check(left.maneuvers[0].type == Maneuver.START && "Jalan Timur".equals(left.maneuvers[0].street), "start street");
        check(left.maneuvers[1].type == Maneuver.LEFT, "heading east then north is a LEFT turn: " + describe(left));
        check("Jalan Utara".equals(left.maneuvers[1].street), "turn street");
        near(left.maneuvers[1].distFromStart, 500, 2, "distance to the turn");
        check(left.maneuvers[2].type == Maneuver.ARRIVE, "arrive");
        near(left.maneuvers[2].distFromStart, left.totalDist, 0.5, "arrive distance equals route length");
        near(left.totalDist, 800, 3, "route length");

        Route right = route(gs, CAR, 0, 0, 500, -300);
        check(right.maneuvers.length == 3 && right.maneuvers[1].type == Maneuver.RIGHT, "RIGHT turn: " + describe(right));

        Route straight = route(gs, CAR, 0, 0, 1000, 0);
        check(straight.maneuvers.length == 2, "no maneuver when going straight through a junction: " + describe(straight));

        Route bend = route(gs, CAR, 0, 0, 800, 500);
        check(bend.maneuvers.length == 3, "a bend with no junction gives no instruction: " + describe(bend));

        Route mid = route(gs, CAR, 250, 3, 500, 300); // start 3 m off the road, between two nodes
        check(mid.maneuvers.length == 3 && mid.maneuvers[1].type == Maneuver.LEFT, "mid-segment start: " + describe(mid));
        near(mid.totalDist, 550, 3, "start is snapped onto the road");

        Route uturn = route(gs, CAR, 700, 0, 300, 0); // westbound: START, straight through junction, arrive
        check(uturn.maneuvers.length == 2, "westbound straight: " + describe(uturn));

        // a 10 degree kink exactly at a crossing is still "straight on"
        GridSource kink = new GridSource();
        kink.add(50, "Jalan Kelokan", Style.SECONDARY, 0, 0, 0, 500, 0, 1000, 88);
        kink.addStraight(51, "Jalan Silang", Style.MINOR, 0, 500, -200, 500, 200, 100);
        Route k = route(kink, CAR, 0, 0, 1000, 88);
        check(k.maneuvers.length == 2, "10 degree kink at a junction gives no instruction: " + describe(k));

        // a slight turn: a side road leaving at about 35 degrees
        GridSource fork = new GridSource();
        fork.addStraight(1, "Jalan Induk", Style.PRIMARY, 0, 0, 0, 400, 0, 100);
        fork.addStraight(2, "Jalan Induk", Style.PRIMARY, 0, 400, 0, 800, 0, 100);
        fork.addStraight(3, "Jalan Cabang", Style.MINOR, 0, 400, 0, 750, 245, 100); // ~35 deg to the left
        Route sl = route(fork, CAR, 0, 0, 750, 245);
        check(sl.maneuvers.length == 3 && sl.maneuvers[1].type == Maneuver.SLIGHT_LEFT, "slight left: " + describe(sl));
    }

    static void roundabout() throws Exception {
        System.out.println("-- roundabout");
        GridSource gs = new GridSource();
        double r = 40, c = Math.sqrt(0.5) * r;
        // closed, one-way, clockwise (N, NE, E, SE, S, SW, W, NW, N); no explicit junction tag
        gs.add(30, null, Style.MINOR, Style.F_ONEWAY,
                2000, 40, 2000 + c, c, 2040, 0, 2000 + c, -c, 2000, -40, 2000 - c, -c, 1960, 0, 2000 - c, c, 2000, 40);
        gs.addStraight(31, "Jalan Barat", Style.PRIMARY, 0, 1500, 0, 1960, 0, 100);
        gs.addStraight(32, "Jalan Timur Raya", Style.PRIMARY, 0, 2040, 0, 2500, 0, 100);
        gs.addStraight(33, "Jalan Utara Raya", Style.PRIMARY, 0, 2000, 40, 2000, 500, 100);
        gs.addStraight(34, "Jalan Selatan Raya", Style.PRIMARY, 0, 2000, -40, 2000, -500, 100);

        Route east = route(gs, CAR, 1500, 0, 2500, 0);
        check(east.maneuvers.length == 3, "roundabout route: " + describe(east));
        Maneuver m = east.maneuvers[1];
        check(m.type == Maneuver.ROUNDABOUT, "roundabout recognised: " + describe(east));
        check(m.exitNo == 2, "clockwise from west to east passes the north exit first: exit " + m.exitNo);
        check("Jalan Timur Raya".equals(m.street), "exit street " + m.street);
        near(m.distFromStart, 460, 3, "roundabout entry distance");
        check(m.text().startsWith("Masuk bundaran, ambil jalan keluar ke-2"), "text: " + m.text());

        Route south = route(gs, CAR, 1500, 0, 2000, -500);
        Maneuver ms = south.maneuvers[1];
        check(ms.type == Maneuver.ROUNDABOUT && ms.exitNo == 3, "west to south goes the long way: exit " + ms.exitNo
                + " " + describe(south));
    }

    static void dedupeAndTiles() throws Exception {
        System.out.println("-- duplicate roads, tile loading");
        GridSource gs = new GridSource();
        gs.duplicate = true;
        gs.addStraight(1, "Jalan Langsung", Style.MINOR, 0, 0, 0, 1000, 0, 100);
        gs.add(2, "Jalan Utama", Style.PRIMARY, 0, 0, 0, 0, 300, 1000, 300, 1000, 0);
        near(route(gs, CAR, 0, 0, 1000, 0).totalDist, 1600, 3, "same answer when roads are streamed twice");

        GridSource far = new GridSource();
        far.addStraight(40, "Jalan Panjang", Style.PRIMARY, 0, 0, 8000, 12000, 8000, 200);
        Route r = route(far, CAR, 500, 8000, 11500, 8000);
        near(r.totalDist, 11000, 5, "long route length");
        check(far.queries >= 3, "several tiles were loaded: " + far.queries + " queries");
        check(far.maxQueryWidthUnits <= dev.obfnav.core.Geo.unitsFromMeters(6100, GridSource.uy(8000)),
                "no query covers the whole 11 km route: " + far.maxQueryWidthUnits);
        check(r.maneuvers.length == 2, "straight road has only start and arrive: " + describe(r));
    }

    static void failures() throws Exception {
        System.out.println("-- failures");
        GridSource gs = new GridSource();
        gs.addStraight(1, "Jalan A", Style.MINOR, 0, 0, 0, 500, 0, 100);
        gs.addStraight(2, "Jalan B", Style.MINOR, 0, 0, 2000, 500, 2000, 100); // not connected to A
        try {
            route(gs, CAR, 0, 0, 500, 2000);
            check(false, "disconnected roads must not produce a route");
        } catch (Router.RouteException e) {
            check(e.getMessage().contains("Tidak ada rute"), "no-route message: " + e.getMessage());
        }
        try {
            route(gs, CAR, 0, -60000, 500, 0);
            check(false, "start far from every road must fail");
        } catch (Router.RouteException e) {
            check(e.getMessage().contains("terlalu jauh"), "too-far message: " + e.getMessage());
        }
    }

    static void textFormatting() {
        System.out.println("-- text");
        Maneuver left = new Maneuver(Maneuver.LEFT, 5, 0, "Jalan Utara", 500);
        check("Belok kiri ke Jalan Utara".equals(left.text()), left.text());
        check("Dalam 300 meter, belok kiri ke Jalan Utara".equals(left.speech(300)), left.speech(300));
        check("Belok kiri ke Jalan Utara sekarang".equals(left.speech(20)), left.speech(20));
        check("Dalam 1 koma 2 kilometer, belok kiri ke Jalan Utara".equals(left.speech(1180)), left.speech(1180));
        check("Belok tajam ke kanan".equals(new Maneuver(Maneuver.SHARP_RIGHT, 1, 0, null, 0).text()), "sharp right");
        check("Putar balik".equals(new Maneuver(Maneuver.UTURN, 1, 0, null, 0).text()), "u-turn");
        check("Ikuti Jalan Timur".equals(new Maneuver(Maneuver.START, 0, 0, "Jalan Timur", 0).text()), "start");
        check("Mulai perjalanan".equals(new Maneuver(Maneuver.START, 0, 0, null, 0).text()), "start unnamed");
        check("80 m".equals(Maneuver.fmtDist(80)), Maneuver.fmtDist(80));
        check("350 m".equals(Maneuver.fmtDist(349)), Maneuver.fmtDist(349));
        check("1,2 km".equals(Maneuver.fmtDist(1234)), Maneuver.fmtDist(1234));
        check("15 km".equals(Maneuver.fmtDist(15000)), Maneuver.fmtDist(15000));
        check("7 mnt".equals(Maneuver.fmtTime(7 * 60)), Maneuver.fmtTime(420));
        check("1 j 20 mnt".equals(Maneuver.fmtTime(80 * 60)), Maneuver.fmtTime(4800));
    }
}
