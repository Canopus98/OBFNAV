package dev.obfnav.tools;

import dev.obfnav.core.Geo;
import dev.obfnav.core.Maneuver;
import dev.obfnav.core.ObfReader;
import dev.obfnav.core.ObfRoadSource;
import dev.obfnav.core.Route;
import dev.obfnav.core.RouteOptions;
import dev.obfnav.core.Router;

import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

/**
 * Computes a route on a real .obf file and prints the instructions:
 * <pre>
 *   java -cp out dev.obfnav.tools.RouteDump peta.obf LAT1 LON1 LAT2 LON2 [car|moto] [notoll] [short]
 * </pre>
 */
public final class RouteDump {
    public static void main(String[] a) throws Exception {
        if (a.length < 5) {
            System.err.println("usage: RouteDump file.obf lat1 lon1 lat2 lon2 [car|moto] [notoll] [short]");
            System.exit(2);
        }
        boolean moto = false, notoll = false, shortest = false;
        for (int i = 5; i < a.length; i++) {
            if (a[i].equals("moto")) moto = true;
            else if (a[i].equals("notoll")) notoll = true;
            else if (a[i].equals("short")) shortest = true;
        }
        RandomAccessFile raf = new RandomAccessFile(a[0], "r");
        FileChannel ch = raf.getChannel();
        ObfReader reader = new ObfReader(ch.map(FileChannel.MapMode.READ_ONLY, 0, ch.size()));
        Router router = new Router(new ObfRoadSource(reader), new RouteOptions(moto, notoll, shortest));
        double la1 = Double.parseDouble(a[1]), lo1 = Double.parseDouble(a[2]);
        double la2 = Double.parseDouble(a[3]), lo2 = Double.parseDouble(a[4]);
        long t0 = System.nanoTime();
        Route r;
        try {
            r = router.route(la1, lo1, la2, lo2);
        } catch (Router.RouteException e) {
            System.out.println("NO ROUTE: " + e.getMessage() + " (" + (System.nanoTime() - t0) / 1000000 + " ms)");
            return;
        }
        long ms = (System.nanoTime() - t0) / 1000000;
        double straight = Geo.dist(Geo.lonToX(lo1), Geo.latToY(la1), Geo.lonToX(lo2), Geo.latToY(la2));
        System.out.printf("route: %s  (straight line %.1f km, %d points, %d ms, %s%s%s)%n", r.summary(),
                straight / 1000, r.size(), ms, moto ? "motor" : "mobil", notoll ? ", hindari tol" : "",
                shortest ? ", terpendek" : ", tercepat");
        for (Maneuver m : r.maneuvers) {
            System.out.printf("  %6s  %s%n", Maneuver.fmtDist(m.distFromStart), m.text());
        }
        raf.close();
    }
}
