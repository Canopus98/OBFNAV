package dev.obfnav.tools;

import dev.obfnav.core.*;

import java.io.RandomAccessFile;
import java.nio.channels.FileChannel;
import java.util.*;

/**
 * Property test on a real .obf file: routes between random pairs of real road points and checks invariants
 * (shortest is never longer, fastest is never slower, no toll for motorcycles/avoid-toll, instructions are sane).
 *   java -cp out dev.obfnav.tools.RealFileCheck peta.obf [pairs]
 */
public final class RealFileCheck {
    public static void main(String[] a) throws Exception {
        int pairs = a.length > 1 ? Integer.parseInt(a[1]) : 60;
        RandomAccessFile raf = new RandomAccessFile(a[0], "r");
        FileChannel ch = raf.getChannel();
        ObfReader reader = new ObfReader(ch.map(FileChannel.MapMode.READ_ONLY, 0, ch.size()));
        ObfRoadSource src = new ObfRoadSource(reader);
        // sample road points
        final List<int[]> pts = new ArrayList<int[]>();
        final Random rnd = new Random(12345);
        src.roads(0, Integer.MAX_VALUE, 0, Integer.MAX_VALUE, new RoadSource.Sink() {
            public void road(RoadSource.Road r) {
                if (r.cls >= Style.TERTIARY && r.cls <= Style.PRIMARY && rnd.nextInt(8) == 0) {
                    int i = rnd.nextInt(r.xy.length / 2) * 2;
                    pts.add(new int[]{r.xy[i], r.xy[i + 1]});
                }
            }
        });
        System.out.println("sampled " + pts.size() + " points on tertiary..primary roads");
        RouteOptions car = new RouteOptions(false, false, false), carNoToll = new RouteOptions(false, true, false);
        RouteOptions carShort = new RouteOptions(false, false, true), moto = new RouteOptions(true, false, false);
        Router rCar = new Router(src, car), rNoToll = new Router(src, carNoToll), rShort = new Router(src, carShort),
                rMoto = new Router(src, moto);
        int tried = 0, ok = 0, noRoute = 0, violations = 0, tollRoutes = 0, longest = 0;
        long msTotal = 0, msMax = 0;
        double maxDetour = 0;
        while (tried < pairs) {
            int[] p = pts.get(rnd.nextInt(pts.size())), q = pts.get(rnd.nextInt(pts.size()));
            double straight = Geo.dist(p[0], p[1], q[0], q[1]);
            if (straight < 3000 || straight > 30000) continue;
            tried++;
            double la1 = Geo.yToLat(p[1]), lo1 = Geo.xToLon(p[0]), la2 = Geo.yToLat(q[1]), lo2 = Geo.xToLon(q[0]);
            long t0 = System.nanoTime();
            Route c = null, n = null, s = null, m = null;
            try { c = rCar.route(la1, lo1, la2, lo2); } catch (Router.RouteException e) { }
            try { n = rNoToll.route(la1, lo1, la2, lo2); } catch (Router.RouteException e) { }
            try { s = rShort.route(la1, lo1, la2, lo2); } catch (Router.RouteException e) { }
            try { m = rMoto.route(la1, lo1, la2, lo2); } catch (Router.RouteException e) { }
            long ms = (System.nanoTime() - t0) / 1000000;
            msTotal += ms; msMax = Math.max(msMax, ms);
            if (c == null) { noRoute++; continue; }
            ok++;
            if (c.usesToll) tollRoutes++;
            String id = String.format("(%.4f,%.4f)->(%.4f,%.4f)", la1, lo1, la2, lo2);
            if (n != null && n.usesToll) { violations++; System.out.println("VIOLATION avoid-toll uses toll " + id); }
            if (m != null && m.usesToll) { violations++; System.out.println("VIOLATION motorcycle uses toll " + id); }
            if (s != null && s.totalDist > c.totalDist + 1) { violations++; System.out.println("VIOLATION shortest longer than fastest " + id); }
            if (s != null && c.totalTime > s.totalTime + 1) { violations++; System.out.println("VIOLATION fastest slower than shortest " + id); }
            if (n != null && c.totalTime > n.totalTime + 1) { violations++; System.out.println("VIOLATION toll-allowed slower than avoid-toll " + id); }
            if (c.totalDist < straight * 0.98) { violations++; System.out.println("VIOLATION route shorter than straight line " + id); }
            maxDetour = Math.max(maxDetour, c.totalDist / straight);
            Maneuver[] mv = c.maneuvers;
            if (mv[0].type != Maneuver.START || mv[mv.length - 1].type != Maneuver.ARRIVE) { violations++; System.out.println("VIOLATION first/last maneuver " + id); }
            for (int i = 1; i < mv.length; i++) if (mv[i].distFromStart + 0.01 < mv[i - 1].distFromStart) { violations++; System.out.println("VIOLATION maneuvers not ordered " + id); break; }
            longest = Math.max(longest, mv.length);
        }
        System.out.printf("pairs=%d routed=%d noRoute=%d tollRoutes=%d violations=%d avgMs(4 routes)=%d maxMs=%d maxDetour=%.2f maxManeuvers=%d%n",
                tried, ok, noRoute, tollRoutes, violations, msTotal / Math.max(1, tried), msMax, maxDetour, longest);
        System.exit(violations == 0 ? 0 : 1);
    }
}
