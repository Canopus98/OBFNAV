package dev.obfnav.tools;

import dev.obfnav.core.Feature;
import dev.obfnav.core.Geo;
import dev.obfnav.core.ObfReader;
import dev.obfnav.core.Style;

import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.Date;
import java.util.List;
import java.util.TreeMap;

/**
 * Command line inspector. Use it on a PC to check that a real .obf file is read correctly
 * before blaming the app:
 *
 * <pre>
 *   java -cp out dev.obfnav.tools.ObfDump file.obf                    # header, zoom levels, rules
 *   java -cp out dev.obfnav.tools.ObfDump file.obf LAT LON ZOOM       # features around a point
 * </pre>
 */
public final class ObfDump {
    public static void main(String[] args) throws Exception {
        if (args.length < 1) {
            System.err.println("usage: ObfDump file.obf [lat lon zoom]");
            System.exit(2);
        }
        RandomAccessFile raf = new RandomAccessFile(args[0], "r");
        FileChannel ch = raf.getChannel();
        if (ch.size() > Integer.MAX_VALUE) throw new IllegalStateException("file > 2 GB not supported");
        ByteBuffer mm = ch.map(FileChannel.MapMode.READ_ONLY, 0, ch.size());
        long t0 = System.nanoTime();
        ObfReader r = new ObfReader(mm);
        System.out.printf("opened in %d ms, version %d, created %s%n", (System.nanoTime() - t0) / 1000000,
                r.getVersion(), new Date(r.getDateCreated()));
        int idx = 0;
        for (ObfReader.MapIndex mi : r.getMaps()) {
            System.out.printf("map[%d] '%s': %d levels%n", idx, mi.name, mi.levels.size());
            for (ObfReader.Level lv : mi.levels) {
                System.out.printf("  zoom %2d..%2d  lat %.4f..%.4f  lon %.4f..%.4f%n", lv.minZoom, lv.maxZoom,
                        Geo.yToLat(lv.bottom), Geo.yToLat(lv.top), Geo.xToLon(lv.left), Geo.xToLon(lv.right));
            }
            int n = 0;
            for (ObfReader.Rule rule : mi.rules) if (rule != null) n++;
            System.out.println("  rules: " + n);
            idx++;
        }
        if (args.length >= 4) {
            double lat = Double.parseDouble(args[1]), lon = Double.parseDouble(args[2]);
            int zoom = Integer.parseInt(args[3]);
            double half = 256.0 * Math.pow(2, 23 - zoom); // about 512 px square at 256 px per tile
            double cx = Geo.lonToX(lon), cy = Geo.latToY(lat);
            final TreeMap<String, Integer> counts = new TreeMap<String, Integer>();
            final int[] named = {0};
            final int[] total = {0};
            for (final ObfReader.MapIndex mi : r.getMaps()) {
                final Style.Rules rc = Style.buildRules(mi);
                long t1 = System.nanoTime();
                r.search(mi, (int) (cx - half), (int) (cx + half), (int) (cy - half), (int) (cy + half), zoom,
                        new ObfReader.FeatureSink() {
                            @Override
                            public boolean accept(ObfReader.MapIndex map, Feature f) {
                                total[0]++;
                                if (f.name != null) named[0]++;
                                String key = "cls" + Style.classOf(rc, f.types);
                                if (f.types.length > 0 && map.rule(f.types[0]) != null) {
                                    key += " (" + map.rule(f.types[0]) + ")";
                                }
                                Integer c = counts.get(key);
                                counts.put(key, c == null ? 1 : c + 1);
                                return true;
                            }
                        });
                System.out.printf("query: %d features (%d named), %d blocks read, %d ms%n", total[0], named[0],
                        r.lastBlocksRead, (System.nanoTime() - t1) / 1000000);
            }
            List<String> keys = new java.util.ArrayList<String>(counts.keySet());
            for (String k : keys) System.out.println("  " + k + " : " + counts.get(k));
        }
        raf.close();
    }
}
