package dev.obfnav.tools;

import dev.obfnav.core.Feature;
import dev.obfnav.core.Geo;
import dev.obfnav.core.ObfReader;
import dev.obfnav.core.Style;

import java.io.File;
import java.io.FileOutputStream;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

/** Round-trip test: writes a synthetic OBF, reads it back through ObfReader (heap and mmap). */
public final class SelfTest {
    private static int checks;

    private static void check(boolean ok, String msg) {
        checks++;
        if (!ok) throw new AssertionError("FAILED: " + msg);
    }

    private static List<Feature> query(ObfReader r, double lon1, double lat1, double lon2, double lat2, int zoom)
            throws Exception {
        final List<Feature> out = new ArrayList<Feature>();
        int l = (int) Geo.lonToX(lon1), rr = (int) Geo.lonToX(lon2);
        int t = (int) Geo.latToY(lat1), b = (int) Geo.latToY(lat2);
        for (ObfReader.MapIndex mi : r.getMaps()) {
            r.search(mi, l, rr, Math.min(t, b), Math.max(t, b), zoom, new ObfReader.FeatureSink() {
                @Override
                public boolean accept(ObfReader.MapIndex map, Feature f) {
                    out.add(f);
                    return true;
                }
            });
        }
        return out;
    }

    private static TreeSet<Long> ids(List<Feature> fs) {
        TreeSet<Long> s = new TreeSet<Long>();
        for (Feature f : fs) s.add(f.id);
        return s;
    }

    private static TreeSet<Long> set(long... v) {
        TreeSet<Long> s = new TreeSet<Long>();
        for (long x : v) s.add(x);
        return s;
    }

    private static void runAll(ObfReader r, SyntheticObf g, String label) throws Exception {
        System.out.println("-- " + label);
        check(r.getVersion() == 2, "version");
        check(r.getDateCreated() == 1700000000000L, "dateCreated");
        check(r.getMaps().size() == 1, "one map index");
        ObfReader.MapIndex mi = r.getMaps().get(0);
        check("synthetic-test".equals(mi.name), "map name");
        check(mi.levels.size() == 2, "two levels");
        check(mi.minZoom() == 6 && mi.maxZoom() == 22, "zoom range");
        check(mi.rule(SyntheticObf.R_PRIMARY).toString().equals("highway=primary"), "rule decode");
        check(mi.rule(SyntheticObf.R_NAME).tag.equals("name") && mi.rule(SyntheticObf.R_NAME).value == null,
                "name rule");

        // 1) whole area, detailed level: all six objects, geometry and names exact
        List<Feature> all = query(r, 106.70, -6.10, 107.00, -6.35, 15);
        check(ids(all).equals(set(1001, 1002, 1003, 2001, 2002, 3001)), "full viewport ids " + ids(all));
        Map<Long, SyntheticObf.Obj> exp = new HashMap<Long, SyntheticObf.Obj>();
        for (SyntheticObf.Obj o : g.west) exp.put(o.id, o);
        for (SyntheticObf.Obj o : g.east) exp.put(o.id, o);
        for (SyntheticObf.Obj o : g.root) exp.put(o.id, o);
        for (Feature f : all) {
            SyntheticObf.Obj o = exp.get(f.id);
            check(Arrays.equals(o.xy, f.xy), "coords of " + f.id + " exp=" + Arrays.toString(o.xy)
                    + " got=" + Arrays.toString(f.xy));
            check(Arrays.equals(o.types, f.types), "types of " + f.id);
            check(o.area == f.area, "area flag of " + f.id);
            check(o.name == null ? f.name == null : o.name.equals(f.name), "name of " + f.id + ": " + f.name);
        }

        check(r.lastBlocksRead == 3, "full viewport reads 3 blocks, got " + r.lastBlocksRead);

        // 2) west-only viewport must not return east objects, and must not even READ the east block
        List<Feature> west = query(r, 106.77, -6.17, 106.81, -6.25, 15);
        check(ids(west).equals(set(1001, 1002)), "west ids " + ids(west));
        check(r.lastBlocksRead == 2, "west viewport reads root+west blocks only, got " + r.lastBlocksRead);

        // 3) east-only viewport
        List<Feature> east = query(r, 106.87, -6.10, 106.99, -6.30, 15);
        check(ids(east).equals(set(2001, 2002)), "east ids " + ids(east));
        check(r.lastBlocksRead == 2, "east viewport reads root+east blocks only, got " + r.lastBlocksRead);

        // 4) low zoom level selects a different level
        List<Feature> low = query(r, 106.70, -6.10, 107.00, -6.35, 8);
        check(ids(low).equals(set(4001)), "low zoom ids " + ids(low));
        check("Kota Tes".equals(low.get(0).name), "low zoom name");

        // 5) zoom with no level
        check(query(r, 106.70, -6.10, 107.00, -6.35, 3).isEmpty(), "zoom 3 empty");

        // 6) viewport outside the data
        check(query(r, 100.0, 1.0, 100.1, 0.9, 15).isEmpty(), "outside empty");

        // 7) early stop
        final int[] cnt = {0};
        r.search(mi, 0, Integer.MAX_VALUE, 0, Integer.MAX_VALUE, 15, new ObfReader.FeatureSink() {
            @Override
            public boolean accept(ObfReader.MapIndex map, Feature f) {
                cnt[0]++;
                return false;
            }
        });
        check(cnt[0] == 1, "sink can stop the search");

        // 8) style classification
        Style.Rules rc = Style.buildRules(mi);
        for (Feature f : all) f.cls = Style.classOf(rc, f.types);
        Map<Long, Integer> cls = new HashMap<Long, Integer>();
        for (Feature f : all) cls.put(f.id, f.cls);
        check(cls.get(1001L) == Style.MINOR, "residential -> MINOR");
        check(cls.get(1002L) == Style.PRIMARY, "primary -> PRIMARY");
        check(cls.get(1003L) == Style.BUILDING, "building");
        check(cls.get(2001L) == Style.MOTORWAY, "motorway");
        check(cls.get(2002L) == Style.WATER, "water");
        for (Feature f : low) f.cls = Style.classOf(rc, f.types);
        check(low.get(0).cls == Style.PLACE_BIG, "town -> PLACE_BIG");

        // 9) geo round trip
        double lon = 106.8456, lat = -6.2088;
        check(Math.abs(Geo.xToLon(Geo.lonToX(lon)) - lon) < 1e-9, "lon roundtrip");
        check(Math.abs(Geo.yToLat(Geo.latToY(lat)) - lat) < 1e-9, "lat roundtrip");
    }

    public static void main(String[] args) throws Exception {
        SyntheticObf g = new SyntheticObf();
        byte[] data = g.build();
        System.out.println("synthetic file: " + data.length + " bytes");

        runAll(new ObfReader(ByteBuffer.wrap(data)), g, "heap buffer");

        File tmp = File.createTempFile("synthetic", ".obf");
        tmp.deleteOnExit();
        FileOutputStream fo = new FileOutputStream(tmp);
        fo.write(data);
        fo.close();
        RandomAccessFile raf = new RandomAccessFile(tmp, "r");
        FileChannel ch = raf.getChannel();
        ByteBuffer mm = ch.map(FileChannel.MapMode.READ_ONLY, 0, ch.size());
        runAll(new ObfReader(mm), g, "memory-mapped file");
        raf.close();

        // corrupted / truncated input must fail with IOException, not crash
        try {
            new ObfReader(ByteBuffer.wrap(Arrays.copyOf(data, data.length - 40)));
            check(false, "truncated file must be rejected");
        } catch (java.io.IOException expected) {
            check(true, "truncated rejected");
        }
        try {
            new ObfReader(ByteBuffer.wrap(new byte[]{0, 1, 2, 3, 4, 5}));
            check(false, "garbage must be rejected");
        } catch (java.io.IOException expected) {
            check(true, "garbage rejected");
        }

        System.out.println("ALL TESTS PASSED (" + checks + " checks)");
    }
}
