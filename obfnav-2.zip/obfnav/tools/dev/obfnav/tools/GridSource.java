package dev.obfnav.tools;

import dev.obfnav.core.Geo;
import dev.obfnav.core.RoadSource;

import java.util.ArrayList;
import java.util.List;

/** In-memory road network for tests. Coordinates are given in meters east/north of a fixed origin. */
public final class GridSource implements RoadSource {
    public static final double ORIGIN_LON = 107.40, ORIGIN_LAT = -6.30;
    private static final double ORIGIN_X = Geo.lonToX(ORIGIN_LON), ORIGIN_Y = Geo.latToY(ORIGIN_LAT);
    private static final double MPU = Geo.metersPerUnit(ORIGIN_Y);

    private final List<Road> roads = new ArrayList<Road>();
    public boolean duplicate;
    public int queries;
    public long maxQueryWidthUnits;

    public static int ux(double east) {
        return (int) Math.round(ORIGIN_X + east / MPU);
    }

    public static int uy(double north) {
        return (int) Math.round(ORIGIN_Y - north / MPU);
    }

    public static double lat(double north) {
        return Geo.yToLat(uy(north));
    }

    public static double lon(double east) {
        return Geo.xToLon(ux(east));
    }

    public Road add(long id, String name, int cls, int flags, double... enPairs) {
        Road r = new Road();
        r.id = id;
        r.name = name;
        r.cls = cls;
        r.flags = flags;
        r.xy = new int[enPairs.length];
        for (int i = 0; i < enPairs.length; i += 2) {
            r.xy[i] = ux(enPairs[i]);
            r.xy[i + 1] = uy(enPairs[i + 1]);
        }
        roads.add(r);
        return r;
    }

    /** Adds a straight road with a node every {@code step} meters (so junction detection has real nodes). */
    public Road addStraight(long id, String name, int cls, int flags, double e0, double n0, double e1, double n1,
                            double step) {
        double len = Math.hypot(e1 - e0, n1 - n0);
        int parts = Math.max(1, (int) Math.round(len / step));
        double[] pts = new double[(parts + 1) * 2];
        for (int i = 0; i <= parts; i++) {
            pts[2 * i] = e0 + (e1 - e0) * i / parts;
            pts[2 * i + 1] = n0 + (n1 - n0) * i / parts;
        }
        return add(id, name, cls, flags, pts);
    }

    @Override
    public void roads(int left, int right, int top, int bottom, Sink sink) {
        queries++;
        maxQueryWidthUnits = Math.max(maxQueryWidthUnits, (long) right - left);
        for (Road r : roads) {
            int minX = Integer.MAX_VALUE, maxX = Integer.MIN_VALUE, minY = Integer.MAX_VALUE, maxY = Integer.MIN_VALUE;
            for (int i = 0; i < r.xy.length; i += 2) {
                minX = Math.min(minX, r.xy[i]);
                maxX = Math.max(maxX, r.xy[i]);
                minY = Math.min(minY, r.xy[i + 1]);
                maxY = Math.max(maxY, r.xy[i + 1]);
            }
            if (maxX < left || minX > right || maxY < top || minY > bottom) continue;
            sink.road(r);
            if (duplicate) sink.road(r);
        }
    }
}
