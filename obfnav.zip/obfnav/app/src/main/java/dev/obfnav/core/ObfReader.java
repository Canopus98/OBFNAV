package dev.obfnav.core;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Minimal read-only reader for the MAP section of OsmAnd .obf files.
 *
 * <p>The file is accessed through a (memory mapped) {@link ByteBuffer}; only the blocks that
 * overlap the requested viewport are decoded, so RAM use stays small regardless of file size.
 *
 * <p>Format notes (derived from OsmAnd's BinaryMapIndexReader / osmand_odb.proto):
 * <ul>
 *   <li>Top level is a protobuf-like stream. Sections are tagged with wire type 5 followed by a
 *       custom length: 4 bytes big-endian, or 8 bytes if the first byte has its high bit set.</li>
 *   <li>Top-level field numbers: 1 version, 18 dateCreated, 32 versionConfirm, 33 owner,
 *       4 transport, 6 MAP, 7 address, 8 POI, 9 routing, 10 HH routing.</li>
 *   <li>Coordinates are 31-bit Mercator; inside a block they are zig-zag deltas, shifted left by 5
 *       and anchored at the box corner (left/top) masked to a multiple of 32.</li>
 * </ul>
 * Only the MAP section is read. POI, address and routing sections are skipped.
 *
 * <p>Instances are not thread safe for concurrent use; {@link #search} is synchronized.
 */
public final class ObfReader {
    public static final int SHIFT = 5;
    private static final int MASK = ~((1 << SHIFT) - 1);
    private static final Charset UTF8 = Charset.forName("UTF-8");

    // OsmAndStructure
    private static final int F_VERSION = 1;
    private static final int F_MAPINDEX = 6;
    private static final int F_DATECREATED = 18;
    private static final int F_VERSIONCONFIRM = 32;
    // OsmAndMapIndex
    private static final int F_MI_NAME = 2;
    private static final int F_MI_RULES = 4;
    private static final int F_MI_LEVELS = 5;
    // MapEncodingRule
    private static final int F_RULE_TAG = 3;
    private static final int F_RULE_VALUE = 5;
    private static final int F_RULE_ID = 7;
    private static final int F_RULE_TYPE = 10;
    // MapRootLevel
    private static final int F_LV_MAXZOOM = 1;
    private static final int F_LV_MINZOOM = 2;
    private static final int F_LV_LEFT = 3;
    private static final int F_LV_RIGHT = 4;
    private static final int F_LV_TOP = 5;
    private static final int F_LV_BOTTOM = 6;
    private static final int F_LV_BOXES = 7;
    private static final int F_LV_BLOCKS = 15;
    // MapDataBox
    private static final int F_BOX_LEFT = 1;
    private static final int F_BOX_RIGHT = 2;
    private static final int F_BOX_TOP = 3;
    private static final int F_BOX_BOTTOM = 4;
    private static final int F_BOX_SHIFT = 5;
    private static final int F_BOX_BOXES = 7;
    // MapDataBlock
    private static final int F_BLK_BASEID = 10;
    private static final int F_BLK_OBJECTS = 12;
    private static final int F_BLK_STRINGS = 15;
    // MapData
    private static final int F_OBJ_COORDS = 1;
    private static final int F_OBJ_AREACOORDS = 2;
    private static final int F_OBJ_TYPES = 7;
    private static final int F_OBJ_STRINGNAMES = 10;
    private static final int F_OBJ_ID = 12;

    public static final class Rule {
        public final String tag;
        public final String value;
        public final int type;

        Rule(String tag, String value, int type) {
            this.tag = tag;
            this.value = value;
            this.type = type;
        }

        @Override
        public String toString() {
            return tag + "=" + value;
        }
    }

    public static final class Level {
        public int minZoom, maxZoom;
        public int left, right, top, bottom;
        int[] boxStart = new int[4];
        int[] boxLen = new int[4];
        int boxCount;

        void addBox(int start, int len) {
            if (boxCount == boxStart.length) {
                boxStart = Arrays.copyOf(boxStart, boxCount * 2);
                boxLen = Arrays.copyOf(boxLen, boxCount * 2);
            }
            boxStart[boxCount] = start;
            boxLen[boxCount] = len;
            boxCount++;
        }
    }

    public static final class MapIndex {
        public String name;
        /** Indexed by rule id; entries may be null. */
        public Rule[] rules = new Rule[64];
        public final List<Level> levels = new ArrayList<Level>();
        int nameRule = -1;

        public Rule rule(int id) {
            return id >= 0 && id < rules.length ? rules[id] : null;
        }

        void putRule(int id, Rule r) {
            if (id < 0 || id > 5000000) return;
            if (id >= rules.length) rules = Arrays.copyOf(rules, Math.max(id + 1, rules.length * 2));
            rules[id] = r;
        }

        public int minZoom() {
            int z = Integer.MAX_VALUE;
            for (Level l : levels) z = Math.min(z, l.minZoom);
            return z == Integer.MAX_VALUE ? 0 : z;
        }

        public int maxZoom() {
            int z = 0;
            for (Level l : levels) z = Math.max(z, l.maxZoom);
            return z;
        }

        /** Center of the area covered by this map, in 31-bit coordinates (or -1 if unknown). */
        public long centerX() {
            if (levels.isEmpty()) return -1;
            long l = Long.MAX_VALUE, r = Long.MIN_VALUE;
            for (Level lv : levels) {
                l = Math.min(l, lv.left);
                r = Math.max(r, lv.right);
            }
            return (l + r) / 2;
        }

        public long centerY() {
            if (levels.isEmpty()) return -1;
            long t = Long.MAX_VALUE, b = Long.MIN_VALUE;
            for (Level lv : levels) {
                t = Math.min(t, lv.top);
                b = Math.max(b, lv.bottom);
            }
            return (t + b) / 2;
        }
    }

    public interface FeatureSink {
        /** @return false to stop the search. */
        boolean accept(MapIndex map, Feature f);
    }

    private static final class Node {
        int left, right, top, bottom;
        int start;
        long block;
    }

    private final ByteBuffer b;
    private int pos;
    /** Number of data blocks decoded by the most recent {@link #search} call (for diagnostics/tests). */
    public int lastBlocksRead;
    private int version;
    private long dateCreated;
    private final List<MapIndex> maps = new ArrayList<MapIndex>();
    private int[] scratch = new int[2048];

    public ObfReader(ByteBuffer buffer) throws IOException {
        this.b = buffer;
        try {
            parseStructure();
        } catch (IndexOutOfBoundsException e) {
            throw new IOException("Corrupt or truncated OBF file", e);
        }
    }

    public int getVersion() {
        return version;
    }

    public long getDateCreated() {
        return dateCreated;
    }

    public List<MapIndex> getMaps() {
        return maps;
    }

    // ---------------------------------------------------------------- low level

    private int u8() {
        return b.get(pos++) & 0xFF;
    }

    private int varint32() {
        int r = 0;
        int s = 0;
        while (true) {
            int x = u8();
            if (s < 32) r |= (x & 0x7F) << s;
            if ((x & 0x80) == 0) return r;
            s += 7;
            if (s > 70) throw new IndexOutOfBoundsException("bad varint");
        }
    }

    private long varint64() {
        long r = 0;
        int s = 0;
        while (true) {
            int x = u8();
            if (s < 64) r |= ((long) (x & 0x7F)) << s;
            if ((x & 0x80) == 0) return r;
            s += 7;
            if (s > 70) throw new IndexOutOfBoundsException("bad varint");
        }
    }

    private int sint32() {
        int n = varint32();
        return (n >>> 1) ^ -(n & 1);
    }

    private long sint64() {
        long n = varint64();
        return (n >>> 1) ^ -(n & 1);
    }

    /** OsmAnd's custom length: 4 bytes big-endian, or 8 bytes when the first byte's high bit is set. */
    private long obfInt() {
        long l = u8();
        boolean eight = l > 0x7f;
        if (eight) l &= 0x7f;
        l = (l << 8) + u8();
        l = (l << 8) + u8();
        l = (l << 8) + u8();
        if (eight) {
            l = (l << 8) + u8();
            l = (l << 8) + u8();
            l = (l << 8) + u8();
            l = (l << 8) + u8();
        }
        return l;
    }

    private int obfLen() throws IOException {
        long l = obfInt();
        if (l < 0 || l > b.limit()) throw new IOException("Bad section length " + l);
        return (int) l;
    }

    private String str() {
        int len = varint32();
        if (len < 0 || pos + len > b.limit()) throw new IndexOutOfBoundsException("bad string");
        byte[] a = new byte[len];
        ByteBuffer d = b.duplicate();
        ((java.nio.Buffer) d).position(pos); // via Buffer: avoids a JDK9+ covariant-return linkage problem
        d.get(a, 0, len);
        pos += len;
        return new String(a, UTF8);
    }

    private void skipField(int tag) throws IOException {
        switch (tag & 7) {
            case 0:
                varint64();
                break;
            case 1:
                pos += 8;
                break;
            case 2: {
                int len = varint32();
                if (len < 0) throw new IOException("Bad length");
                pos += len;
                break;
            }
            case 5:
                pos += obfLen();
                break;
            default:
                throw new IOException("Unsupported wire type " + (tag & 7) + " at " + pos);
        }
    }

    // ---------------------------------------------------------------- structure

    private void parseStructure() throws IOException {
        pos = 0;
        int size = b.limit();
        boolean confirmed = false;
        while (pos < size) {
            int tag = varint32();
            int field = tag >>> 3;
            if (field == 0) throw new IOException("Not an OBF file (bad tag at " + (pos - 1) + ")");
            switch (field) {
                case F_VERSION:
                    version = varint32();
                    break;
                case F_DATECREATED:
                    dateCreated = varint64();
                    break;
                case F_VERSIONCONFIRM:
                    confirmed = varint32() == version;
                    break;
                case F_MAPINDEX: {
                    int len = obfLen();
                    int start = pos;
                    maps.add(readMapIndex(start, start + len));
                    pos = start + len;
                    break;
                }
                default:
                    skipField(tag);
                    break;
            }
        }
        if (!confirmed) throw new IOException("Incomplete OBF file (version confirm missing)");
    }

    private MapIndex readMapIndex(int start, int end) throws IOException {
        MapIndex mi = new MapIndex();
        int nextId = 1;
        pos = start;
        while (pos < end) {
            int tag = varint32();
            switch (tag >>> 3) {
                case F_MI_NAME:
                    mi.name = str();
                    break;
                case F_MI_RULES: {
                    int len = varint32();
                    int rEnd = pos + len;
                    String t = null, v = null;
                    int id = nextId++;
                    int type = 0;
                    while (pos < rEnd) {
                        int rt = varint32();
                        switch (rt >>> 3) {
                            case F_RULE_TAG:
                                t = str();
                                break;
                            case F_RULE_VALUE:
                                v = str();
                                break;
                            case F_RULE_ID:
                                id = varint32();
                                break;
                            case F_RULE_TYPE:
                                type = varint32();
                                break;
                            default:
                                skipField(rt);
                                break;
                        }
                    }
                    pos = rEnd;
                    mi.putRule(id, new Rule(t, v, type));
                    if ("name".equals(t)) mi.nameRule = id;
                    break;
                }
                case F_MI_LEVELS: {
                    int len = obfLen();
                    int s = pos;
                    mi.levels.add(readLevel(s, s + len));
                    pos = s + len;
                    break;
                }
                default:
                    skipField(tag);
                    break;
            }
        }
        return mi;
    }

    private Level readLevel(int start, int end) throws IOException {
        Level lv = new Level();
        pos = start;
        loop:
        while (pos < end) {
            int tag = varint32();
            switch (tag >>> 3) {
                case F_LV_MAXZOOM:
                    lv.maxZoom = varint32();
                    break;
                case F_LV_MINZOOM:
                    lv.minZoom = varint32();
                    break;
                case F_LV_LEFT:
                    lv.left = varint32();
                    break;
                case F_LV_RIGHT:
                    lv.right = varint32();
                    break;
                case F_LV_TOP:
                    lv.top = varint32();
                    break;
                case F_LV_BOTTOM:
                    lv.bottom = varint32();
                    break;
                case F_LV_BOXES: {
                    int len = obfLen();
                    lv.addBox(pos, len);
                    pos += len;
                    break;
                }
                case F_LV_BLOCKS:
                    break loop; // data blocks start here; they are reached through box pointers
                default:
                    skipField(tag);
                    break;
            }
        }
        return lv;
    }

    // ---------------------------------------------------------------- search

    private static boolean overlaps(int l, int r, int t, int bo, int vl, int vr, int vt, int vb) {
        return !(r < vl || l > vr || t > vb || bo < vt);
    }

    /**
     * Streams every feature of {@code map} whose bounding box touches the given rectangle
     * (31-bit coordinates, top &lt; bottom) at the given zoom level.
     */
    public synchronized void search(MapIndex map, int left, int right, int top, int bottom, int zoom,
                                    FeatureSink sink) throws IOException {
        lastBlocksRead = 0;
        try {
            for (Level lv : map.levels) {
                if (zoom < lv.minZoom || zoom > lv.maxZoom) continue;
                if (!overlaps(lv.left, lv.right, lv.top, lv.bottom, left, right, top, bottom)) continue;
                ArrayList<Node> found = new ArrayList<Node>();
                for (int i = 0; i < lv.boxCount; i++) {
                    walkBox(lv.boxStart[i], lv.boxLen[i], lv.left, lv.right, lv.top, lv.bottom,
                            left, right, top, bottom, found);
                }
                Collections.sort(found, new Comparator<Node>() {
                    @Override
                    public int compare(Node x, Node y) {
                        return x.block < y.block ? -1 : (x.block == y.block ? 0 : 1);
                    }
                });
                for (Node n : found) {
                    if (!readBlock(map, n, left, right, top, bottom, sink)) return;
                }
            }
        } catch (IndexOutOfBoundsException e) {
            throw new IOException("Corrupt or truncated OBF data", e);
        }
    }

    private void walkBox(int start, int len, int pl, int pr, int pt, int pb,
                         int vl, int vr, int vt, int vb, List<Node> found) throws IOException {
        pos = start;
        int end = start + len;
        int l = pl, r = pr, t = pt, bo = pb;
        long shift = -1;
        int[] kids = null;
        int kidCount = 0;
        while (pos < end) {
            int tag = varint32();
            switch (tag >>> 3) {
                case F_BOX_LEFT:
                    l = sint32() + pl;
                    break;
                case F_BOX_RIGHT:
                    r = sint32() + pr;
                    break;
                case F_BOX_TOP:
                    t = sint32() + pt;
                    break;
                case F_BOX_BOTTOM:
                    bo = sint32() + pb;
                    break;
                case F_BOX_SHIFT:
                    shift = obfInt();
                    break;
                case F_BOX_BOXES: {
                    int cl = obfLen();
                    if (kids == null) kids = new int[8];
                    if (kidCount + 2 > kids.length) kids = Arrays.copyOf(kids, kids.length * 2);
                    kids[kidCount++] = pos;
                    kids[kidCount++] = cl;
                    pos += cl;
                    break;
                }
                default:
                    skipField(tag);
                    break;
            }
        }
        if (!overlaps(l, r, t, bo, vl, vr, vt, vb)) return;
        if (shift >= 0) {
            Node n = new Node();
            n.left = l;
            n.right = r;
            n.top = t;
            n.bottom = bo;
            n.start = start;
            n.block = shift + start;
            found.add(n);
        }
        for (int i = 0; i < kidCount; i += 2) {
            walkBox(kids[i], kids[i + 1], l, r, t, bo, vl, vr, vt, vb, found);
        }
    }

    private boolean readBlock(MapIndex mi, Node n, int vl, int vr, int vt, int vb, FeatureSink sink)
            throws IOException {
        if (n.block < 0 || n.block >= b.limit()) throw new IOException("Bad block pointer");
        lastBlocksRead++;
        pos = (int) n.block;
        int len = varint32();
        int end = pos + len;
        long baseId = 0;
        ArrayList<Feature> objs = new ArrayList<Feature>();
        List<String> table = null;
        while (pos < end) {
            int tag = varint32();
            switch (tag >>> 3) {
                case F_BLK_BASEID:
                    baseId = varint64();
                    break;
                case F_BLK_OBJECTS: {
                    int ol = varint32();
                    int oe = pos + ol;
                    Feature f = readObject(mi, n, oe, vl, vr, vt, vb);
                    if (f != null) {
                        f.id += baseId;
                        objs.add(f);
                    }
                    pos = oe;
                    break;
                }
                case F_BLK_STRINGS: {
                    int tl = varint32();
                    int te = pos + tl;
                    table = new ArrayList<String>();
                    while (pos < te) {
                        int st = varint32();
                        if ((st >>> 3) == 1) table.add(str());
                        else skipField(st);
                    }
                    pos = te;
                    break;
                }
                default:
                    skipField(tag);
                    break;
            }
        }
        for (Feature f : objs) {
            if (f.nameRef >= 0 && table != null && f.nameRef < table.size()) f.name = table.get(f.nameRef);
            if (!sink.accept(mi, f)) return false;
        }
        return true;
    }

    private Feature readObject(MapIndex mi, Node n, int end, int vl, int vr, int vt, int vb)
            throws IOException {
        int tag = varint32();
        int field = tag >>> 3;
        if (field != F_OBJ_COORDS && field != F_OBJ_AREACOORDS) throw new IOException("Bad map object");
        boolean area = field == F_OBJ_AREACOORDS;
        int size = varint32();
        int ce = pos + size;
        int px = n.left & MASK;
        int py = n.top & MASK;
        int cnt = 0;
        int minX = Integer.MAX_VALUE, maxX = Integer.MIN_VALUE;
        int minY = Integer.MAX_VALUE, maxY = Integer.MIN_VALUE;
        while (pos < ce) {
            int x = (sint32() << SHIFT) + px;
            int y = (sint32() << SHIFT) + py;
            if (cnt + 2 > scratch.length) scratch = Arrays.copyOf(scratch, scratch.length * 2);
            scratch[cnt++] = x;
            scratch[cnt++] = y;
            px = x;
            py = y;
            if (x < minX) minX = x;
            if (x > maxX) maxX = x;
            if (y < minY) minY = y;
            if (y > maxY) maxY = y;
        }
        if (cnt == 0 || !overlaps(minX, maxX, minY, maxY, vl, vr, vt, vb)) {
            pos = end;
            return null;
        }
        Feature f = new Feature();
        f.area = area;
        f.xy = Arrays.copyOf(scratch, cnt);
        f.minX = minX;
        f.maxX = maxX;
        f.minY = minY;
        f.maxY = maxY;
        f.types = new int[0];
        while (pos < end) {
            int t = varint32();
            switch (t >>> 3) {
                case F_OBJ_TYPES: {
                    int tl = varint32();
                    int te = pos + tl;
                    int[] ty = new int[4];
                    int tc = 0;
                    while (pos < te) {
                        if (tc == ty.length) ty = Arrays.copyOf(ty, tc * 2);
                        ty[tc++] = varint32();
                    }
                    f.types = Arrays.copyOf(ty, tc);
                    break;
                }
                case F_OBJ_ID:
                    f.id = sint64();
                    break;
                case F_OBJ_STRINGNAMES: {
                    int sl = varint32();
                    int se = pos + sl;
                    while (pos < se) {
                        int stag = varint32();
                        int ref = varint32();
                        if (stag == mi.nameRule) f.nameRef = ref;
                    }
                    break;
                }
                default:
                    skipField(t); // inner polygons, additional types, label coordinates, ...
                    break;
            }
        }
        return f;
    }
}
